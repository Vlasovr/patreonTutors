//
//  Draggable_Volume_ControlApp.swift
//  Draggable Volume Control
//
//  Created by Damra on 13.11.2024.
//

import SwiftUI

@main
struct Draggable_Volume_ControlApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
