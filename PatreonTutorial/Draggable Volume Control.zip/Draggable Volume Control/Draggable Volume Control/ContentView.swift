//
//  ContentView.swift
//  Draggable Volume Control
//
//  Created by Damra on 13.11.2024.
//

import SwiftUI

struct ContentView: View {
    // MARK: Properties
    @State var startAngle: Double = 0
    @State var toAngle: Double = 180
    
    @State var startProgress: CGFloat = 0
    @State var toProgress: CGFloat = 0.5
    
    // New state variable to control the rectangle color
    @State private var isTapped: Bool = false
    
    var body: some View {
        GeometryReader { proxy in
            let width = proxy.size.width
            
            VStack(spacing: 50) {
                ZStack {
                    self.rotatingGradientCircle(
                        toAngle: toAngle,
                        colors: [.cyan, .purple, .indigo, .pink, .orange],
                        lineWidth: 20,
                        blurRadius: 10,
                        offset: -10,
                        frameSize: 250
                        )
                    
                    Circle()
                        .fill(Color.Neumorphic.main)
                        .frame(width: 280, height: 280)
                        .softInnerShadow(Circle())
                    
                    // Allowing Reverse Swiping
                    ZStack {
                        Rectangle()
                            .fill(isTapped ? .red : Color.Neumorphic.secondary) // Change color on tap
                            .frame(width: 5, height: 18)
                            .scaleEffect(isTapped ? 1.25 : 1)
                    }
                    .rotationEffect(.degrees(90))
                    .offset(x: width / 2.3)
                    .rotationEffect(.degrees(toAngle))
                    .gesture(
                        DragGesture()
                            .onChanged({ value in
                                onDrag(value: value)
                                isTapped = true  // Change color when dragged
                            })
                            .onEnded { _ in
                                isTapped = false  // Revert color when dragging ends
                            }
                        )
                    .rotationEffect(.degrees(-90))
                }
                
                HStack(spacing: 35){
                    Image(systemName: "plus")
                        .imageScale(.large)
                        .foregroundStyle(Color.Neumorphic.secondary)
                    
                    Text("Volume").font(.largeTitle).fontWeight(.regular)
                        .foregroundStyle(Color.Neumorphic.secondary)
                    
                    Image(systemName: "minus").imageScale(.large)
                        .foregroundStyle(Color.Neumorphic.secondary)
                }
            }
        }
        .frame(width: screenBounds().width / 1.6, height: screenBounds().width / 1.6)
    }
    
    func onDrag(value: DragGesture.Value,fromSlider: Bool = false){
        
        // MARK: Converting Translation into Angle
        let vector = CGVector(dx: value.location.x, dy: value.location.y)
        
        // Removing the Button Radius
        // Button Diameter = 30
        // Radius = 15
        let radians = atan2(vector.dy - 15, vector.dx - 15)
        
        // Converting into Angle
        var angle = radians * 180 / .pi
        if angle < 0{angle = 360 + angle}
        
        // Progress
        let progress = angle / 360
        
        if fromSlider{
            
            // Update From Values
            self.startAngle = angle
            self.startProgress = progress
        }
        else{
            
            // Update To Values
            self.toAngle = angle
            self.toProgress = progress
        }
    }
    
}

#Preview {
    ContentView()
}
