//
//  Extension.swift
//  Draggable Volume Control
//
//  Created by Damra on 13.11.2024.
//

import Foundation
import SwiftUI

// MARK: Extensions
extension View{
    
    // MARK: Screen Bounds Extension
    func screenBounds()->CGRect{
        return UIScreen.main.bounds
    }
}

// MARK: Extensions
extension View {
    
    // MARK: Rotating Gradient Circle
    func rotatingGradientCircle(toAngle: Double, colors: [Color], lineWidth: CGFloat, blurRadius: CGFloat, offset: CGFloat, frameSize: CGFloat) -> some View {
        Circle()
            .stroke(
                AngularGradient(
                    gradient: Gradient(colors: colors),
                    center: .center,
                    angle: .degrees(-toAngle)
                ),
                lineWidth: lineWidth
            )
            .blur(radius: blurRadius)
            .offset(y: offset)
            .frame(width: frameSize, height: frameSize)
            .rotationEffect(.degrees(toAngle))
    }
}
