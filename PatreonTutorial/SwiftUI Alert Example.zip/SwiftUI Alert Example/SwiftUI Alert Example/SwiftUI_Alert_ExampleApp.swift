//
//  SwiftUI_Alert_ExampleApp.swift
//  SwiftUI Alert Example
//
//  Created by Damra on 18.12.2023.
//

import SwiftUI

@main
struct SwiftUI_Alert_ExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
