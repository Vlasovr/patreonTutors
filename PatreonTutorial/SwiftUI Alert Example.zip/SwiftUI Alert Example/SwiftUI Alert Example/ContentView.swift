//
//  ContentView.swift
//  SwiftUI Alert Example
//
//  Created by Damra on 18.12.2023.
//

import SwiftUI
import UIKit

struct ContentView: View {
    var body: some View {
        alertView()
    }
}

#Preview {
    alertView()
}

struct alertView: View {
    @State var showAlert = false
    @State var showAlert2 = false
    @State var showAlert3: TVCharacter?
    
    var body: some View {
        ZStack(alignment: .top) {
            Color.black.ignoresSafeArea()
            VStack {
                
                Text("SwiftUICodes Alert").font(.headline).foregroundStyle(.white)
                Spacer()
                Button(action: {
                    showAlert.toggle()
                }){
                    ZStack {
                        RoundedRectangle(cornerRadius: 25)
                            .frame(width: 180, height: 45)
                            .foregroundColor(.white)
                        
                        Text("ShowAlert 1").font(.headline).foregroundStyle(.black)
                    }
                }
                .alert("Are you sure you want to delete this item?", isPresented: $showAlert) {
                    Button("OK", role: .destructive) {
                        print("OK")
                    }
                    Button("Cancel", role: .cancel) {
                        print("cancel")
                    }
                }
                
                Button(action: {
                    showAlert2.toggle()
                }){
                    ZStack {
                        RoundedRectangle(cornerRadius: 25)
                            .frame(width: 180, height: 45)
                            .foregroundColor(.white)
                        
                        Text("ShowAlert 2").font(.headline).foregroundStyle(.black)
                    }
                }
                .alert(isPresented: $showAlert2) {
                    Alert(title: Text("Are you sure you want to delete this item?"), message: Text("This action is irreversible"), primaryButton: .default(Text("Cancel")), secondaryButton: .default(Text("OK")))
                }
                
                Button(action: {
                    showAlert3 = TVCharacter(name: "Sherlock Holmes")
                }){
                    ZStack {
                        RoundedRectangle(cornerRadius: 25)
                            .frame(width: 180, height: 45)
                            .foregroundColor(.white)
                        
                        Text("ShowAlert 3").font(.headline).foregroundStyle(.black)
                    }
                }
                .alert(item: $showAlert3) { show in
                    Alert(title: Text(show.name), message: Text("Great Choice!"), dismissButton: .cancel())
                }
                
                Spacer()
                
            }
        }
    }
}

struct TVCharacter: Identifiable {
    var id: String { name }
    let name: String
}
