//
//  ContentView.swift
//  sourcecode57
//
//  Created by M.Damra on 9.02.2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        BankAppView()
    }
}

#Preview {
    ContentView()
}

struct BankAppView: View {
    @State private var selectedTab = 0
    @State private var cardOffset: CGFloat = 0
    @State private var showDetails = false
    var body: some View {
        ZStack {
            Color(.systemGroupedBackground)
                .ignoresSafeArea()
            VStack {
                HStack {
                    Text("My Bank")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                    
                    Spacer()
                    
                    Button {
                        
                    } label: {
                        Image(systemName: "person.circle.fill")
                            .font(.title)
                            .foregroundColor(.white)
                    }
                }
                .padding()
                .background(LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.7), Color.purple.opacity(0.7)]), startPoint: .topLeading, endPoint: .bottomTrailing))
                
                
                StackedCardsView()
                    .frame(height: 250)
                    .padding()
                
                HStack(spacing: 25){
                    ActionButton(iconName: "arrow.left.arrow.right", labels: "Transfer")
                    ActionButton(iconName: "dollarsign.circle", labels: "Pay")
                    ActionButton(iconName: "creditcard", labels: "Card")
                    ActionButton(iconName: "chart.bar", labels: "Stats")
                }
                .padding()
                
                VStack(alignment: .leading) {
                    Text("Recent Transactions")
                        .font(.headline)
                        .padding(.horizontal)
                    
                    ScrollView(.vertical, showsIndicators: false) {
                        VStack(spacing: 20) {
                            ForEach(0..<5) { _ in
                                TransactionRow()
                            }
                        }
                        .padding()
                    }
                }
                .padding()
                .background(Color.white)
                .cornerRadius(20)
                .padding(.horizontal)
                
                Spacer()
                
            }
        }
    }
}

struct ActionButton: View {
    var iconName: String
    var labels: String
    var body: some View {
        VStack {
            Button {
                
            } label: {
                Image(systemName: iconName)
                    .font(.title)
                    .foregroundColor(.white)
                    .padding()
                    .background(LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.7), Color.purple.opacity(0.7)]), startPoint: .topLeading, endPoint: .bottomTrailing))
                    .clipShape(Circle())
            }
            
            Text(labels)
                .font(.caption)
                .foregroundStyle(.gray)
            
        }
    }
}

struct TransactionRow: View {
    var body: some View {
        HStack {
            Image(systemName: "cart.fill")
                .scaledToFit()
                .font(.title)
                .foregroundColor(.white)
                .padding()
                .background(Color.red.opacity(0.5))
                .clipShape(Circle())
            
            VStack(alignment: .leading) {
                Text("Shopping")
                    .font(.headline)
                Text("12 Oct 2025")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            Text("-$150.00")
                .font(.headline)
                .foregroundColor(.red)
        }
        .background(Color.white)
        .cornerRadius(10)
    }
}

struct StackedCardsView: View {
    @State private var cards: [Card] = [
        Card(title: "Bank Card", cardName: "SwiftUICodes", cardNumber: "1234", expressionDate: "01/29"),
        Card(title: "Bank Card", cardName: "SwiftUICodes", cardNumber: "3456", expressionDate: "09/26"),
        Card(title: "Credit Card", cardName: "SwiftUICodes", cardNumber: "7690", expressionDate: "12/27"),
        Card(title: "Bank Card", cardName: "SwiftUICodes", cardNumber: "4210", expressionDate: "04/31")
    ]
    
    @State private var topCardOffset: CGSize = .zero
    
    var body: some View {
        ZStack {
            ForEach(Array(cards.enumerated()), id: \.element.id) { index, card in
                CardView(card: card)
                    .offset(y: CGFloat(index) * 10)
                    .scaleEffect(index == cards.count - 1 ? 1.0 : 0.95)
                    .offset(x: index == cards.count - 1 ? topCardOffset.width : 0)
                    .animation(.spring(), value: topCardOffset)
                    .gesture(
                        index == cards.count - 1 ?
                        DragGesture()
                            .onChanged { value in
                                topCardOffset = value.translation
                            }
                            .onEnded { value in
                                if abs(value.translation.width) > 100 {
                                    withAnimation {
                                        let removedCard = cards.removeLast()
                                        cards.insert(removedCard, at: 0)
                                        topCardOffset = .zero
                                    }
                                } else {
                                    withAnimation {
                                        topCardOffset = .zero
                                    }
                                }
                            }
                        
                        : nil
                    )
            }
        }
    }
}

struct Card: Identifiable {
    let id = UUID()
    let title: String
    let cardName: String
    let cardNumber: String
    let expressionDate: String
}

struct CardView: View {
    let card: Card
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing))
                .shadow(radius: 10)
            
            VStack(alignment: .leading) {
                HStack {
                    Text(card.title)
                        .font(.headline)
                        .foregroundColor(.white)
                    Spacer()
                    Image(systemName: "wave.3.right")
                        .font(.title)
                        .foregroundColor(.white)
                }
                
                Image("chip1")
                    .resizable()
                    .renderingMode(.template)
                    .foregroundStyle(.white)
                    .frame(width: 50, height: 50)
                
                //Spacer()
                
                Text("**** **** **** \(card.cardNumber)")
                    .font(.title)
                    .foregroundColor(.white)
                    .padding(.bottom, 5)
                
                HStack {
                    VStack(alignment: .leading) {
                        Text("Card Holder")
                            .font(.caption)
                            .foregroundColor(.white)
                        Text(card.cardName)
                            .font(.headline)
                            .foregroundColor(.white)
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .trailing) {
                        Text("Expires")
                            .font(.caption)
                            .foregroundColor(.white)
                        Text(card.expressionDate)
                            .font(.headline)
                            .foregroundColor(.white)
                    }
                }
            }
            .padding()
        }
        .frame(height: 200)
    }
}
