//
//  sourcecode57App.swift
//  sourcecode57
//
//  Created by M.Damra on 9.02.2025.
//

import SwiftUI

@main
struct sourcecode57App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
