//
//  Swipe_Action_AnimationApp.swift
//  Swipe Action Animation
//
//  Created by Damra on 8.11.2023.
//

import SwiftUI

@main
struct Swipe_Action_AnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
