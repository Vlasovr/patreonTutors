//
//  ContentView.swift
//  Swipe Action Animation
//
//  Created by Damra on 8.11.2023.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(alignment: .leading){
            Text("My Inbox")
                .font(.title.bold())
                .padding(.horizontal)
            
            List(messages) { message in
                MessageRow(message: message)
                    .swipeActions {
                        Button {
                            print("Message deleted.")
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }
                        .tint(.red)
                    }
            }
            
        }
    }
}

#Preview {
    ContentView()
}
