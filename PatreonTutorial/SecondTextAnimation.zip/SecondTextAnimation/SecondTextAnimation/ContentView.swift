//
//  ContentView.swift
//  SecondTextAnimation
//
//  Created by Altuğ Nuri ASLANTAŞ on 8.10.2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        // A vertical stack that aligns its content to the left.
        VStack(alignment: .leading) {
            // A header text with heavy font weight, gray color, and some padding at the bottom.
            Text("Blur Text Animation")
                .fontWeight(.heavy)
                .foregroundColor(.gray)
                .padding(.bottom, 10)
            // Another vertical stack for the BlurView components.
            VStack(alignment: .leading) {
                // Four instances of BlurView with different text, font sizes, and animation start times.
                BlurView(text: "Text Animation", textSize: 38, startTime: 0.41)
                BlurView(text: "Made By", textSize: 38, startTime: 1.85)
                BlurView(text: "@SwiftUICodes", textSize: 38, startTime: 2.76)
                BlurView(text: "Subscribe on Youtube", textSize: 16, startTime: 3.76)
                    .padding(.top, 30) // Adds padding to the top for the last line.
            }
        }
    }
}

struct BlurView: View {
    let characters: Array<String.Element>  // Array of characters from the input text.
    let baseTime: Double  // The time after which the animation should start.
    let textSize: Double  // The font size for the text.
    @State var blurValue: Double = 10  // State variable to control the blur radius.
    @State var opacity: Double = 0  // State variable to control the opacity.
    // Initializer for the BlurView, takes text, text size, and the start time as parameters.
    init(text:String, textSize: Double, startTime: Double) {
        characters = Array(text)  // Convert the text into an array of individual characters.
        self.textSize = textSize  // Set the text size.
        baseTime = startTime  // Set the base time for the animation to start.
    }
    var body: some View {
        // Horizontal stack to display the characters side by side.
        HStack(spacing: 1) {
            // Loop through each character and display it as a Text view.
            ForEach(0..<characters.count) { num in
                Text(String(self.characters[num]))  // Convert each character back into a string.
                    .font(.custom("HiraMinProN-W3", fixedSize: textSize))  // Custom font with fixed size.
                    .blur(radius: blurValue)  // Apply the blur effect.
                    .opacity(opacity)  // Set the opacity.
                // Apply an animation with easing in/out effect and a delay for each character.
                    .animation(.easeInOut.delay( Double(num) * 0.15 ), value: blurValue)
            }
        }
        // When the user taps the view, toggle between blurred and non-blurred states.
        .onTapGesture {
            if blurValue == 0 {
                blurValue = 10  // If it's not blurred, set blur value to 10.
                opacity = 0.01  // Set opacity to almost transparent.
            } else {
                blurValue = 0  // Remove blur.
                opacity = 1  // Make the text fully visible.
            }
        }
        // When the view appears, trigger the animation after a delay.
        .onAppear {
            // Wait for the specified baseTime before starting the animation.
            DispatchQueue.main.asyncAfter(deadline: .now() + baseTime) {
                if blurValue == 0 {
                    blurValue = 10  // If no blur, add blur and reduce opacity.
                    opacity = 0.01
                } else {
                    blurValue = 0  // Remove blur and increase opacity.
                    opacity = 1
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
