//
//  SecondTextAnimationApp.swift
//  SecondTextAnimation
//
//  Created by Altuğ Nuri ASLANTAŞ on 8.10.2024.
//

import SwiftUI

@main
struct SecondTextAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
