

import SwiftUI

@main
struct cvApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
