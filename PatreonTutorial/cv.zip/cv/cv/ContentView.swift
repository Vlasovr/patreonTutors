import SwiftUI

// Main Entry Point
struct ContentView: View {
    var body: some View {
        NavigationView {
            ZStack {
                // Animated Background Gradient
                AnimatedBackground()
                    .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 30) {
                    // App Logo with Shadow
                    Image(systemName: "doc.text.image")
                        .resizable()
                        .frame(width: 120, height: 120)
                        .foregroundColor(.white)
                        .shadow(radius: 10)
                    
                    // App Title with Custom Font
                    Text("Pro CV Builder")
                        .font(.custom("AvenirNext-Bold", size: 34))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                        .shadow(radius: 5)
                    
                    // Get Started Button with Gradient
                    NavigationLink(destination: PersonalInfoView()) {
                        Text("Get Started")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(width: 220)
                            .background(
                                LinearGradient(gradient: Gradient(colors: [Color.pink, Color.purple]), startPoint: .leading, endPoint: .trailing)
                            )
                            .cornerRadius(15)
                            .shadow(radius: 5)
                    }
                    
                    // Spacer
                    Spacer()
                    
                    // Settings Button with Icon
                    HStack {
                        Spacer()
                        NavigationLink(destination: SettingsView()) {
                            Image(systemName: "gearshape.fill")
                                .resizable()
                                .frame(width: 35, height: 35)
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.black.opacity(0.3))
                                .clipShape(Circle())
                                .shadow(radius: 5)
                        }
                    }
                }
                .padding()
            }
            .navigationBarHidden(true)
        }
    }
}

// Animated Background
struct AnimatedBackground: View {
    @State private var startPoint = UnitPoint.topLeading
    @State private var endPoint = UnitPoint.bottomTrailing
    
    var body: some View {
        LinearGradient(gradient: Gradient(colors: [.blue, .purple, .pink, .orange]), startPoint: startPoint, endPoint: endPoint)
            .animation(Animation.linear(duration: 10).repeatForever(autoreverses: true))
            .onAppear {
                self.startPoint = UnitPoint.bottomTrailing
                self.endPoint = UnitPoint.topLeading
            }
    }
}

// Personal Information Screen
struct PersonalInfoView: View {
    @State private var fullName = ""
    @State private var email = ""
    @State private var phone = ""
    @State private var dateOfBirth = Date()
    
    var body: some View {
        VStack {
            Form {
                Section(header: Label("Personal Information", systemImage: "person.crop.circle")) {
                    TextField("Full Name", text: $fullName)
                    TextField("Email Address", text: $email)
                    TextField("Phone Number", text: $phone)
                    DatePicker("Date of Birth", selection: $dateOfBirth, displayedComponents: .date)
                }
                
                Section(header: Label("Profile Picture", systemImage: "photo")) {
                    NavigationLink(destination: ProfilePictureView()) {
                        Text("Upload Profile Picture")
                    }
                }
            }
            
            // Next Button with Icon
            NavigationLink(destination: EducationView()) {
                HStack {
                    Text("Next")
                        .font(.headline)
                    Image(systemName: "arrow.right.circle.fill")
                        .font(.headline)
                }
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.green)
                .cornerRadius(15)
                .padding()
                .shadow(radius: 5)
            }
        }
        .navigationTitle("Personal Info")
    }
}

// Education Screen
struct EducationView: View {
    @State private var institution = ""
    @State private var degree = ""
    @State private var fieldOfStudy = ""
    @State private var graduationYear = ""
    
    var body: some View {
        VStack {
            Form {
                Section(header: Label("Education", systemImage: "book.closed.fill")) {
                    TextField("Institution", text: $institution)
                    TextField("Degree", text: $degree)
                    TextField("Field of Study", text: $fieldOfStudy)
                    TextField("Graduation Year", text: $graduationYear)
                }
            }
            
            // Next Button with Icon
            NavigationLink(destination: WorkExperienceView()) {
                HStack {
                    Text("Next")
                        .font(.headline)
                    Image(systemName: "arrow.right.circle.fill")
                        .font(.headline)
                }
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.green)
                .cornerRadius(15)
                .padding()
                .shadow(radius: 5)
            }
        }
        .navigationTitle("Education")
    }
}

// Work Experience Screen
struct WorkExperienceView: View {
    @State private var experiences: [WorkExperience] = [WorkExperience()]
    
    var body: some View {
        VStack {
            Form {
                Section(header: Label("Work Experience", systemImage: "briefcase.fill")) {
                    ForEach(experiences.indices, id: \.self) { index in
                        VStack(alignment: .leading) {
                            TextField("Company Name", text: $experiences[index].companyName)
                            TextField("Position", text: $experiences[index].position)
                            TextField("Duration", text: $experiences[index].duration)
                            TextField("Responsibilities", text: $experiences[index].responsibilities)
                        }
                    }
                    Button(action: {
                        experiences.append(WorkExperience())
                    }) {
                        HStack {
                            Image(systemName: "plus.circle.fill")
                            Text("Add More Experience")
                        }
                    }
                }
            }
            
            // Next Button with Icon
            NavigationLink(destination: SkillsView()) {
                HStack {
                    Text("Next")
                        .font(.headline)
                    Image(systemName: "arrow.right.circle.fill")
                        .font(.headline)
                }
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.green)
                .cornerRadius(15)
                .padding()
                .shadow(radius: 5)
            }
        }
        .navigationTitle("Work Experience")
    }
}

struct WorkExperience {
    var companyName = ""
    var position = ""
    var duration = ""
    var responsibilities = ""
}

// Skills Screen
struct SkillsView: View {
    @State private var skills = ""
    
    var body: some View {
        VStack {
            Form {
                Section(header: Label("Skills", systemImage: "hammer.fill")) {
                    TextField("e.g., Swift, UI/UX Design", text: $skills)
                }
            }
            
            // Next Button with Icon
            NavigationLink(destination: SummaryView()) {
                HStack {
                    Text("Next")
                        .font(.headline)
                    Image(systemName: "arrow.right.circle.fill")
                        .font(.headline)
                }
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.green)
                .cornerRadius(15)
                .padding()
                .shadow(radius: 5)
            }
        }
        .navigationTitle("Skills")
    }
}

// Summary Screen
struct SummaryView: View {
    @State private var summary = ""
    
    var body: some View {
        VStack {
            Form {
                Section(header: Label("Professional Summary", systemImage: "text.alignleft")) {
                    TextEditor(text: $summary)
                        .frame(height: 150)
                }
            }
            
            // Preview Button with Icon
            NavigationLink(destination: PreviewView()) {
                HStack {
                    Text("Preview")
                        .font(.headline)
                    Image(systemName: "eye.fill")
                        .font(.headline)
                }
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.purple)
                .cornerRadius(15)
                .padding()
                .shadow(radius: 5)
            }
        }
        .navigationTitle("Summary")
    }
}

// Preview Screen
struct PreviewView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 15) {
                // Profile Picture
                Image("profile_picture")
                    .resizable()
                    .frame(width: 120, height: 120)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.blue, lineWidth: 4))
                    .shadow(radius: 10)
                    .padding()
                
                // Personal Info
                Text("Full Name")
                    .font(.title)
                    .fontWeight(.bold)
                HStack {
                    Image(systemName: "envelope.fill")
                    Text("Email Address")
                }
                HStack {
                    Image(systemName: "phone.fill")
                    Text("Phone Number")
                }
                HStack {
                    Image(systemName: "calendar")
                    Text("Date of Birth")
                }
                
                Divider()
                    .padding(.vertical)
                
                // Education
                Text("Education")
                    .font(.headline)
                    .padding(.bottom, 5)
                VStack(alignment: .leading) {
                    Text("Degree in Field of Study")
                        .fontWeight(.semibold)
                    Text("Institution")
                    Text("Graduation Year")
                }
                
                Divider()
                    .padding(.vertical)
                
                // Work Experience
                Text("Work Experience")
                    .font(.headline)
                    .padding(.bottom, 5)
                // List of experiences
                ForEach(0..<2) { _ in
                    VStack(alignment: .leading) {
                        Text("Position at Company")
                            .fontWeight(.semibold)
                        Text("Duration")
                        Text("Responsibilities")
                    }
                    .padding(.bottom, 5)
                }
                
                Divider()
                    .padding(.vertical)
                
                // Skills
                Text("Skills")
                    .font(.headline)
                    .padding(.bottom, 5)
                Text("• Skill 1\n• Skill 2\n• Skill 3")
                
                Divider()
                    .padding(.vertical)
                
                // Summary
                Text("Professional Summary")
                    .font(.headline)
                    .padding(.bottom, 5)
                Text("This is a brief professional summary...")
            }
            .padding()
        }
        .navigationTitle("Preview")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: {
                    // Save action
                }) {
                    HStack {
                        Image(systemName: "square.and.arrow.down")
                        Text("Save")
                    }
                }
            }
        }
    }
}

// Settings Screen
struct SettingsView: View {
    @State private var notificationsEnabled = true
    @State private var darkModeEnabled = false
    
    var body: some View {
        Form {
            Section(header: Label("Preferences", systemImage: "slider.horizontal.3")) {
                Toggle(isOn: $notificationsEnabled) {
                    Label("Enable Notifications", systemImage: "bell.fill")
                }
                Toggle(isOn: $darkModeEnabled) {
                    Label("Dark Mode", systemImage: "moon.fill")
                }
            }
            
            Section(header: Label("About", systemImage: "info.circle.fill")) {
                NavigationLink(destination: AboutView()) {
                    Text("About This App")
                }
            }
        }
        .navigationTitle("Settings")
    }
}

// Profile Picture Upload Screen
struct ProfilePictureView: View {
    var body: some View {
        VStack {
            // Placeholder for profile picture upload
            Image(systemName: "person.crop.circle.badge.plus")
                .resizable()
                .frame(width: 150, height: 150)
                .foregroundColor(.gray)
                .padding()
                .overlay(Circle().stroke(Color.blue, lineWidth: 4))
                .shadow(radius: 10)
            
            Text("Tap to upload your profile picture")
                .foregroundColor(.gray)
                .padding()
            
            Spacer()
        }
        .navigationTitle("Profile Picture")
        .onTapGesture {
            // Handle image picker
        }
    }
}

// About Screen
struct AboutView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("About This App")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            Text("Pro Resume Builder is a powerful tool designed to help you create professional resumes with ease. Fill in your details, and let the app do the rest!")
            
            HStack {
                Image(systemName: "heart.fill")
                    .foregroundColor(.red)
                Text("Developed with love by YourName")
            }
            
            Spacer()
        }
        .padding()
        .navigationTitle("About")
    }
}

// Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
