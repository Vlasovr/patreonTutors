//
//  ContentView.swift
//  Animated OnBoarding
//
//  Created by Damra on 7.06.2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        OnBoarding()
    }
}

#Preview {
    ContentView()
}
