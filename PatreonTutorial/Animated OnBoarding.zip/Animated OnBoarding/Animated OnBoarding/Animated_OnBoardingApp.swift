//
//  Animated_OnBoardingApp.swift
//  Animated OnBoarding
//
//  Created by Damra on 7.06.2024.
//

import SwiftUI

@main
struct Animated_OnBoardingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
