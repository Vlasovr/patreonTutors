//
//  CustomIndicatorView.swift
//  Animated OnBoarding
//
//  Created by Damra on 7.06.2024.
//

import Foundation
import SwiftUI

struct CustomIndicatorView: View {
    var totalPages: Int
    var currentPages: Int
    var activeInt: Color = .black
    var inActiveInt: Color = .gray.opacity(0.5)
    
    var body: some View {
        HStack(spacing: 0) {
            ForEach(0..<totalPages, id: \.self) {
                Circle()
                    .fill(currentPages == $0 ? activeInt : inActiveInt)
                    .frame(width: 4, height: 4)
            }
        }
    }
}
