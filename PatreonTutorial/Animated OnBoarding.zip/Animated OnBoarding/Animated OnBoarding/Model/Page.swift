//
//  Page.swift
//  Animated OnBoarding
//
//  Created by Damra on 7.06.2024.
//

import Foundation
import SwiftUI

struct PageIntro: Identifiable, Hashable {
    var id: UUID = .init()
    var introAssetImage: String
    var title: String
    var subTitle: String
    var displayAction: Bool = false
}

var pageIntros: [PageIntro] = [
    .init(introAssetImage: "page 1", title: "Connect with\nCreatives Quickly and Easily", subTitle: "Thank you for being with us. We can help you use your time more efficiently."),
    .init(introAssetImage: "page 2", title: "Get Inspired\nby Creatives", subTitle: "Discover and be inspired by your favorite creator."),
    .init(introAssetImage: "page 2", title: "Let's\nGet Started", subTitle: "Please enter your details to create an account.", displayAction: true)
]
