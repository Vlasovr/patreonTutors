//
//  ContentView.swift
//  SwiftUI HealthKit Integration
//
//  Created by Damra on 16.11.2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                Color.gray.opacity(0.1).ignoresSafeArea()
                HealthView()
            }
            .navigationTitle("Health Data")
        }
    }
}

#Preview {
    ContentView()
}
