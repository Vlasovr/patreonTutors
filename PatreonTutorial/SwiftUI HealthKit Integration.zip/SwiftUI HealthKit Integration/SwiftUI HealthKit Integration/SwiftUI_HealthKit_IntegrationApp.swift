//
//  SwiftUI_HealthKit_IntegrationApp.swift
//  SwiftUI HealthKit Integration
//
//  Created by Damra on 16.11.2024.
//

import SwiftUI

@main
struct SwiftUI_HealthKit_IntegrationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
