//
//  HealthView.swift
//  SwiftUI HealthKit Integration
//
//  Created by Damra on 16.11.2024.
//

import Foundation
import SwiftUI

struct HealthView: View {
    @State private var steps: Double? = nil
    @State private var activeEnergy: Double? = nil
    @State private var isAuthorized: Bool = false
    @State private var errorMessage: String? = nil
    var body: some View {
        VStack(spacing: 20){
            Form {
                Section(header: Text("Steps")) {
                    if let steps = steps {
                        HStack {
                            Image(systemName: "flame.fill")
                                .foregroundStyle(.red)
                                .imageScale(.large)
                            Text("Steps: \(Int(steps))")
                                .font(.callout)
                                .fontWeight(.bold)
                                .foregroundStyle(.red)
                        }
                        
                    } else if let errorMessage = errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .multilineTextAlignment(.center)
                            .padding()
                    } else {
                        Text("Fetching steps...")
                            .font(.headline)
                    }
                }
                
                Section(header: Text("Activity")) {
                    if let activeEnergy = activeEnergy {
                        HStack {
                            Image(systemName: "flame.fill")
                                .foregroundStyle(.red)
                                .imageScale(.large)
                            Text("Activity: \(Int(activeEnergy)) kcal")
                                .font(.callout)
                                .fontWeight(.bold)
                                .foregroundStyle(.red)
                        }
                    } else if let errorMessage = errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .multilineTextAlignment(.center)
                            .padding()
                    } else {
                        Text("Fetching activeEnergy...")
                            .font(.headline)
                    }
                }
            }
            
            Button("Request HealthKit Access") {
                requestHealthKitAccess()
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
            
        }
        .onAppear(perform: fetchSteps)
        .onAppear(perform: fetchActiveEnergy)
    }
    // Request HealthKit authorization
    private func requestHealthKitAccess() {
        HealthKitManager.shared.requestAuthorization { success, error in
            if success {
                isAuthorized = true
                fetchSteps()
                fetchActiveEnergy()
            } else {
                errorMessage = error?.localizedDescription ?? "Authorization failed."
            }
        }
    }
    
    // Fetch steps
    private func fetchSteps() {
        HealthKitManager.shared.fetchStepCount { steps, error in
            if let steps = steps {
                self.steps = steps
            } else if let error = error {
                self.errorMessage = error.localizedDescription
            }
        }
    }
    
    // Fetch active energy
    func fetchActiveEnergy() {
        HealthKitManager.shared.requestAuthorization { success, error in
            if success {
                HealthKitManager.shared.fetchActiveEnergyBurned { energy, error in
                    if let error = error {
                        errorMessage = error.localizedDescription
                    } else if let energy = energy {
                        activeEnergy = energy
                    }
                }
            } else if let error = error {
                errorMessage = error.localizedDescription
            }
        }
    }
}

#Preview {
    HealthView()
}
