//
//  Axis_ControlApp.swift
//  Axis Control
//
//  Created by Damra on 6.12.2024.
//

import SwiftUI

@main
struct Axis_ControlApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView().preferredColorScheme(.dark)
        }
    }
}
