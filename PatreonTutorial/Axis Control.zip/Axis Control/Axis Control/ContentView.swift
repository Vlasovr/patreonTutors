//
//  ContentView.swift
//  Axis Control
//
//  Created by Damra on 6.12.2024.
//

import SwiftUI

struct ContentView: View {
    @State private var offset: CGSize = .zero
    @State private var objectPosition: CGSize = .zero // To move the object
    @State private var joystickDirection: Direction? = nil // To follow the direction of the joystick
    var body: some View {
        ZStack {
            Color.Neumorphic.main.ignoresSafeArea()

            VStack(spacing: 50) {
                // Object to move
                ZStack {
                    Circle()
                        .fill(Color.red)
                        .frame(width: 120, height: 120)
                        .softOuterShadow()

                    Text("SwiftUICodes").font(.headline)
                }
                .offset(objectPosition)
                .animation(.easeInOut(duration: 0.5), value: objectPosition)
                .padding(.bottom, 50)

                Spacer()

                // MARK: Joystick Control

                ZStack {
                    // Outer circle (joystick area)
                    Circle()
                        .fill(Color.Neumorphic.main)
                        .frame(width: 200, height: 200)
                        .softOuterShadow()

                    // Arrow Icons
                    VStack {
                        Image(systemName: "chevron.up")
                            .foregroundColor(.gray)
                        Spacer()
                        HStack {
                            Image(systemName: "chevron.left")
                                .foregroundColor(.gray)
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundColor(.gray)
                        }
                        Spacer()
                        Image(systemName: "chevron.down")
                            .foregroundColor(.gray)
                    }
                    .fontWeight(.bold)
                    .frame(width: 170, height: 170)
                    .padding()

                    // Interior circle and shadow
                    ZStack {
                        // Shadow circle
                        Circle()
                            .fill(Color.green)
                            .frame(width: 45, height: 45)
                            .offset(x: offset.width / 1.25, y: offset.height / 1.25)
                            .blur(radius: 8)
                            .allowsHitTesting(false) // Prevents the shadow from interacting

                        // Joystick Ball
                        Circle()
                            .fill(Color.Neumorphic.main)
                            .frame(width: 60, height: 60)
                            .softInnerShadow(Circle())
                            .offset(offset)

                            .gesture(
                                DragGesture()
                                    .onChanged { value in
                                        let radius: CGFloat = 75 // Radius of the outer circle
                                        let translation = value.translation
                                        let distance = sqrt(translation.width * translation.width + translation.height * translation.height)

                                        if distance <= radius {
                                            self.offset = translation
                                        } else {
                                            let clampedX = (translation.width / distance) * radius
                                            let clampedY = (translation.height / distance) * radius
                                            self.offset = CGSize(width: clampedX, height: clampedY)
                                        }

                                        // Determine joystick orientation
                                        self.joystickDirection = self.getDirection(from: self.offset)
                                    }
                                    .onEnded { _ in
                                        // Return the joystick ball to the centre
                                        withAnimation(.interpolatingSpring(stiffness: 100, damping: 10)) {
                                            self.offset = .zero
                                        }

                                        // Move the object according to the joystick direction
                                        if let direction = self.joystickDirection {
                                            self.moveObject(in: direction)
                                        }

                                        // Reset direction information
                                        self.joystickDirection = nil
                                    }
                            )
                    }
                }.padding(.bottom, 50)
            }
        }
    }

    // Function that determines the joystick direction
    func getDirection(from offset: CGSize) -> Direction? {
        let threshold: CGFloat = 25 // Minimum offset value for determining direction

        if abs(offset.width) > abs(offset.height) {
            if offset.width > threshold {
                return .right
            } else if offset.width < -threshold {
                return .left
            }
        } else {
            if offset.height > threshold {
                return .down
            } else if offset.height < -threshold {
                return .up
            }
        }
        return nil
    }

    // Function that moves the object in the specified direction
    func moveObject(in direction: Direction) {
        let step: CGFloat = 25 // Distance to be travelled in each step
        let maxWidth = UIScreen.main.bounds.width / 2 - 25 // To keep the object within the screen boundaries
        let maxHeight = UIScreen.main.bounds.height / 2 - 25

        switch direction {
        case .up:
            if objectPosition.height - step >= -maxHeight {
                objectPosition.height -= step
            }
        case .down:
            if objectPosition.height + step <= maxHeight {
                objectPosition.height += step
            }
        case .left:
            if objectPosition.width - step >= -maxWidth {
                objectPosition.width -= step
            }
        case .right:
            if objectPosition.width + step <= maxWidth {
                objectPosition.width += step
            }
        }
    }
}

#Preview {
    ContentView().preferredColorScheme(.dark)
}

// Enum defining movement directions
enum Direction {
    case up, down, left, right
}
