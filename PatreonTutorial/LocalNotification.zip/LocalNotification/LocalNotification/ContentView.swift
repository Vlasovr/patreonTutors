//
//  ContentView.swift
//  LocalNotification
//
//  Created by Altuğ Nuri ASLANTAŞ on 22.10.2024.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var notificationManager = NotificationManager() // State object for managing notifications
    @State private var showToast = false // State variable to show or hide the toast message
    var body: some View {
        ZStack {
            Color.black.opacity(0.8).edgesIgnoringSafeArea(.all) // Background color with opacity applied to the entire view, ignoring safe areas
            VStack(spacing: 0) { // Vertical stack layout with no spacing between elements
                // Title section
                Text("All Local Notifications")
                    .font(.title) // Large title font style
                    .fontWeight(.bold) // Bold font weight for emphasis
                    .foregroundColor(Color.green) // Title text color set to green
                    .multilineTextAlignment(.center) // Centers the text if it spans multiple lines
                Text("by SwiftUICodess")
                    .font(.title2) // Slightly smaller title font style
                    .fontWeight(.bold) // Bold font for subtitle
                    .foregroundColor(Color.orange) // Subtitle text color set to orange
                    .multilineTextAlignment(.center) // Centers the subtitle text
                Spacer() // Adds flexible space to push content toward the middle of the screen
                Image("notif")
                    .resizable() // Makes the image resizable
                    .aspectRatio(contentMode: .fit) // Maintains the aspect ratio and fits within the available space
                Spacer() // Adds more flexible space below the image
                HStack {
                    // Button to schedule a single notification
                    Button(action: {
                        notificationManager.scheduleNotification(
                            date: Date().addingTimeInterval(5), // Schedule notification 5 seconds from now
                            title: "Local Notification", // Title of the notification
                            body: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.", // Body of the notification
                            alarmSoundName: "sound1", // Sound for the notification
                            gifName: "alarmGif", // GIF for the notification
                            imageName: "swiftuicodes", // Image for the notification
                            interruptionLvl: .active, // Interruption level of the notification
                            categoryIdentifierV: "Localnotif" // Category identifier for the notification
                        )
                        withAnimation {
                            self.showToast = true // Show toast message when the notification is scheduled
                        }
                        // Hide the toast message after 2 seconds
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            withAnimation {
                                self.showToast = false
                            }
                        }
                    }) {
                        Text("Schedule Notification") // Button text
                            .font(.headline) // Headline font style for the button
                            .padding() // Padding inside the button
                            .frame(maxWidth: .infinity) // Makes the button take the full width of the parent
                            .background(Color.blue) // Background color for the button
                            .foregroundColor(.white) // Text color for the button
                            .cornerRadius(10) // Rounds the corners of the button
                            .shadow(radius: 5) // Adds a shadow to the button
                    }
                    // Button to schedule a repeating notification
                    Button(action: {
                        notificationManager
                            .scheduleRepeatNotification(
                                .daily, // Repeat interval (daily in this case)
                                month: 0,
                                day: 0,
                                hour: 11,
                                minute: 48,
                                title: "Local Notification", // Notification title
                                body: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.", // Notification body
                                alarmSoundName: "sound1", // Notification sound
                                gifName: "", // No GIF for this notification
                                imageName: "swiftuicodes", // Image name for the notification
                                interruptionLvl: .active, // Interruption level for the notification
                                categoryIdentifierV: "Localnotif" // Notification category identifier
                            )
                        withAnimation {
                            self.showToast = true // Show toast message when the repeating notification is scheduled
                        }
                        // Hide the toast message after 2 seconds
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            withAnimation {
                                self.showToast = false
                            }
                        }
                    }) {
                        Text(
                            "Schedule \(Text("REPEAT").foregroundColor(.green)) Notification"
                        ) // Button text with "REPEAT" highlighted in green
                        .font(.headline) // Headline font style
                        .padding() // Padding inside the button
                        .frame(maxWidth: .infinity) // Full-width button
                        .background(Color.purple) // Button background color set to purple
                        .foregroundColor(.white) // Button text color set to white
                        .cornerRadius(10) // Rounds the button corners
                        .shadow(radius: 5) // Adds a shadow effect to the button
                    }
                }
                .padding(.horizontal, 20) // Adds horizontal padding around the buttons
                // Code to run when the view appears
                .onAppear {
                    NotificationManager.instance.requestAuthorization() // Requests notification permissions
                    NotificationManager.instance.DeleteAllNotification() // Deletes all previously scheduled notifications
                    NotificationManager.instance.resetBadgeNumber() // Resets the app badge number
                }
            }
            // Toast message for successful notification scheduling
            if showToast {
                VStack {
                    Spacer() // Pushes content to the bottom
                    HStack {
                        Text("Successfully notification. ✔") // Toast text
                            .foregroundColor(.green) // Toast text color
                            .padding() // Adds padding around the text
                            .background(Color.black.opacity(0.5)) // Semi-transparent background for the toast
                            .cornerRadius(8) // Rounds the corners of the toast
                    }
                    .padding(.horizontal,20) // Adds horizontal padding to the toast
                    .padding(.bottom,100) // Adds bottom padding to position the toast above the bottom edge
                }
                .transition(.move(edge: .leading).combined(with: .opacity)) // Animation for showing the toast with a slide and fade-in effect
                .animation(.easeInOut) // Applies easing animation for smooth transition
            }
        }
    }
}

#Preview {
    ContentView()
}
