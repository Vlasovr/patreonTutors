//
//  LocalNotificationApp.swift
//  LocalNotification
//
//  Created by Altuğ Nuri ASLANTAŞ on 22.10.2024.
//

import SwiftUI

@main
struct LocalNotificationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
