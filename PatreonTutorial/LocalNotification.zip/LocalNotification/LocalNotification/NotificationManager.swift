//
//  NotificationManager.swift
//  LocalNotification
//
//  Created by Altuğ Nuri ASLANTAŞ on 23.10.2024.
//

import SwiftUI

// Singleton instance of NotificationManager is created, which allows only one instance of this class throughout the app.
class NotificationManager: NSObject, ObservableObject, UNUserNotificationCenterDelegate {
    static let instance = NotificationManager() // Singleton instance

    // @AppStorage is used to store the notification permission status persistently.
    // "grantedNotNill" will store if the user has granted notification permissions or not.
    @AppStorage("notificationPermission") var grantedNotNill: Bool = false

    // This method listens to actions that occur when a notification is received.
    // Specifically, it checks if the "REPLY" action was clicked, and prints a message accordingly.
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        if response.actionIdentifier == "REPLY" {
            print("Click REPLY Button")
        }
        print("Click REPLY Button \(response.actionIdentifier)")
        completionHandler()
    }

    // This method requests notification authorization from the user.
    // It checks if the user grants or denies the permission. If granted, it registers for remote notifications and sets grantedNotNill to true.
    func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
            if granted {
                print("Notification permission granted.")
                DispatchQueue.main.async {
                    UIApplication.shared.registerForRemoteNotifications()
                    self.grantedNotNill = true
                }
            } else {
                print("Notification permission denied.")
                self.grantedNotNill = true
            }
        }
    }

    // This method resets the badge number to 0, which clears any red notification badges on the app icon.
    func resetBadgeNumber() {
        UIApplication.shared.applicationIconBadgeNumber = 0
    }

    // This method deletes all scheduled and delivered notifications.
    func DeleteAllNotification() {
        let notificationCenter = UNUserNotificationCenter.current()
        notificationCenter.removeAllPendingNotificationRequests()
        notificationCenter.removeAllDeliveredNotifications()
    }

    // This method deletes only delivered notifications, leaving pending notifications intact.
    func DeleteDeliveredNotifications() {
        let notificationCenter = UNUserNotificationCenter.current()
        notificationCenter.removeAllDeliveredNotifications()
    }
}

// MARK: - Extensions Notifications

extension NotificationManager {
    // This method schedules a notification to be triggered at a specified date.
    // It sets the content of the notification such as title, body, sound, badge number, and optionally includes a GIF.
    // The time interval between the current date and the target date is calculated to determine when the notification should be triggered.
    func scheduleNotification(
        date: Date,
        title: String = "Notification",
        body: String = "",
        alarmSoundName: String = "",
        gifName: String = "",
        imageName: String = "",
        interruptionLvl: InterruptionLevelSelect = .active,
        categoryIdentifierV: String = ""
    ) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = alarmSoundName == "" ? .default : UNNotificationSound(named: UNNotificationSoundName(rawValue: alarmSoundName))
        content.badge = (UIApplication.shared.applicationIconBadgeNumber + 1) as NSNumber
        content.interruptionLevel = interruptionLvl.selectInterrup
        content.categoryIdentifier = categoryIdentifierV

        // Add GIF to the notification if the file is available in the app's bundle.
        if let attchmentURL = Bundle.main.url(
            forResource: gifName,
            withExtension: "gif"
        ) {
            content.attachments = try! [.init(identifier: "gif", url: attchmentURL, options: nil)]
        }
        if gifName == "" {
            // Add IMAGE to the notification if the file is available in the app's bundle.
            if let imageURL = Bundle.main.url(forResource: imageName, withExtension: "jpg") {
                do {
                    let attachment = try UNNotificationAttachment(identifier: "image", url: imageURL, options: nil)
                    content.attachments = [attachment]
                } catch {
                    print("error: \(error)")
                }
            }
        } else {
            // Add GIF to the notification if the file is available in the app's bundle.
            if let attchmentURL = Bundle.main.url(
                forResource: gifName,
                withExtension: "gif"
            ) {
                content.attachments = try! [.init(identifier: "gif", url: attchmentURL, options: nil)]
            }
        }
        
        // Calculate time interval between now and the target date.
        let timeInterval = date.timeIntervalSince(Date())

        // Schedule the notification only if the interval is valid (i.e., positive).
        if timeInterval > 0 {
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: timeInterval, repeats: false)
            let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

            // Add the notification request to the system.
            UNUserNotificationCenter.current().add(request) { error in
                if let error = error {
                    print("Error scheduling notification: \(error.localizedDescription)")
                } else {
                    print("Successfully scheduled notification.")
                }
            }
        }
    }
}

extension NotificationManager {
    // This method schedules a repeat notification (hourly, daily, weekly, monthly, or yearly) based on the selected repeat type.
    func scheduleRepeatNotification(
        _ repeatType: RepeatType,
        month: Int = 5, day: Int = 5,
        hour: Int = 9, minute: Int = 42,
        title: String = "Notification",
        body: String = "",
        alarmSoundName: String = "",
        gifName: String = "",
        imageName: String = "",
        interruptionLvl: InterruptionLevelSelect = .active,
        categoryIdentifierV: String = ""
    ) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = alarmSoundName == "" ? .default : UNNotificationSound(named: UNNotificationSoundName(rawValue: alarmSoundName))
        content.badge = (UIApplication.shared.applicationIconBadgeNumber + 1) as NSNumber
        content.interruptionLevel = interruptionLvl.selectInterrup
        content.categoryIdentifier = categoryIdentifierV

       
        if gifName == "" {
            // Add IMAGE to the notification if the file is available in the app's bundle.
            if let imageURL = Bundle.main.url(forResource: imageName, withExtension: "jpg") {
                do {
                    let attachment = try UNNotificationAttachment(identifier: "image", url: imageURL, options: nil)
                    content.attachments = [attachment]
                } catch {
                    print("Resim eklenemedi: \(error)")
                }
            }
        } else {
            // Add GIF to the notification if the file is available in the app's bundle.
            if let attchmentURL = Bundle.main.url(
                forResource: gifName,
                withExtension: "gif"
            ) {
                content.attachments = try! [.init(identifier: "gif", url: attchmentURL, options: nil)]
            }
        }

        // Set up the date components for the repeat type.
        let dateComponents = selectedRepeatType(
            repeatType,
            hour: hour,
            minute: minute,
            day: day,
            month: month
        )

        // Create a trigger based on the date components for repeated notifications.
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)

        // Create the notification request and add it to the system.
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Error scheduling repeat notification: \(error.localizedDescription)")
            } else {
                print("Successfully scheduled repeat notification.")
            }
        }
    }
}

// This function helps set the DateComponents based on the selected repeat type.
// It returns different components depending on whether the notification repeats hourly, daily, weekly, etc.
func selectedRepeatType(_ repeatType: RepeatType, hour: Int?, minute: Int?, day: Int?, month: Int?) -> DateComponents {
    switch repeatType {
    case .hourly:
        var dateComponents = DateComponents()
        dateComponents.minute = minute
        return dateComponents
    case .daily:
        var dateComponents = DateComponents()
        dateComponents.minute = minute
        dateComponents.hour = hour
        return dateComponents
    case .weekly:
        var dateComponents = DateComponents()
        dateComponents.minute = minute
        dateComponents.hour = hour
        dateComponents.weekday = 6 // Friday as day of the week (Sunday = 1, Saturday = 7)
        return dateComponents
    case .monthly:
        var dateComponents = DateComponents()
        dateComponents.minute = minute
        dateComponents.hour = hour
        dateComponents.day = day
        return dateComponents
    case .yearly:
        var dateComponents = DateComponents()
        dateComponents.minute = minute
        dateComponents.hour = hour
        dateComponents.day = day
        dateComponents.month = month
        return dateComponents
    }
}

// Enum that defines the repeat types for scheduling notifications.
enum RepeatType: Codable {
    case hourly
    case daily
    case weekly
    case monthly
    case yearly
}

// Enum that defines interruption levels for notifications.
// It specifies how the notification interacts with other system notifications.
enum InterruptionLevelSelect: Codable {
    case active, passive, critical, timeSensitive

    // This variable returns the appropriate interruption level for each case.
    var selectInterrup: UNNotificationInterruptionLevel {
        switch self {
        case .active:
            return .active
        case .passive:
            return .passive
        case .critical:
            return .critical
        case .timeSensitive:
            return .timeSensitive
        }
    }
}
