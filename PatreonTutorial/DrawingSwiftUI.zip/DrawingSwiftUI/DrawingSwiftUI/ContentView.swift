//
//  ContentView.swift
//  DrawingSwiftUI
//
//  Created by Selçuk Aslantas on 22.09.2024.
//

import SwiftUI
import PencilKit

// A UIViewRepresentable struct to wrap PKCanvasView for use in SwiftUI
struct CanvasView: UIViewRepresentable {
    // Binding to the PKCanvasView instance
    @Binding var canvasView: PKCanvasView
    // Creates and configures the PKCanvasView
    func makeUIView(context: Context) -> PKCanvasView {
        // Allows drawing with any input (finger or Apple Pencil)
        canvasView.drawingPolicy = .anyInput
        return canvasView
    }
    // Updates the PKCanvasView when SwiftUI state changes
    func updateUIView(_ uiView: PKCanvasView, context: Context) {
        // No updates needed for this simple implementation
    }
}
// The main content view of the application
struct ContentView: View {
    // State variable to hold the PKCanvasView instance
    @State private var canvasView = PKCanvasView()
    // State variable to hold the PKToolPicker instance
    @State private var toolPicker = PKToolPicker()
    var body: some View {
        VStack {
            // Embeds the CanvasView within the SwiftUI view hierarchy
            CanvasView(canvasView: $canvasView)
                .onAppear {
                    // Configure and display the tool picker when the view appears
                    if let window = UIApplication.shared.windows.first {
                        // Make the tool picker visible and associate it with the canvas view
                        toolPicker.setVisible(true, forFirstResponder: canvasView)
                        // Add the canvas view as an observer to the tool picker
                        toolPicker.addObserver(canvasView)
                        // Make the canvas view the first responder to receive input
                        canvasView.becomeFirstResponder()
                    }
                }
                .background(Color.white) // Sets the background color of the canvas
                .cornerRadius(10) // Rounds the corners of the canvas
                .shadow(radius: 5) // Adds a shadow effect to the canvas
                .padding() // Adds padding around the canvas
            HStack {
                // Button to clear the canvas
                Button(action: clearCanvas) {
                    Text("Clear")
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                // Additional buttons can be added here
            }
        }
    }
    // Function to clear the drawing on the canvas
    func clearCanvas() {
        canvasView.drawing = PKDrawing()
    }
}
#Preview {
    ContentView()
}
