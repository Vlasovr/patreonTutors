//
//  DrawingSwiftUIApp.swift
//  DrawingSwiftUI
//
//  Created by Selçuk Aslantas on 22.09.2024.
//

import SwiftUI

@main
struct DrawingSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
