//
//  codeApp.swift
//  code
//
//  Created by Altuğ Nuri ASLANTAŞ on 26.12.2024.
//

import SwiftUI

@main
struct codeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
