
import SwiftUI

// MARK: - 1. CustomTab Enum
// Represents the available tabs in the app.
// Each tab has:
//  - A display title
//  - An SF Symbol name
//  - An associated view builder for rendering its content
enum CustomTab: CaseIterable, Identifiable {
    case home
    case favorites
    case messages
    case profile
    
    var id: Self { self }
    
    var title: String {
        switch self {
        case .home:   return "Home"
        case .favorites:  return "Favorites"
        case .messages:   return "Messages"
        case .profile:return "Profile"
        }
    }
    
    var systemImageName: String {
        switch self {
        case .home:   return "house.fill"
        case .favorites:  return "star.fill"
        case .messages:   return "bubble.left.and.bubble.right.fill"
        case .profile:return "person.crop.circle.fill"
        }
    }
    
    // Returns the view associated with each tab.
    // This way we can avoid large switch statements in `ContentView`.
    @ViewBuilder
    var associatedView: some View {
        switch self {
        case .home:
            HomeView()
        case .favorites:
            FavoritesView()
        case .messages:
            MessagesView()
        case .profile:
            ProfileView()
        }
    }
}

// MARK: - 2. Content Views for Each Tab
struct HomeView: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.blue, Color.purple], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            Text("1\nHome View")
                .font(.largeTitle)
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
                .padding()
        }
    }
}

struct FavoritesView: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.orange, Color.red], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            Text("2\nFavorites View")
                .font(.largeTitle)
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
                .padding()
        }
    }
}

struct MessagesView: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.green, Color.teal], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            Text("3\nMessages View")
                .font(.largeTitle)
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
                .padding()
        }
    }
}

struct ProfileView: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.pink, Color.purple], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            Text("4\nProfile View")
                .font(.largeTitle)
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
                .padding()
        }
    }
}

struct TabBackgroundShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let curveHeight: CGFloat = 14
        
        path.move(to: CGPoint(x: 0, y: rect.height * 2))
        path.addLine(to: CGPoint(x: 0, y: curveHeight))
        path.addQuadCurve(
            to: CGPoint(x: rect.width, y: curveHeight),
            control: CGPoint(x: rect.width / 2, y: 0)
        )
        path.addLine(to: CGPoint(x: rect.width, y: rect.height))
        path.closeSubpath()
        return path
    }
}

struct CustomTabBar: View {
    @Binding var selectedTab: CustomTab
    let namespace: Namespace.ID
    let tabs: [CustomTab]
    
    var body: some View {
        HStack(spacing: 16) {
            ForEach(tabs) { tab in
                GeometryReader { proxy in
                    Button {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            selectedTab = tab
                        }
                    } label: {
                        VStack(spacing: 3) {
                            Image(systemName: tab.systemImageName)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 20, height: 20)
                                .font(.headline)
                            Text(tab.title)
                                .font(.footnote)
                                .lineLimit(1)
                        }
                        .foregroundColor(selectedTab == tab ? .white : .gray)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        
                    }
                    .background(
                        ZStack {
                            if selectedTab == tab {
                                TabBackgroundShape()
                                    .fill(Color.orange)
                                    .matchedGeometryEffect(
                                        id: "TAB_BACKGROUND",
                                        in: namespace
                                    )
                                    .frame(
                                        width: proxy.size.width * 0.9,
                                        height: proxy.size.height * 1.3
                                    )
                                    .offset(y: -5)
                                    .shadow(color: Color.black.opacity(0.3), radius: 6, x: 0, y: 4)
                            }
                        }
                    )
                    .contentShape(Rectangle())
                }
                .frame(height: 60)
            }
        }
        .padding(.horizontal, 25)
        .padding(.bottom, 6)
        .background(
            Color(Color.color1)
                .ignoresSafeArea(edges: .bottom)
        )
    }
}

// MARK: - 5. ContentView
struct ContentView: View {
    @State private var selectedTab: CustomTab = .home
    @Namespace private var animationNamespace
    
    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                selectedTab.associatedView
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .animation(nil, value: selectedTab)
            }
            
            CustomTabBar(
                selectedTab: $selectedTab,
                namespace: animationNamespace,
                tabs: CustomTab.allCases
            )
        }
        .edgesIgnoringSafeArea(.bottom)
    }
}

#Preview {
    ContentView()
}

