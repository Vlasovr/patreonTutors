import SwiftUI
import Combine

// MARK: - 1) ObservableObject to monitor battery information
final class BatteryManager: ObservableObject {
    // Publishes the current battery level (0.0 to 1.0) and battery state
    @Published var batteryLevel: Float = 1.0
    @Published var batteryState: UIDevice.BatteryState = .unknown
    
    // Initialize battery monitoring
    init() {
        // Enable battery monitoring on the device
        UIDevice.current.isBatteryMonitoringEnabled = true
        
        // Set initial battery level and state
        batteryLevel = UIDevice.current.batteryLevel
        batteryState = UIDevice.current.batteryState
        
        // Observe changes to battery level
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(batteryLevelDidChange(_:)),
            name: UIDevice.batteryLevelDidChangeNotification,
            object: nil
        )
        
        // Observe changes to battery state (e.g., charging, unplugged)
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(batteryStateDidChange(_:)),
            name: UIDevice.batteryStateDidChangeNotification,
            object: nil
        )
    }
    
    // MARK: - Notification handlers
    @objc private func batteryLevelDidChange(_ notification: Notification) {
        batteryLevel = UIDevice.current.batteryLevel
    }
    
    @objc private func batteryStateDidChange(_ notification: Notification) {
        batteryState = UIDevice.current.batteryState
    }
    
    // Remove observers on deinit
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: - Battery Symbol Logic
    
    /// Returns the appropriate SF Symbol name based on battery level or charging state.
    var batterySymbolName: String {
        switch batteryState {
        case .charging:
            // Show a 'battery with a bolt' icon when charging
            return "battery.100.bolt"
        default:
            // Calculate the battery level percentage
            let level = Int(batteryLevel * 100)
            switch level {
            case 0..<20:  return "battery.0"
            case 20..<40: return "battery.25"
            case 40..<60: return "battery.50"
            case 60..<80: return "battery.75"
            default:      return "battery.100"
            }
        }
    }
    
    /// Converts the battery state into a human-readable string.
    var batteryStateDescription: String {
        switch batteryState {
        case .unknown:   return "Unknown"
        case .unplugged: return "Unplugged"
        case .charging:  return "Charging"
        case .full:      return "Full"
        @unknown default: return "Unknown"
        }
    }
}

// MARK: - 2) A floating battery icon (SF Symbol) with a Menu for details
struct BatteryButton: View {
    // We observe the battery manager to show real-time updates
    @ObservedObject var batteryManager: BatteryManager
    
    var body: some View {
        // Use a Menu to display battery info when tapped
        Menu {
            // Show battery level as a percentage
            Text("Battery Level: \(Int(batteryManager.batteryLevel * 100))%")
            // Show a human-readable battery state
            Text("Battery State: \(batteryManager.batteryStateDescription)")
        } label: {
            // Label is just the SF Symbol (no background or shape)
            Image(systemName: batteryManager.batterySymbolName)
                .font(.system(size: 36)) // Adjust size as desired
                .foregroundColor(.green) // Pick a color or use .primary
        }
        // Accessibility label for assistive technologies
        .accessibilityLabel("Battery Information")
    }
}

// MARK: - 3) Main ContentView placing the button at bottom-right
struct ContentView: View {
    // We create a single instance of BatteryManager
    @StateObject private var batteryManager = BatteryManager()
    
    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            // Use a light background color to see the icon clearly
            Color.gray.opacity(0.1).ignoresSafeArea()
            
            // Place the battery button in the bottom-right corner
            BatteryButton(batteryManager: batteryManager)
                .padding(20) // Move it away from edges
        }
    }
}

// MARK: - 4) The SwiftUI App entry point
@main
struct BatteryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
