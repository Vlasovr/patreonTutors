//
//  CircleTickShape.swift
//  SwiftUI-Animations
//
//  Created by Shubham on 08/04/21.
//  Copyright © 2021 Shubham Singh. All rights reserved.
//

import SwiftUI

struct CircleTickShape: Shape {
    
    // MARK: - Properties
    var diameter: CGFloat = 60
    var tickScale: CGFloat = 0.3

    // MARK: - Functions
    func path(in rect: CGRect) -> Path {
        let centerX = rect.midX
        let centerY = rect.midY
        
        var path = Path()
        path.move(to: CGPoint(x: centerX, y: centerY))
    
        /// Circle
        path.addEllipse(in: CGRect(x: centerX - (diameter / 2), y: centerY - (diameter / 2), width: diameter, height: diameter))
        
        /// Tick
        path.move(to: CGPoint(x: centerX - (38 * tickScale), y: (centerY + 2) - tickScale))
        path.addLine(to: CGPoint(x: centerX - (tickScale * 18), y: centerY + (tickScale * 28)))
        path.addLine(to: CGPoint(x: centerX + (tickScale * 40), y: centerY - (tickScale * 26)))
        
        return path
    }
}


struct CircleTickShape_Previews: PreviewProvider {
    static var previews: some View {
        CircleTickShape(diameter: 50)
            .stroke(style: StrokeStyle(lineWidth: 4, lineCap: .round, lineJoin: .round))
    }
}
