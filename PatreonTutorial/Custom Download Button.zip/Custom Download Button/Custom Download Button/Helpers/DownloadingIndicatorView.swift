//
//  DownloadingIcon.swift
//  SwiftUI-Animations
//
//  Created by Shubham on 09/04/21.
//  Copyright © 2021 Shubham Singh. All rights reserved.
//

import SwiftUI

struct DownloadIndicatorView: View {
    
    // MARK: - Properties
    @State private var arrowYOffset: CGFloat = 0
    let animationSpeed: TimeInterval = 0.5
    let indicatorSize: CGFloat = 38
    var isAnimating: Bool = true
    
    // MARK: - Views
    var body: some View {
        ZStack {
            Circle()
                .stroke(.white, style: StrokeStyle(lineWidth: 4))
                .frame(width: indicatorSize, height: indicatorSize)
                .shadow(color: Color.black.opacity(0.25), radius: 4, y: 2)
            
            Image(systemName: "arrow.down")
                .font(.system(size: 20, weight: .heavy))
                .foregroundColor(.white)
                .offset(y: arrowYOffset)
                .mask(
                    Circle()
                        .frame(width: indicatorSize, height: indicatorSize)
                )
        }
        .onAppear {
            if isAnimating {
                withAnimation(Animation.easeIn(duration: animationSpeed)) {
                    arrowYOffset = indicatorSize
                }
                Timer.scheduledTimer(withTimeInterval: animationSpeed, repeats: true) { _ in
                    animateArrow()
                }
            }
        }
    }
    
    // MARK: - Functions
    private func animateArrow() {
        arrowYOffset = -indicatorSize
        withAnimation(Animation.easeIn(duration: animationSpeed)) {
            arrowYOffset = indicatorSize
        }
    }
}

struct DownloadingIcon_Previews: PreviewProvider {
    static var previews: some View {
        DownloadIndicatorView()
    }
}
