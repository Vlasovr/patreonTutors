//
//  Downloader.swift
//  SwiftUI-Animations
//
//  Created by Shubham on 08/04/21.
//  Copyright © 2021 Shubham Singh. All rights reserved.
//

import SwiftUI

enum DownloadStatus: CaseIterable {
    case notStarted
    case inProgress
    case completed
    
    func stateLabel() -> String {
        switch self {
        case .notStarted:
            return "Download"
        case .inProgress:
            return "Downloading"
        case .completed:
            return "Finished"
        }
    }
    
    func backgroundColor() -> Color {
        switch self {
        case .notStarted:
            return .indigo
        case .inProgress:
            return .orange
        case .completed:
            return .green
        }
    }
    
    func textOffset() -> CGFloat {
        switch self {
        case .notStarted, .completed:
            return 0
        case .inProgress:
            return 8
        }
    }
}

struct ButtonProperties {
    static let width: CGFloat = 320
    static let height: CGFloat = 76
    static let animationDuration: TimeInterval = 0.35
    static let cornerRadius: CGFloat = 25
}

class DownloadManager: ObservableObject {
    @Published var downloadStatus: DownloadStatus = .notStarted
    
    // MARK: - Initializer
    init(status: DownloadStatus = .notStarted) {
        self.downloadStatus = status
    }
}

#Preview {
    ContentView()
}
