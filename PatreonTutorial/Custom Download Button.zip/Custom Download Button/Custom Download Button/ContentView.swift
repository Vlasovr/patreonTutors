//
//  ContentView.swift
//  Custom Download Button
//
//  Created by Damra on 23.10.2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            DownloadButton()
        }
    }
}

#Preview {
    ContentView()
}
