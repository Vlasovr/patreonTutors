//
//  Custom_Download_ButtonApp.swift
//  Custom Download Button
//
//  Created by Damra on 23.10.2024.
//

import SwiftUI

@main
struct Custom_Download_ButtonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
