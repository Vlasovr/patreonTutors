//
//  DownloadStatusView.swift
//  DownloadButtonDeneme
//
//  Created by Damra on 14.09.2024.
//

import Foundation
import SwiftUI

struct DownloadStatusView: View {
    
    // MARK: - Properties
    var status: DownloadStatus = .completed
    var showProgressBar: Bool = true
    var isLightTheme: Bool = false
    
    @EnvironmentObject var downloadManager: DownloadManager
    @Binding var progressValue: CGFloat
    
    // MARK: - Views
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 0)
                .foregroundStyle(status.backgroundColor())
            
            Text(status.stateLabel())
                .foregroundColor(.white)
                .font(.system(size: 26, weight: .bold))
                .shadow(color: Color.white.opacity(0.3), radius: 5, y: 2)
                .opacity(downloadManager.downloadStatus != status ? 0 : 1)
                .offset(x: downloadManager.downloadStatus.textOffset() + 26)
                .animation(Animation.easeOut(duration: ButtonProperties.animationDuration / 2.25))
                .frame(alignment: .leading)
            
            if showProgressBar {
                Capsule(style: .circular)
                    .trim(from: 0, to: progressValue / 2)
                    .stroke(lineWidth: 8)
                    .rotationEffect(.degrees(180))
                    .foregroundColor(.white)
                    .frame(width: ButtonProperties.width, height: 12)
                    .offset(y: ButtonProperties.height / 2 + 4.5)
                    .mask(
                        RoundedRectangle(cornerRadius: ButtonProperties.cornerRadius)
                            .frame(width: 320, height: 84)
                    )
                    .opacity(downloadManager.downloadStatus != status ? 0 : 1)
                    .animation(.default)
            }
        }
        .frame(width: ButtonProperties.width, height: ButtonProperties.height)
    }
}


struct DownloadingStatesView_Previews: PreviewProvider {
    static var previews: some View {
        DownloadStatusView(progressValue: .constant(0))
            .environmentObject(DownloadManager())
    }
}
