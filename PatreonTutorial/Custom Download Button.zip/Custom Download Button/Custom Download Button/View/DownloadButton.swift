//
//  DownloadButton.swift
//  DownloadButtonDeneme
//
//  Created by Damra on 14.09.2024.
//

import Foundation
import SwiftUI

struct DownloadButton: View {
    
    // MARK: - Properties
    @StateObject var downloadManager = DownloadManager()
    
    @State private var initialYOffset: CGFloat = 0
    @State private var downloadingYOffset: CGFloat = -ButtonProperties.height
    @State private var downloadedYOffset: CGFloat = -(ButtonProperties.height * 2)
    
    @State private var progressValue: CGFloat = 0
    
    // MARK: - Views
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .center, vertical: .center)) {
            DownloadStatusView(status: .completed, isLightTheme: true, progressValue: .constant(0))
                .environmentObject(downloadManager)
                .offset(y: downloadedYOffset)
            
            DownloadStatusView(status: .inProgress, showProgressBar: true, isLightTheme: true, progressValue: $progressValue)
                .environmentObject(downloadManager)
                .offset(y: downloadingYOffset)
            
            DownloadStatusView(status: .notStarted, progressValue: .constant(0))
                .environmentObject(downloadManager)
                .offset(y: initialYOffset)
            
            ZStack {
                getSupportingIndicator()
                    .scaleEffect(0.9)
            }
            .offset(x: -ButtonProperties.width / 3.5 + 13)
            
        }
        .mask(
            RoundedRectangle(cornerRadius: ButtonProperties.cornerRadius)
                .frame(width: ButtonProperties.width, height: ButtonProperties.height)
        )
        .onTapGesture {
            initiateDownload()
        }
        .frame(width: ButtonProperties.width, height: ButtonProperties.height)
        .shadow(color: Color.background.opacity(0.4), radius: 10)
    }
    
    // MARK: - Functions
    func initiateDownload() {
        self.downloadManager.downloadStatus = .inProgress
        withAnimation(Animation.easeOut(duration: ButtonProperties.animationDuration)) {
            self.downloadedYOffset = -ButtonProperties.height + 10
            self.initialYOffset = ButtonProperties.height
            self.downloadingYOffset = 0
        }
        
        Timer.scheduledTimer(withTimeInterval: ButtonProperties.animationDuration, repeats: false) { _ in
            updateProgress()
        }
    }
    
    func updateProgress() {
        Timer.scheduledTimer(withTimeInterval: 0.15, repeats: true) { progressTimer in
            if progressValue > 1 {
                progressValue = 1
                progressTimer.invalidate()
                downloadCompleted()
            }
            // Simulating progress increment
            progressValue += 0.045
        }
    }
    
    func downloadCompleted() {
        self.downloadManager.downloadStatus = .completed
        withAnimation(Animation.easeOut(duration: ButtonProperties.animationDuration)) {
            self.downloadingYOffset = ButtonProperties.height
            self.downloadedYOffset = 0
        }
        
        Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false) { _ in
            resetButton()
        }
    }
    
    func resetButton() {
        self.initialYOffset = -ButtonProperties.height
        self.progressValue = 0
        self.downloadManager.downloadStatus = .notStarted
        withAnimation(Animation.easeOut(duration: ButtonProperties.animationDuration)) {
            self.initialYOffset = 0
        }
        
        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
            self.downloadingYOffset = -ButtonProperties.height
            self.downloadedYOffset = -(ButtonProperties.height * 2)
        }
    }
    
    @ViewBuilder func getSupportingIndicator() -> some View {
        if downloadManager.downloadStatus == .notStarted {
            DownloadIndicatorView(isAnimating: false)
                .foregroundColor(.background)
        } else if downloadManager.downloadStatus == .inProgress {
            DownloadIndicatorView()
                .offset(x: -16)
        } else {
            CircleTickShape()
                .trim(from: 0, to: progressValue == 1 ? 0 : 1)
                .stroke(style: StrokeStyle(lineWidth: 5.5, lineCap: .round, lineJoin: .round))
                .foregroundColor(.white)
                .scaleEffect(0.6)
                .opacity(downloadManager.downloadStatus == .completed ? 1 : 0)
                .offset(x: 8)
                .animation(Animation.easeInOut(duration: ButtonProperties.animationDuration * 2).delay(downloadManager.downloadStatus == .completed ? ButtonProperties.animationDuration / 4 : 0))
                .frame(width: 44, height: 44)
        }
    }
}


struct StateView_Previews: PreviewProvider {
    static var previews: some View {
        ZStack {
            Color.background
                .edgesIgnoringSafeArea(.all)
            DownloadButton()
        }
        .colorScheme(.dark)
    }
}
