//
//  ContentView.swift
//  Custom Rating View
//
//  Created by Damra on 18.10.2024.
//

import SwiftUI

struct ContentView: View {
    @State private var currentRating = 0
    @State private var currentRating2 = 0.0 // We use `Double` type since the grading is done by shifting
    var body: some View {
        VStack {
            Text("Rating View")
                .font(.title2)
                .padding()
            
            RatingView(rating: $currentRating)
            
            // Rating Information
            Text("Rating: \(currentRating) / 5")
                .font(.headline)
                .padding()
                .foregroundColor(currentRating > 0 ? .green : .gray)
            
            Divider()
            
            Text("Swipe Rating View")
                .font(.title2)
                .padding()
            
            SwipeRatingView(rating: $currentRating2)
            
            // Rating Information
            Text("Rating: \(Int(currentRating2)) / 5")
                .font(.headline)
                .padding()
                .foregroundColor(currentRating2 > 0 ? .green : .gray)
            
            Spacer()
            
        }
        .padding()
    }
}

#Preview {
    ContentView()
}

struct RatingView: View {
    @Binding var rating: Int
    var maximumRating = 5
    var onColor = Color.yellow
    var offColor = Color.gray
    var body: some View {
        HStack {
            ForEach(1 ..< maximumRating + 1, id: \.self) { number in
                Image(systemName: "star.fill")
                    .foregroundColor(number <= rating ? onColor : offColor)
                    .onTapGesture {
                        withAnimation(.interactiveSpring) {
                            rating = number
                        }
                    }
            }
        }
        .font(.largeTitle)
    }
}

struct SwipeRatingView: View {
    @Binding var rating: Double
    var maximumRating = 5
    var onColor = Color.yellow
    var offColor = Color.gray
    var body: some View {
        HStack {
            ForEach(1 ..< maximumRating + 1, id: \.self) { index in
                Image(systemName: "star.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 40, height: 40)
                    .foregroundColor(index <= Int(rating) ? onColor : offColor)
                    .onTapGesture {
                        withAnimation {
                            rating = Double(index)
                        }
                    }
            }
        }
        .gesture(
            DragGesture()
                .onChanged { value in
                    // Let's calculate the width of each star and rate it according to the user's scrolling movement
                    let starWidth = 40.0
                    let totalWidth = starWidth * Double(maximumRating)
                    let newRating = Double(value.location.x / (totalWidth / Double(maximumRating)))
                    
                    rating = max(1.0, min(newRating, Double(maximumRating)))
                }
            )
        .font(.largeTitle)
    }
}
