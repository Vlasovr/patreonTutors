//
//  Custom_Rating_ViewApp.swift
//  Custom Rating View
//
//  Created by Damra on 18.10.2024.
//

import SwiftUI

@main
struct Custom_Rating_ViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
