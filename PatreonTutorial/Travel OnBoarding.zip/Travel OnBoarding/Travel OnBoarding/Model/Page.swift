//
//  Page.swift
//  Travel OnBoarding
//
//  Created by Damra on 24.08.2024.
//

import Foundation
import SwiftUI

struct PageIntro: Identifiable, Hashable {
    var id: UUID = .init()
    var introAssetImage: String
    var title: String
    var subTitle: String
    var stateMachineName: String
    var displayAction: Bool = false
}

var pageIntros: [PageIntro] = [
    .init(introAssetImage: "1", title: "Explore the World, One Adventure at a Time.", subTitle: "Planning a trip involves researching destinations, booking accommodations, and creating an itinerary.", stateMachineName: "State Machine 1"),
    .init(introAssetImage: "2", title: "Adventure Awaits Around Every Corner.", subTitle: "Whether it's a weekend getaway or a month-long journey, traveling can be a refreshing break from everyday life.", stateMachineName: "State Machine 1"),
    .init(introAssetImage: "3", title: "Experience Life, One Destination at a Time.", subTitle: "Some travelers prefer the adventure of backpacking, while others enjoy the luxury of all-inclusive resorts.", stateMachineName: "State Machine 1", displayAction: true)
]
