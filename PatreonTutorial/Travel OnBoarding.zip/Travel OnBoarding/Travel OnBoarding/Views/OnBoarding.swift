//
//  OnBoarding.swift
//  Travel OnBoarding
//
//  Created by Damra on 24.08.2024.
//

import Foundation
import SwiftUI
import RiveRuntime

struct OnBoarding: View {
    //MARK: View Properties
    @State var activeIntro: PageIntro = pageIntros.first!
    @State var emailID: String = ""
    @State var password: String = ""
    @State var keyboardHeight: CGFloat = 0
    @AppStorage("isDone") var isDone = false
    var body: some View {
        GeometryReader {
            let size = $0.size
            
            IntroView(intro: $activeIntro, size: size) {
                VStack(spacing: 10) {
                    
                    CustomTextField(text: $emailID, hint: "Email Adress", leadingIcon: Image(systemName: "envelope"))
                    
                    CustomTextField(text: $password, hint: "Password", leadingIcon: Image(systemName: "lock"), isPassword: true)
                    
                    Spacer(minLength: 10)
                    
                    Button {
                        withAnimation {
                            isDone = true
                        }
                    } label: {
                        Text("Continue")
                            .fontWeight(.semibold)
                            .foregroundStyle(.white)
                            .padding(.vertical, 15)
                            .hAlign(.center)
                            .background(
                                Capsule()
                                    .fill(.black)
                            )
                    }
                }
            }
        }
        .padding(15)
        //manual keyboard push
        .offset(y: -keyboardHeight)
        //Disabling native. keyboard push
        .ignoresSafeArea(.keyboard, edges: .all)
        .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillShowNotification)) { output in
            if let info = output.userInfo, let height = (info[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue.height{
                keyboardHeight = height
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillHideNotification)) { _ in
            keyboardHeight = 0
        }
        .animation(.spring(response: 0.5, dampingFraction: 0.8, blendDuration: 0), value: keyboardHeight)
    }
}

#Preview {
    OnBoarding()
}
