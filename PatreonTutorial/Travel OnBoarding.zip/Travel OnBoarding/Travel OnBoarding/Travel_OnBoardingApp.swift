//
//  Travel_OnBoardingApp.swift
//  Travel OnBoarding
//
//  Created by Damra on 24.08.2024.
//

import SwiftUI

@main
struct Travel_OnBoardingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
