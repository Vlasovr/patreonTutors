//
//  CustomTextField.swift
//  Animated OnBoarding
//
//  Created by Damra on 7.06.2024.
//

import Foundation
import SwiftUI

struct CustomTextField: View {
    @Binding var text: String
    var hint: String
    var leadingIcon: Image
    var isPassword: Bool = false
    
    var body: some View {
        HStack(spacing: 0) {
            leadingIcon.font(.callout)
                .foregroundColor(.gray)
                .frame(width: 40, alignment: .leading)
            
            if isPassword {
                SecureField(hint, text: $text)
            }else {
                TextField(hint, text: $text)
            }
        }
        .padding(15)
        .background(
            RoundedRectangle(cornerRadius: 15, style: .continuous)
                .fill(.gray.opacity(0.1))
        )
    }
}
