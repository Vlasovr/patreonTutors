//
//  ContentView.swift
//  Travel OnBoarding
//
//  Created by Damra on 24.08.2024.
//

import SwiftUI
import RiveRuntime

struct ContentView: View {
    var body: some View {
        OnBoarding()
    }
}

#Preview {
    ContentView()
}
