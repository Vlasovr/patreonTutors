//
//  customanimatingactionmenuApp.swift
//  customanimatingactionmenu
//
//  Created by Altuğ Nuri ASLANTAŞ on 25.08.2024.
//

import SwiftUI

@main
struct customanimatingactionmenuApp: App {
    var body: some Scene {
        WindowGroup {
            IconMenuView()
        }
    }
}
