import SwiftUI

// Enum defining different icon actions with associated SF symbols and gradient colors
enum IconAction {
    case calendar
    case keyboard
    case camera
    case quote
    case mic
    
    // Returns the SF Symbol name for each action
    var symbolName: String {
        switch self {
        case .calendar: return "sun.max.fill"
        case .keyboard: return "pencil.circle.fill"
        case .camera: return "photo.fill"
        case .quote: return "message.fill"
        case .mic: return "speaker.wave.3.fill"
        }
    }
    
    // Returns gradient colors for each action's icon
    var gradientColors: [Color] {
        switch self {
        case .calendar: return [Color.orange, Color.red]
        case .keyboard: return [Color.purple, Color.blue]
        case .camera: return [Color.teal, Color.green]
        case .quote: return [Color.blue, Color.cyan]
        case .mic: return [Color.pink, Color.purple]
        }
    }
    
    // Function to perform the action when an icon is selected
    func perform() {
        switch self {
        case .calendar:
            print("Sun icon tapped")
        case .keyboard:
            print("Pencil icon tapped")
        case .camera:
            print("Photo icon tapped")
        case .quote:
            print("Message icon tapped")
        case .mic:
            print("Speaker icon tapped")
        }
    }
}

struct IconMenuView: View {
    // State variables to manage UI state
    @State private var isIconMenuVisible = false // Track menu visibility
    @State private var isPlusIconRotated = false // Track plus icon rotation
    @GestureState private var isPressed = false // Track long press state
    @State private var selectedIcon: IconAction? = nil // Track the selected icon
    
    // Array of action icons to display in the menu
    let actionIcons: [IconAction] = [.calendar, .keyboard, .camera, .quote, .mic]
  
    var body: some View {
        VStack {
            Spacer() // Pushes the menu to the bottom of the screen
            
            // Display selected icon and its name
            if let selectedIcon = selectedIcon {
                VStack {
                    Spacer()
                    Image(systemName: selectedIcon.symbolName)
                        .font(.system(size: 100))
                        .foregroundStyle(
                            LinearGradient(
                                gradient: Gradient(colors: selectedIcon.gradientColors),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .shadow(color: selectedIcon.gradientColors.last!.opacity(0.7), radius: 10, x: 0, y: 5)
                    Text(selectedIcon.symbolName)
                        .font(.largeTitle)
                        .foregroundStyle(
                            LinearGradient(
                                gradient: Gradient(colors: selectedIcon.gradientColors),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .bold()
                    Spacer()
                }
                // Apply spring animation to the icon and text when selected
                .animation(.spring(response: 0.5, dampingFraction: 0.6), value: selectedIcon)
            }
            
            // ZStack to hold the icon menu and plus button
            ZStack(alignment: .leading) {
                HStack {
                    // Loop through each icon action and create a button
                    ForEach(actionIcons.indices, id: \.self) { index in
                        Button(action: {
                            // Handle icon selection and perform action
                            selectedIcon = actionIcons[index]
                            actionIcons[index].perform()
                            toggleMenuVisibility()
                        }) {
                            Image(systemName: actionIcons[index].symbolName)
                                .foregroundColor(.white)
                                .frame(width: 50, height: 50)
                                .background(
                                    LinearGradient(
                                        gradient: Gradient(colors: actionIcons[index].gradientColors),
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    ), in: Circle()
                                )
                                .shadow(color: .black.opacity(0.3), radius: 10, x: 5, y: 5)
                                .overlay(
                                    Circle()
                                        .stroke(Color.white, lineWidth: 2)
                                        .shadow(color: .white.opacity(0.5), radius: 10)
                                )
                                .scaleEffect(isIconMenuVisible ? 1 : 0) // Scale in/out when menu is toggled
                                .rotation3DEffect(
                                    .degrees(isIconMenuVisible ? 0 : 180),
                                    axis: (x: 0.0, y: 1.0, z: 0.0)
                                )
                                // Apply staggered animation when icons appear/disappear
                                .animation(.spring(response: 0.3, dampingFraction: 0.7).delay(isIconMenuVisible ? Double(index) * 0.1 : Double(actionIcons.count - index - 1) * 0.1), value: isIconMenuVisible)
                        }
                    }
                }
                
                // Plus button to toggle the menu
                Image(systemName: "ellipsis.circle.fill")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.black)
                    .frame(width: 50, height: 50)
                    .background(.white, in: Circle())
                    .rotationEffect(.degrees(isPressed ? -360 : 0)) // Rotate when pressed
                    .rotationEffect(.degrees(isPlusIconRotated ? 90 : 0)) // Rotate to open/close menu
                    .scaleEffect(isPressed ? 1.5 : 1) // Scale up when pressed
                    .shadow(color: .gray.opacity(0.5), radius: isPressed ? 10 : 5, x: 0, y: 5)
                    .onTapGesture {
                        toggleMenuVisibility() // Toggle menu on tap
                    }
                    .gesture(
                        // Long press gesture to toggle menu
                        LongPressGesture(minimumDuration: 1.0, maximumDistance: 50)
                            .updating($isPressed) { currentState, gestureState, _ in
                                gestureState = currentState
                            }
                            .onEnded { _ in
                                toggleMenuVisibility()
                            }
                    )
                    // Apply spring animation to the plus button
                    .animation(.spring(response: 1.5, dampingFraction: 0.5), value: isPressed)
                    .frame(maxWidth: .infinity, alignment: .leading) // Align to the left
            }
        }
        .padding(20)
    }
    
    // Function to toggle the menu's visibility and rotate the plus icon
    private func toggleMenuVisibility() {
        withAnimation(.linear(duration: 0.4)) {
            isIconMenuVisible.toggle()
            isPlusIconRotated.toggle()
        }
    }
}

// Preview struct for testing in Xcode's canvas
struct IconMenuView_Previews: PreviewProvider {
    static var previews: some View {
        IconMenuView()
    }
}


