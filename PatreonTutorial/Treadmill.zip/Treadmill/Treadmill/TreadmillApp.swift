import SwiftUI

@main
struct TreadmillApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
