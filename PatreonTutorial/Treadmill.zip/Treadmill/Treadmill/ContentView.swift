import SwiftUI

// MARK: - ContentView

struct ContentView: View {
    // State variables to manage workout data
    @State private var isRunning = false
    @State private var speed: Double = 5.0 // km/h
    @State private var distance: Double = 0.0 // km
    @State private var duration: Int = 0 // seconds
    @State private var heartRate: Int = 80 // bpm
    @State private var calories: Int = 0 // kcal
    @State private var targetDistance: Double = 10.0 // km

    // Timer for updating metrics every second
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    // Grid layout for metric cards
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]

    var body: some View {
        NavigationView {
            VStack {
                // Header
                HStack {
                    Text("Treadmill Dashboard")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        
                    Spacer()
                    NavigationLink(destination: SettingsView(targetDistance: $targetDistance, speed: $speed)) {
                        Image(systemName: "gearshape.fill")
                            .font(.title)
                            .foregroundColor(.white)
                    }
                }
                .padding()
                .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]),
                                           startPoint: .topLeading,
                                           endPoint: .bottomTrailing))
                .cornerRadius(15)
                .padding([.horizontal, .top])

                // Metrics Overview using LazyVGrid
                LazyVGrid(columns: columns, spacing: 20) {
                    MetricCard(title: "Speed", value: "\(String(format: "%.1f", speed))", unit: "km/h", color: .red, icon: "speedometer")
                    MetricCard(title: "Distance", value: "\(String(format: "%.1f", distance))", unit: "km", color: .green, icon: "map")
                    MetricCard(title: "Duration", value: "\(duration / 60) min", unit: "min", color: .blue, icon: "clock")
                    MetricCard(title: "Heart Rate", value: "\(heartRate)", unit: "bpm", color: .pink, icon: "heart.fill")
                    MetricCard(title: "Calories", value: "\(calories)", unit: "kcal", color: .orange, icon: "flame.fill")
                }
                .padding(.horizontal)
                .padding(.top,20)

                // Circular Progress View for Distance
                VStack(spacing: 20) {
                    Text("Target Distance: \(String(format: "%.1f", targetDistance)) km")
                        .font(.headline)
                        .foregroundColor(.primary)

                    CircularProgressView(progress: distance / targetDistance, color: .yellow, lineWidth: 15)
                        .frame(width: 150, height: 150)
                        .shadow(radius: 10)
                        .overlay(
                            Text("\(String(format: "%.1f", distance)) km")
                                .font(.title2)
                                .foregroundColor(.primary)
                                .bold()
                        )
                        .animation(.easeInOut, value: distance)
                }
                .padding(.vertical, 20)

                // Control Buttons
                HStack(spacing: 50) {
                    Button(action: {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                            isRunning.toggle()
                        }
                    }) {
                        Image(systemName: isRunning ? "stop.circle.fill" : "play.circle.fill")
                            .resizable()
                            .frame(width: 70, height: 70)
                            .foregroundColor(isRunning ? .red : .green)
                            .shadow(radius: 1)
                            .scaleEffect(isRunning ? 1.2 : 1.0)
                            .animation(.easeInOut(duration: 0.2), value: isRunning)
                    }
                }
                .padding(.bottom, 40)
            }
            .onReceive(timer) { _ in
                guard isRunning else { return }
                duration += 1
                distance += speed / 3600
                calories += Int(speed * 0.1)
                heartRate = min(heartRate + Int.random(in: 0...1), 160)
            }
            .background(
                LinearGradient(gradient: Gradient(colors: [Color.gray.opacity(0.1), Color.gray.opacity(0.2)]),
                               startPoint: .top,
                               endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
            )
            .navigationBarHidden(true)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

// MARK: - MetricCard

struct MetricCard: View {
    var title: String
    var value: String
    var unit: String
    var color: Color
    var icon: String

    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: icon)
                .font(.title)
                .foregroundColor(color)
                .shadow(radius: 5)

            Text(title)
                .font(.headline)
                .foregroundColor(color)

            Text(value)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.primary)

            Text(unit)
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, minHeight: 100)
        .padding()
        .background(LinearGradient(gradient: Gradient(colors: [Color.white, Color(UIColor.systemGray6)]),
                                   startPoint: .top,
                                   endPoint: .bottom))
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
    }
}



// MARK: - CircularProgressView

struct CircularProgressView: View {
    var progress: Double // Value between 0 and 1
    var color: Color
    var lineWidth: CGFloat

    var body: some View {
        ZStack {
            Circle()
                .stroke(color.opacity(0.3), lineWidth: lineWidth)

            Circle()
                .trim(from: 0.0, to: CGFloat(min(progress, 1.0)))
                .stroke(color, style: StrokeStyle(lineWidth: lineWidth, lineCap: .round, lineJoin: .round))
                .rotationEffect(Angle(degrees: -90))
                .animation(.linear, value: progress)
        }
    }
}


// MARK: - SettingsView

struct SettingsView: View {
    @Binding var targetDistance: Double
    @Binding var speed: Double

    var body: some View {
        VStack(spacing: 30) {
            Text("Settings")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.blue)
                .padding()

            Form {
                Section(header: Text("Workout Settings").foregroundColor(.blue)) {
                    VStack(alignment: .leading) {
                        Text("Target Distance (km)")
                            .foregroundColor(.primary)
                        Slider(value: $targetDistance, in: 1...20, step: 0.5)
                            .accentColor(.yellow)
                        Text("\(String(format: "%.1f", targetDistance)) km")
                            .foregroundColor(.secondary)
                    }

                    VStack(alignment: .leading) {
                        Text("Speed (km/h)")
                            .foregroundColor(.primary)
                        Slider(value: $speed, in: 1...20, step: 0.5)
                            .accentColor(.green)
                        Text("\(String(format: "%.1f", speed)) km/h")
                            .foregroundColor(.secondary)
                    }
                }
            }
            .background(Color.white)
            .cornerRadius(15)
            .shadow(radius: 10)

            Spacer()
        }
        .padding()
        .background(
            LinearGradient(gradient: Gradient(colors: [Color.gray.opacity(0.1), Color.gray.opacity(0.2)]),
                           startPoint: .top,
                           endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
        )
        .navigationBarTitle("Settings", displayMode: .inline)
    }
}


