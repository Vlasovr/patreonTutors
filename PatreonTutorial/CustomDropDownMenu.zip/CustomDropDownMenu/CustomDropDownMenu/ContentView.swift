//
//  ContentView.swift
//  CustomDropDownMenu
//
//  Created by Altuğ Nuri ASLANTAŞ on 2.11.2024.
//

import SwiftUI

// Main view that displays a dark overlay and the custom dropdown picker
struct ContentView: View {
    @State private var selectedItem: String? = nil // State variable to hold the selected option
    var body: some View {
        ZStack {
            // Dark overlay to enhance dropdown visibility
            Color.black.opacity(0.8).edgesIgnoringSafeArea(.all)
            // Custom dropdown picker with available options
            CustomDropdownPicker(
                selectedItem: $selectedItem, // Binding to the selected item
                availableOptions: [
                    "Appstore",
                    "Xcode",
                    "SwiftUI",
                    "Objective-C",
                    "C++"
                ]
            )
        }
    }
}

// Enum to represent the position of the dropdown options (above or below the selection)
enum DropdownPosition {
    case above
    case below
}

// Custom dropdown picker view
struct CustomDropdownPicker: View {
    @Binding var selectedItem: String? // Binding to the selected item
    var position: DropdownPosition = .below // Default position of the dropdown
    var availableOptions: [String] // List of available options
    var maxWidth: CGFloat = 180 // Maximum width for the dropdown picker
    @State private var isDropdownVisible = false // State variable to control dropdown visibility
    @SceneStorage("dropdown_zIndex") private var dropdownZIndex = 1000.0 // Z-index for dropdown layering
    @State private var currentZIndex = 1000.0 // Current Z-index to control dropdown stacking order
    var body: some View {
        GeometryReader { geometry in
            let containerSize = geometry.size // Get the size of the container
            VStack(spacing: 0) {
                // Conditionally show the options list based on dropdown visibility and position
                if (position == .above && isDropdownVisible) || (position == .below && isDropdownVisible) {
                    OptionsList() // Display the options list
                }
                // Main selection view
                HStack {
                    // Display the selected item or placeholder text
                    Text(selectedItem ?? "Choose an option")
                        .foregroundColor(selectedItem != nil ? .black : .gray) // Change text color based on selection
                    Spacer() // Pushes the checkmark to the right
                    // Dropdown arrow icon
                    Image(systemName: position == .above ? "chevron.up" : "chevron.down")
                        .font(.title3)
                        .foregroundColor(.gray)
                        .rotationEffect(.degrees(isDropdownVisible ? -180 : 0)) // Rotate icon based on dropdown state
                }
                .padding(.horizontal, 15)
                .frame(height: 50) // Fixed height for the selection view
                .background(Color.white) // Background color
                .contentShape(Rectangle()) // Make the entire area tappable
                .onTapGesture {
                    dropdownZIndex += 1 // Increase z-index on tap
                    currentZIndex = dropdownZIndex // Update current z-index
                    withAnimation(.easeInOut) {
                        isDropdownVisible.toggle() // Toggle dropdown visibility with animation
                    }
                }
                .zIndex(10) // Set z-index for the selection view
            }
            .clipped() // Clip any overflowing content
            .background(Color.white) // Background color for the entire picker
            .cornerRadius(10) // Rounded corners
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray)) // Gray border
            .frame(height: containerSize.height, alignment: position == .above ? .bottom : .top) // Position based on state
        }
        .frame(width: maxWidth, height: 50) // Set fixed width and height for the dropdown
        .zIndex(currentZIndex) // Apply z-index to manage stacking
    }
    
    // View for displaying the list of options
    private func OptionsList() -> some View {
        VStack(spacing: 0) {
            // Iterate over available options and create a row for each
            ForEach(availableOptions, id: \.self) { option in
                HStack {
                    Text(option) // Display the option text
                    Spacer() // Push the checkmark to the right
                    Image(systemName: "checkmark")
                        .opacity(selectedItem == option ? 1 : 0) // Show checkmark if the option is selected
                }
                .foregroundStyle(selectedItem == option ? Color.primary : Color.gray) // Change text color based on selection
                .frame(height: 40) // Fixed height for each option
                .contentShape(Rectangle()) // Make the entire area tappable
                .padding(.horizontal, 15) // Padding for the options
                .onTapGesture {
                    withAnimation(.easeInOut) {
                        selectedItem = option // Set the selected option
                        isDropdownVisible.toggle() // Close the dropdown
                    }
                }
            }
        }
        .transition(.move(edge: position == .above ? .bottom : .top)) // Transition animation based on position
        .zIndex(1) // Set z-index for the options list
    }
}

#Preview {
    ContentView() // Preview of the ContentView view
} 
