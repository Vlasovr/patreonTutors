//
//  CustomDropDownMenuApp.swift
//  CustomDropDownMenu
//
//  Created by Altuğ Nuri ASLANTAŞ on 2.11.2024.
//

import SwiftUI

@main
struct CustomDropDownMenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
