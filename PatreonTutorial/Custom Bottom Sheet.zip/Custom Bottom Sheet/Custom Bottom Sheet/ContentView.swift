//
//  ContentView.swift
//  Custom Bottom Sheet
//
//  Created by Damra on 15.10.2024.
//

import SwiftUI

struct ContentView: View {
    @State private var isBottomSheetOpen = false
    var body: some View {
        ZStack {
            LinearGradient(colors: [.cyan, .indigo], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
            // Main View
            VStack {
                Text("Main Content")
                    .font(.largeTitle)
                    .foregroundStyle(.white)
                    .padding()
                Button(action: {
                    withAnimation {
                        self.isBottomSheetOpen.toggle()
                    }
                }) {
                    Text("Open Bottom Sheet")
                        .padding()
                        .background(Color.white)
                        .foregroundColor(.blue)
                        .cornerRadius(8)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.gray.opacity(0.1))
            
            // Bottom Page
            BottomSheetView(isOpen: $isBottomSheetOpen, maxHeight: 400) {
                VStack {
                    Text("SwiftUICodes")
                        .font(.headline)
                        .padding()
                    Divider()
                    Text("This field can be used to show content such as additional information or settings.")
                        .padding()
                }
            }
            .edgesIgnoringSafeArea(.all)
        }
    }
}

#Preview {
    ContentView()
}

struct BottomSheetView<Content: View>: View {
    @Binding var isOpen: Bool
    let maxHeight: CGFloat
    let minHeight: CGFloat
    let content: Content
    
    @GestureState private var translation: CGFloat = 0
    
    private var offset: CGFloat {
        isOpen ? 0 : (maxHeight - minHeight)
    }
    
    private var indicator: some View {
        RoundedRectangle(cornerRadius: 10)
            .fill(Color.gray.opacity(0.3))
            .frame(
                width: 40,
                height: 6
            ).padding(5)
    }
    
    init(isOpen: Binding<Bool>, maxHeight: CGFloat, @ViewBuilder content: () -> Content) {
        self._isOpen = isOpen
        self.maxHeight = maxHeight
        self.minHeight = 100
        self.content = content()
    }
    
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                self.indicator
                self.content
            }.padding(.top, 10)
                .frame(width: geometry.size.width, height: self.maxHeight, alignment: .top)
                .background(Color(.systemBackground))
                .cornerRadius(20)
                .frame(height: geometry.size.height, alignment: .bottom)
                .offset(y: max(self.offset + self.translation, 0))
                .animation(.bouncy(), value: isOpen)
                .gesture(
                    DragGesture().updating(self.$translation) { value, state, _ in
                        state = value.translation.height
                    }
                        .onEnded { value in
                            let snapDistance = self.maxHeight * 0.25
                            guard abs(value.translation.height) > snapDistance else {
                                return
                            }
                            self.isOpen = value.translation.height < 0
                        }
                    )
        }
    }
}
