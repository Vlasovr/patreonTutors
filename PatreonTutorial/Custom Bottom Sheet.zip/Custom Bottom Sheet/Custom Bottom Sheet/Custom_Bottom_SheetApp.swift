//
//  Custom_Bottom_SheetApp.swift
//  Custom Bottom Sheet
//
//  Created by Damra on 15.10.2024.
//

import SwiftUI

@main
struct Custom_Bottom_SheetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
