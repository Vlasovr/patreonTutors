import SwiftUI
import Combine

// MARK: - 1) Photo Model
struct Photo: Identifiable, Equatable, Codable {
    let id: Int
    let title: String
    let description: String
    let url: URL
    var isFavorite: Bool
    
    init(id: Int, title: String, description: String, url: URL, isFavorite: Bool = false) {
        self.id = id
        self.title = title
        self.description = description
        self.url = url
        self.isFavorite = isFavorite
    }
}

// MARK: - 2) ViewModel to Manage Photos
class PhotoViewModel: ObservableObject {
    @Published var photos: [Photo] = []
    @Published var searchText: String = ""
    @Published var sortOption: SortOption = .id
    @Published var showOnlyFavorites: Bool = false
    @Published var isGridLayout: Bool = true  // (3) Switch between list/grid
    private let favoritesKey = "favoritePhotos"
    
    enum SortOption: String, CaseIterable {
        case id = "Sort by ID"
        case title = "Sort by Title"
    }
    
    init() {
        loadInitialData()
    }
    
    func loadInitialData() {
        // Generate 10 sample photos from Picsum using IDs 21...30
        var initialPhotos: [Photo] = []
        for i in 21...30 {
            if let url = URL(string: "https://picsum.photos/id/\(i)/300/300") {
                let photo = Photo(
                    id: i,
                    title: "Photo #\(i)",
                    description: "This is a sample description for photo #\(i). Tap to read more!",
                    url: url
                )
                initialPhotos.append(photo)
            }
        }
        
        // Attempt to load saved favorites from UserDefaults
        let savedFavorites = loadFavorites()
        if !savedFavorites.isEmpty {
            self.photos = initialPhotos.map { photo in
                var mutablePhoto = photo
                if savedFavorites.contains(photo.id) {
                    mutablePhoto.isFavorite = true
                }
                return mutablePhoto
            }
        } else {
            self.photos = initialPhotos
        }
        
        sortPhotos()
    }
    
    func refresh() {
        photos.shuffle()
        sortPhotos()
    }
    
    // Toggle favorite status with haptic feedback
    func toggleFavorite(for photo: Photo) {
        if let index = photos.firstIndex(of: photo) {
            photos[index].isFavorite.toggle()
            let generator = UIImpactFeedbackGenerator(style: .light)
            generator.impactOccurred()
            saveFavorites()
        }
    }
    
    // Sort by ID or Title
    func sortPhotos() {
        switch sortOption {
        case .id:
            photos.sort { $0.id < $1.id }
        case .title:
            photos.sort { $0.title < $1.title }
        }
    }
    
    // Save favorites to UserDefaults
    private func saveFavorites() {
        let favoriteIDs = photos.filter { $0.isFavorite }.map { $0.id }
        UserDefaults.standard.set(favoriteIDs, forKey: favoritesKey)
    }
    
    // Load favorites from UserDefaults
    private func loadFavorites() -> [Int] {
        UserDefaults.standard.array(forKey: favoritesKey) as? [Int] ?? []
    }
    
    // Filtered array based on search text & favorites toggle
    var filteredPhotos: [Photo] {
        let searchFiltered: [Photo]
        if searchText.isEmpty {
            searchFiltered = photos
        } else {
            searchFiltered = photos.filter { photo in
                photo.title.lowercased().contains(searchText.lowercased()) ||
                photo.description.lowercased().contains(searchText.lowercased())
            }
        }
        if showOnlyFavorites {
            return searchFiltered.filter { $0.isFavorite }
        } else {
            return searchFiltered
        }
    }
}

// MARK: - 3) Main App Entry
@main
struct MultipleImageViewerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

// MARK: - 4) Main ContentView
struct ContentView: View {
    @StateObject private var viewModel = PhotoViewModel()
    
    var body: some View {
        NavigationView {
            ZStack {
                // (1) Off-white background
                Color(uiColor: .systemGray6)
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Sorting + layout toggle
                    layoutAndSortBar
                    
                    // Photo display area (list or grid)
                    if viewModel.isGridLayout {
                        photoGrid
                    } else {
                        photoList
                    }
                }
                .navigationTitle("Multiple Image Viewer")
                .toolbar {
                    // (1) Show-Only-Favorites Toggle
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button {
                            withAnimation {
                                viewModel.showOnlyFavorites.toggle()
                            }
                        } label: {
                            Image(systemName: viewModel.showOnlyFavorites ? "star.fill" : "star")
                                .foregroundColor(viewModel.showOnlyFavorites ? .yellow : .primary)
                        }
                    }
                }
            }
            .searchable(text: $viewModel.searchText, prompt: "Search Photos")
        }
    }
    
    // MARK: - Layout and Sort Bar
    private var layoutAndSortBar: some View {
        HStack {
            Picker("Sort", selection: $viewModel.sortOption) {
                ForEach(PhotoViewModel.SortOption.allCases, id: \.self) { option in
                    Text(option.rawValue)
                }
            }
            .pickerStyle(.segmented)
            .onChange(of: viewModel.sortOption) { _ in
                withAnimation {
                    viewModel.sortPhotos()
                }
            }
            
            Spacer()
            
            // (3) Switch Between List or Grid Layout
            Button {
                withAnimation {
                    viewModel.isGridLayout.toggle()
                }
            } label: {
                Image(systemName: viewModel.isGridLayout ? "list.bullet" : "rectangle.grid.2x2")
                    .font(.headline)
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 6)
        .background(Color(uiColor: .systemGray5))
    }
    
    // MARK: - Photo Grid
    private var photoGrid: some View {
        ScrollView {
            // Adaptive grid for different device sizes
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 160))], spacing: 16) {
                ForEach(viewModel.filteredPhotos) { photo in
                    // (6) Swipe actions for favorite/share on iOS 15+
                    PhotoCardView(photo: photo, toggleFavorite: {
                        viewModel.toggleFavorite(for: photo)
                    })
                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                        Button {
                            viewModel.toggleFavorite(for: photo)
                        } label: {
                            Label("Favorite", systemImage: photo.isFavorite ? "star.fill" : "star")
                        }
                        .tint(.yellow)
                        
                        Button {
                            sharePhoto(photo: photo)
                        } label: {
                            Label("Share", systemImage: "square.and.arrow.up")
                        }
                        .tint(.blue)
                    }
                    .onTapGesture {
                        showDetail(photo: photo)
                    }
                }
            }
            .padding()
        }
        .refreshable {
            viewModel.refresh()
        }
    }
    
    // MARK: - Photo List
    private var photoList: some View {
        List {
            ForEach(viewModel.filteredPhotos) { photo in
                HStack {
                    AsyncImage(url: photo.url, transaction: Transaction(animation: .easeInOut)) { phase in
                        switch phase {
                        case .empty:
                            ProgressView()
                                .frame(width: 60, height: 60)
                        case .success(let image):
                            image
                                .resizable()
                                .scaledToFill()
                                .frame(width: 60, height: 60)
                                .clipped()
                        case .failure:
                            // (7) Offline caching placeholder
                            Image(systemName: "photo")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 40, height: 40)
                                .foregroundColor(.gray)
                        @unknown default:
                            EmptyView()
                        }
                    }
                    .cornerRadius(8)
                    
                    VStack(alignment: .leading) {
                        Text(photo.title)
                            .font(.headline)
                        if photo.isFavorite {
                            Text("Favorited")
                                .font(.caption)
                                .foregroundColor(.yellow)
                        }
                    }
                    Spacer()
                    
                    Button {
                        viewModel.toggleFavorite(for: photo)
                    } label: {
                        Image(systemName: photo.isFavorite ? "star.fill" : "star")
                            .foregroundColor(photo.isFavorite ? .yellow : .gray)
                    }
                }
                .contentShape(Rectangle())
                .onTapGesture {
                    showDetail(photo: photo)
                }
            }
        }
        .listStyle(.insetGrouped)
        .refreshable {
            viewModel.refresh()
        }
    }
    
    // Present detail in a modal or sheet
    private func showDetail(photo: Photo) {
        let detailView = DetailView(photo: photo)
        let hostingController = UIHostingController(rootView: detailView)
        hostingController.modalPresentationStyle = .overFullScreen
        
        UIApplication.shared.windows.first?.rootViewController?.present(
            hostingController,
            animated: true,
            completion: nil
        )
    }
    
    // Simple share action
    private func sharePhoto(photo: Photo) {
        let activityVC = UIActivityViewController(activityItems: [photo.url], applicationActivities: nil)
        UIApplication.shared.windows.first?.rootViewController?.present(activityVC, animated: true)
    }
}

// MARK: - 5) Photo Card View
struct PhotoCardView: View {
    let photo: Photo
    let toggleFavorite: () -> Void
    
    var body: some View {
        VStack {
            AsyncImage(url: photo.url, transaction: Transaction(animation: .spring())) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                        .frame(height: 120)
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFill()
                        .frame(height: 120)
                        .clipped()
                case .failure:
                    Image(systemName: "exclamationmark.triangle")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 60)
                        .foregroundColor(.red)
                @unknown default:
                    EmptyView()
                }
            }
            
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(photo.title)
                        .font(.headline)
                }
                Spacer()
                Button(action: toggleFavorite) {
                    Image(systemName: photo.isFavorite ? "star.fill" : "star")
                        .foregroundColor(photo.isFavorite ? .yellow : .gray)
                }
                .buttonStyle(.borderless)
            }
            .padding(.horizontal, 8)
            .padding(.bottom, 8)
        }
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(Color(uiColor: .systemBackground))
                .shadow(color: .black.opacity(0.1), radius: 4, x: 0, y: 2)
        )
        .padding(.horizontal, 4)
        .padding(.vertical, 4)
    }
}

// MARK: - 6) Detail View (Expandable Description & Pinch-to-Zoom)
struct DetailView: View {
    let photo: Photo
    @Environment(\.presentationMode) var presentationMode
    @State private var isExpanded: Bool = false       // (4) Expandable Descriptions
    @State private var scale: CGFloat = 1.0           // (5) Pinch-to-Zoom
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.65)
                .ignoresSafeArea()
            
            VStack(spacing: 16) {
                Spacer()
                
                // Image with pinch-to-zoom gesture
                AsyncImage(url: photo.url) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                            .frame(width: 200, height: 200)
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFit()
                            .scaleEffect(scale)
                            .gesture(MagnificationGesture()
                                .onChanged { value in
                                    scale = value
                                }
                                .onEnded { _ in
                                    withAnimation {
                                        // Snap back or keep final scale
                                        // For a simpler approach, we keep the final scale
                                    }
                                }
                            )
                            .frame(height: 300)
                    case .failure:
                        Image(systemName: "exclamationmark.triangle")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 80)
                            .foregroundColor(.red)
                    @unknown default:
                        EmptyView()
                    }
                }
                
                Text(photo.title)
                    .font(.title2)
                    .foregroundColor(.white)
                
                // Expandable description
                VStack {
                    Text(photo.description)
                        .foregroundColor(.white.opacity(0.9))
                        .lineLimit(isExpanded ? nil : 2)
                        .onTapGesture {
                            withAnimation {
                                isExpanded.toggle()
                            }
                        }
                    if !isExpanded {
                        Text("Tap to read more...")
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.7))
                    }
                }
                .padding(.horizontal, 16)
                
                Spacer()
                
                // Close button
                Button("Close") {
                    presentationMode.wrappedValue.dismiss()
                }
                .font(.headline)
                .foregroundColor(.white)
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.red.opacity(0.8))
                )
                .padding(.bottom, 30)
            }
            .padding()
        }
    }
}
