//
//  ContentView.swift
//  Animated Custom Tabbar
//
//  Created by Damra on 7.06.2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabbarView()
    }
}

#Preview {
    ContentView()
}
