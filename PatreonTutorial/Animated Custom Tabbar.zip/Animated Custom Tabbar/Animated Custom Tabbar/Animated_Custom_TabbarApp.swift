//
//  Animated_Custom_TabbarApp.swift
//  Animated Custom Tabbar
//
//  Created by Damra on 7.06.2024.
//

import SwiftUI

@main
struct Animated_Custom_TabbarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
