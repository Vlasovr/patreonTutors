//
//  TabView.swift
//  Animated Custom Tabbar
//
//  Created by Damra on 7.06.2024.
//

import Foundation
import SwiftUI

enum Tab: String, CaseIterable {
    case home = "Home"
    case message = "Message"
    case analysis = "Analysis"
    case activity = "Activity"
    
    var systemImage: String {
        switch self {
        case .home:
            return "house"
        case .message:
            return "envelope.open.badge.clock"
        case .analysis:
            return "chart.bar.xaxis.ascending"
        case .activity:
            return "figure.run"
        }
    }
    
    var index: Int {
        return Tab.allCases.firstIndex(of: self) ?? 0
    }
}
