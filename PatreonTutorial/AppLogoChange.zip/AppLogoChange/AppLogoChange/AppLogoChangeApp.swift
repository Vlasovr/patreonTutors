//
//  AppLogoChangeApp.swift
//  AppLogoChange
//
//  Created by Selçuk Aslantas on 5.09.2024.
//

import SwiftUI

@main
struct AppLogoChangeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(IconNames())
        }
    }
}
