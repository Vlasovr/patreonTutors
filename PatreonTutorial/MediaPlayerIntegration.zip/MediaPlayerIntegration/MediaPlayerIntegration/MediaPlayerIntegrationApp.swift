//
//  MediaPlayerIntegrationApp.swift
//  MediaPlayerIntegration
//
//  Created by Damra on 11.11.2024.
//

import SwiftUI

@main
struct MediaPlayerIntegrationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
