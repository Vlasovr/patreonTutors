//
//  CarouselCardView.swift
//  MediaPlayerIntegration
//
//  Created by Damra on 11.11.2024.
//

import SwiftUI

struct CarouselCardView: View {
    let songs = ["Good For You", "Señorita", "Worth It", "Perfect", "Nevermind"] // Example title
    let artist = ["Selena Gomez", "Camila Cabello & Shawn Mendes", "Fifth Harmony", "Ed Sheeran", "Dennis Lloyd"] // Example subtitle
    @State private var selectedIndex = 0

    @AppStorage("currentSongIndex") var currentSongIndex: Int = 0 // To track the current song

    var body: some View {
        VStack {
            CardView(imageName: artist[currentSongIndex], itemName: songs[currentSongIndex])
                .frame(height: 300) // Adjust size as needed
                .tag(currentSongIndex)

            // Optional: Displaying current item number
            Text(songs[currentSongIndex])
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.white)
            Text(artist[currentSongIndex])
                .font(.subheadline)
                .foregroundColor(.black.opacity(0.4))
        }
        
        /*VStack {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    ForEach(songs.indices, id: \.self) { index in
                        VStack {
                            CardView(imageName: artist[index], itemName: songs[index])
                                .frame(height: 300) // Adjust size as needed
                                .tag(index)

                            // Optional: Displaying current item number
                            Text(songs[index])
                                .font(.title)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                            Text(artist[index])
                                .font(.subheadline)
                                .foregroundColor(.black.opacity(0.4))
                        }
                    }
                }.scrollTargetLayout()
            }
            .contentMargins(.horizontal, 32)
            .scrollTargetBehavior(.paging)
            .padding(.horizontal, 20)
        }*/
    }
}
