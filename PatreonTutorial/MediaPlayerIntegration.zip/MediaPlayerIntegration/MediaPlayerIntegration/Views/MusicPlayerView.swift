//
//  MusicPlayerView.swift
//  MediaPlayerIntegration
//
//  Created by Damra on 11.11.2024.
//

import SwiftUI
import AVFoundation

let songsURL = ["goodforyou", "senorita", "worthit", "perfect", "nevermind"]

struct MusicPlayerView: View {
    @State private var currentTime: Double = 0
    @State private var totalTime: Double = 236
    @State private var isPlaying: Bool = false
    @State private var audioPlayer: AVAudioPlayer?
    @State private var timer: Timer?

    @AppStorage("currentSongIndex") var currentSongIndex: Int = 0 // To track the current song

    // let songURL = Bundle.main.url(forResource: "Evolving Energetic Orchestra", withExtension: "wav")! // Replace with your song's name and extension

    var body: some View {
        ZStack {
            Image("image4").resizable().ignoresSafeArea()
            RoundedRectangle(cornerRadius: 25)
                .fill(Color.clear)
                .background(
                    TransparentBlurView(removeFilters: true)
                        .blur(radius: 25, opaque: true)
                        .background(Color.white.opacity(0.05))
                )
                .clipShape(.rect(cornerRadius: 25, style: .continuous))
                .background(
                    RoundedRectangle(cornerRadius: 25, style: .continuous)
                        .stroke(.white.opacity(0.3), lineWidth: 1.5)
                )
                .shadow(color: .black.opacity(0.4), radius: 10)
                .ignoresSafeArea()
            VStack {
                // Playlist Title
                Text("Best Vibes of the Week")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.top, 20)

                // Song Cover Image & Song Title and Artist
                CarouselCardView()
                    .transition(.move(edge: .leading))
                    .animation(.easeInOut)
                    .padding([.top, .bottom])

                Slider(value: $currentTime, in: 0 ... totalTime, step: 1)
                    .accentColor(.black.opacity(0.5))
                    .padding(.horizontal)

                // Progress Bar and Times
                HStack {
                    Text(formatTime(time: currentTime))
                        .font(.caption)
                        .foregroundColor(.black.opacity(0.5))

                    Spacer()

                    Text(formatTime(time: totalTime))
                        .font(.caption)
                        .foregroundColor(.black.opacity(0.5))
                }
                .padding(.horizontal)

                // Control Buttons
                HStack {
                    Button(action: {
                        skipBackward()
                    }) {
                        Image(systemName: "15.arrow.trianglehead.counterclockwise")
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding()
                    }

                    Button(action: {
                        withAnimation(.bouncy) {
                            skipToPreviousSong()
                        }
                    }) {
                        Image(systemName: "backward.fill")
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding()
                    }

                    Button(action: {
                        togglePlayPause()
                    }) {
                        ZStack {
                            Circle()
                                .fill(.white.opacity(0.3))
                                .frame(width: 85, height: 85)

                            Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                                .font(.system(size: 60))
                                .foregroundColor(.white)
                                .padding()
                        }
                    }

                    Button(action: {
                        skipToNextSong()
                    }) {
                        Image(systemName: "forward.fill")
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding()
                    }

                    Button(action: {
                        skipForward()
                    }) {
                        Image(systemName: "15.arrow.trianglehead.clockwise")
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding()
                    }
                }
                .padding(.top, 30)

                // Bottom Controls (Bookmark, Shuffle, More)
                HStack {
                    Button(action: {}) {
                        Image(systemName: "bookmark")
                            .font(.title2)
                            .foregroundColor(.white)
                            .imageScale(.large)
                    }
                    Spacer()
                    Button(action: {}) {
                        Image(systemName: "repeat")
                            .font(.title2)
                            .foregroundColor(.white)
                            .imageScale(.large)
                    }
                    Spacer()
                    Button(action: {}) {
                        Image(systemName: "shuffle")
                            .font(.title2)
                            .foregroundColor(.white)
                            .imageScale(.large)
                    }
                    Spacer()
                    Button(action: {}) {
                        Image(systemName: "text.badge.plus")
                            .font(.title2)
                            .foregroundColor(.white)
                            .imageScale(.large)
                    }
                }
                .padding(.top, 20)
                .padding(.horizontal, 30)
            }
            .padding()
        }
        .onAppear {
            setupAudioPlayer()
        }
        .onDisappear {
            stopAudio()
        }
        .onChange(of: audioPlayer?.isPlaying) { _ in
            startTimer()
        }
    }

    // Helper function to format time
    func formatTime(time: Double) -> String {
        let minutes = Int(time) / 60
        let seconds = Int(time) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }

    // Setup Audio Player
    func setupAudioPlayer() {
        guard let songURL = Bundle.main.url(forResource: songsURL[currentSongIndex], withExtension: "mp3") else {
            print("Error: Song file not found")
            return
        }

        do {
            audioPlayer = try AVAudioPlayer(contentsOf: songURL)
            audioPlayer?.prepareToPlay()
            totalTime = audioPlayer?.duration ?? 0
            // audioPlayer?.delegate = self
        } catch {
            print("Error loading audio file")
        }
    }

    // Start Timer to update current time of the song
    func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            guard let player = audioPlayer else { return }
            currentTime = player.currentTime
        }
    }

    // Toggle Play/Pause
    func togglePlayPause() {
        guard let player = audioPlayer else { return }
        if isPlaying {
            player.pause()
        } else {
            player.play()
        }
        isPlaying.toggle()
    }

    // Skip Forward
    func skipForward() {
        guard let player = audioPlayer else { return }
        let newTime = min(player.currentTime + 15, totalTime)
        player.currentTime = newTime
        currentTime = newTime
    }

    // Skip Backward
    func skipBackward() {
        guard let player = audioPlayer else { return }
        let newTime = max(player.currentTime - 15, 0)
        player.currentTime = newTime
        currentTime = newTime
    }

    // Skip to Next Song
    func skipToNextSong() {
        Task {
            togglePlayPause() // Play the next song
            stopAudio()
            currentSongIndex = (currentSongIndex + 1) % songsURL.count // Loop back to the first song when reaching the end
            setupAudioPlayer()
            togglePlayPause() // Play the next song
        }
    }

    // Skip to Previous Song
    func skipToPreviousSong() {
        Task {
            togglePlayPause() // Play the previous song
            stopAudio()
            currentSongIndex = (currentSongIndex - 1 + songsURL.count) % songsURL.count // Loop back to the last song when going backward
            setupAudioPlayer()
            togglePlayPause() // Play the previous song
        }
    }

    // Stop Audio
    func stopAudio() {
        audioPlayer?.stop()
        audioPlayer = nil
    }
}
