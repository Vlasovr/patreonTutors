//
//  ScrollPaginationApp.swift
//  ScrollPagination
//
//  Created by Damra on 16.07.2024.
//

import SwiftUI

@main
struct ScrollPaginationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
