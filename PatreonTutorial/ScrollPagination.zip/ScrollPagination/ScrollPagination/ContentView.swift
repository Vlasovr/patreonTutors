//
//  ContentView.swift
//  ScrollPagination
//
//  Created by Damra on 16.07.2024.
//

import SwiftUI

let animals = [
    Animal(image: .animal1),
    Animal(image: .animal2),
    Animal(image: .animal3),
    Animal(image: .animal4),
    Animal(image: .animal5)
]

struct ContentView: View {
    var body: some View {
        NavigationStack {
            List {
                NavigationLink(destination: ScrollPagination()) {
                    Text("Scroll Pagination")
                }
                NavigationLink(destination: ScrollRotationEffect()) {
                    Text("Scroll Rotation Effect")
                }
                NavigationLink(destination: ScrollParallaxEffect()) {
                    Text("Scroll Parallax Effect")
                }
                NavigationLink(destination: ScrollHueRotationEffect()) {
                    Text("Scroll Hue Rotation Effect")
                }
            }
        }
    }
}

#Preview {
    ContentView()
}

struct ScrollPagination: View {
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack(spacing: 22) {
                ForEach(animals, id: \.self) { animal in
                    AnimalPhoto(image: animal.image.rawValue).cornerRadius(25)
                }
            }.scrollTargetLayout()
        }
        .contentMargins(.horizontal, 42)
        .scrollTargetBehavior(.paging)
    }
}

struct ScrollRotationEffect: View {
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack(spacing: 16) {
                ForEach(animals, id: \.self) { items in
                    VStack(spacing: 8) {
                        ZStack {
                            AnimalPhoto(image: items.image.rawValue).cornerRadius(25)
                                .scrollTransition(axis: .horizontal) { content, phase in
                                    content
                                        .rotationEffect(.degrees(phase.value * 2.5))
                                        .offset(y: phase.isIdentity ? 0 : 8)
                                }
                        }
                        .containerRelativeFrame(.horizontal)
                        .clipShape(RoundedRectangle(cornerRadius: 25))
                    }
                }
            }.scrollTargetLayout()
        }
        .contentMargins(.horizontal, 32)
        .scrollTargetBehavior(.paging)
    }
}

struct ScrollParallaxEffect: View {
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack(spacing: 16) {
                ForEach(animals, id: \.self) { items in
                    VStack(spacing: 8) {
                        ZStack {
                            AnimalPhoto(image: items.image.rawValue).cornerRadius(25)
                                .scrollTransition(axis: .horizontal) { content, phase in
                                    return content
                                        .offset(x: phase.value * -250)
                                }
                        }
                        .containerRelativeFrame(.horizontal)
                        .clipShape(RoundedRectangle(cornerRadius: 25))
                    }
                }.scrollTargetLayout()
            }
        }
        .contentMargins(.horizontal, 32)
        .scrollTargetBehavior(.paging)
    }
}

struct ScrollHueRotationEffect: View {
    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            ForEach(0..<25, id: \.self) { items in
                ZStack {
                    RoundedRectangle(cornerRadius: 25)
                        .fill(.purple)
                        .frame(height: 80)
                        .visualEffect({ content, proxy in
                            content
                                .hueRotation(Angle(degrees: proxy.frame(in: .global).origin.y / 10))
                        })
                    
                    Text("Index \(items)")
                    
                }
            }.padding(.horizontal)
        }
    }
}

struct AnimalPhoto: View {
    var image: String
    var body: some View {
        Image(image)
            .resizable()
            .scaledToFit()
            .frame(height: 550)
    }
}

struct Animal: Identifiable, Hashable {
    var id = UUID()
    var image: animalImage
    
    init(id: UUID = UUID(), image: animalImage) {
        self.id = id
        self.image = image
    }
}

enum animalImage: String, CaseIterable {
    case animal1 = "animal1"
    case animal2 = "animal2"
    case animal3 = "animal3"
    case animal4 = "animal4"
    case animal5 = "animal5"
    
    var displayName: String {
        switch self {
        case .animal1:
            return "Animal 1"
        case .animal2:
            return "Animal 2"
        case .animal3:
            return "Animal 3"
        case .animal4:
            return "Animal 4"
        case .animal5:
            return "Animal 5"
        }
    }
    
}
