import SwiftUI
import StoreKit

struct ContentView: View {
    // Track the app usage count with @AppStorage to persist data between launches
    @AppStorage("appUsageCount") private var appUsageCount = 0
    @State private var showRatingPrompt = false
    
    var body: some View {
        VStack(spacing: 40) {
            // App Title
            Text("Welcome to RateMyApp")
                .font(.largeTitle)
                .fontWeight(.heavy)
                .foregroundColor(.purple)
                .multilineTextAlignment(.center)
                .padding(.top, 50)
            
            // Informative text encouraging the user to rate the app
            Text("Please Rate My App")
                .font(.body)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 30)
            
            // Button to simulate app usage
            Button(action: {
                incrementUsageCount()
            }) {
                Text("Use the App")
                    .font(.title2)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(15)
                    .shadow(radius: 5)
            }
            
            // Button to manually request a rating
            Button(action: {
                requestAppStoreReview()
            }) {
                Text("Rate the App")
                    .font(.title2)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.orange)
                    .cornerRadius(15)
                    .shadow(radius: 5)
            }
            
            Spacer()
        }
        .padding()
        .onAppear {
            // Increment usage count when the view appears
            incrementUsageCount()
        }
    }
    
    // Increment usage count and request review after a threshold is reached
    private func incrementUsageCount() {
        appUsageCount += 1
        print("App Usage Count: \(appUsageCount)")
        
        // Check if the app usage count reaches the threshold (e.g., 5 uses)
        if appUsageCount >= 5 {
            showRatingPrompt = true
            requestAppStoreReview()
            appUsageCount = 0  // Reset the counter after requesting the review
        }
    }
    
    // Request a rating using StoreKit
    private func requestAppStoreReview() {
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
            SKStoreReviewController.requestReview(in: windowScene)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
