import SwiftUI

@main
struct ratemyappApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
