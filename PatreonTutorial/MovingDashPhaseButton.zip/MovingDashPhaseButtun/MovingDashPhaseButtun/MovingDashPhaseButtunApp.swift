//
//  MovingDashPhaseButtunApp.swift
//  MovingDashPhaseButtun
//
//  Created by Damra on 28.08.2024.
//

import SwiftUI

@main
struct MovingDashPhaseButtunApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
