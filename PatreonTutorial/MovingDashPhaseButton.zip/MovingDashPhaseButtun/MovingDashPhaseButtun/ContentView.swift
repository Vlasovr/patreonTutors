//
//  ContentView.swift
//  MovingDashPhaseButtun
//
//  Created by Damra on 28.08.2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        MovingDashPhaseButtun()
    }
}

#Preview {
    ContentView()
}

struct MovingDashPhaseButtun: View {
    @State private var isMoving = false
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 27)
                .frame(width: 160, height: 54)
                .foregroundStyle(.indigo.gradient)
            RoundedRectangle(cornerRadius: 27)
                .strokeBorder(style: StrokeStyle(lineWidth: 5, lineCap: .round, lineJoin: .round, dash: [40, 400], dashPhase: isMoving ? 220 : -220))
                .frame(width: 160, height: 54)
                .foregroundStyle(
                    LinearGradient(gradient: Gradient(colors: [.orange, .yellow, .green, .blue, .white, .red, .cyan]), startPoint: .trailing, endPoint: .leading)
                )
            
            Button("Get Started") {
                // Button action goes here
                // No changes needed in the Button action
            }
            .foregroundColor(.white)
        }
        .onAppear {
            // Infinite loop animation without any delay or pause
            withAnimation(Animation.linear(duration: 3).repeatForever(autoreverses: false)) {
                isMoving.toggle()
            }
        }
    }
}
