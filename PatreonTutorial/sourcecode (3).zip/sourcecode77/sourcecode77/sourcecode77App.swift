//
//  sourcecode77App.swift
//  sourcecode77
//
//  Created by M.Damra on 21.02.2025.
//

import SwiftUI

@main
struct sourcecode77App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
