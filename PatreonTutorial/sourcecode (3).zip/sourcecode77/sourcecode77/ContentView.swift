//
//  ContentView.swift
//  sourcecode77
//
//  Created by M.Damra on 21.02.2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        GlassEffect()
    }
}

#Preview {
    ContentView()
}

struct GlassEffect: View {
    @State private var hueRotation = false
    var body: some View {
        RoundedRectangle(cornerRadius: 25)
            .fill(.ultraThinMaterial)
            .frame(width: 300, height: 200)
            .background(
                RoundedRectangle(cornerRadius: 25)
                    .fill(
                        AngularGradient(gradient: Gradient(colors: [.cyan, .purple, .cyan]),
                                        center: .center,
                                        angle: .degrees(hueRotation ? 360 : 0))
                    )
            )
            .blur(radius: 30)
            .hueRotation(.degrees(hueRotation ? 180 : 0))
            .animation(.linear(duration: 5).repeatForever(autoreverses: false), value: hueRotation)
            .onAppear { hueRotation = true }
            .overlay(
                Text("Glass Effect")
                    .font(.title)
                    .foregroundStyle(.white)
                    .blendMode(.overlay)
            )
    }
}
