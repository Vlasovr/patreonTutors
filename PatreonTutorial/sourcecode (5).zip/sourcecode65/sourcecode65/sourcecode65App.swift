//
//  sourcecode65App.swift
//  sourcecode65
//
//  Created by M.Damra on 14.02.2025.
//

import SwiftUI

@main
struct sourcecode65App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
