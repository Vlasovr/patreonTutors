//
//  ContentView.swift
//  sourcecode65
//
//  Created by M.Damra on 14.02.2025.
//

import SwiftUI

struct ContentView: View {
    let items = ["louvre1", "louvre2", "louvre3", "louvre4", "louvre5"]
    var body: some View {
        CarouselView(items: items)
            .frame(height: 250)
            .shadow(color: .black.opacity(0.2), radius: 15, x: 0, y: 0)
    }
}

#Preview {
    ContentView()
}

struct CarouselView: View {
    let items: [String]
    @State private var currentIndex: Int = 0
    let timer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()
    
    var body: some View {
        VStack {
            TabView(selection: $currentIndex) {
                ForEach(Array(items.enumerated()), id: \.offset) { index, item in
                    ZStack(alignment: .bottomLeading) {
                        Image(item)
                            .resizable()
                            .frame(height: 250)
                            .clipped()
                            .cornerRadius(25)
                            .shadow(radius: 5)
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
            .frame(height: 250)
            .onReceive(timer) { _ in
                withAnimation {
                    currentIndex = (currentIndex + 1) % items.count
                }
            }
            
            HStack(spacing: 8) {
                ForEach(0..<items.count, id: \.self) { index in
                    Circle()
                        .fill(index == currentIndex ? .white : .gray.opacity(0.5))
                        .frame(width: 8, height: 8)
                }
            }
        }
    }
}
