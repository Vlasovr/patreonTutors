//
//  CircleButton.swift
//  DraggableDatingCard
//
//  Created by Damra on 20.09.2024.
//

import Foundation
import SwiftUI

struct CircleButton: View {
    var icon: String
    var color: Color
    var circleframe: CGFloat
    var imageframe: CGFloat
    var imagecolor: Color
    var body: some View {
        Button {
            
        } label: {
            ZStack {
                Circle()
                    .fill(color)
                    .frame(width: circleframe, height: circleframe)
                
                Image(systemName: icon)
                    .resizable()
                    .scaledToFit()
                    .foregroundColor(imagecolor)
                    .frame(width: imageframe, height: imageframe)
            }
        }.buttonStyle(.plain)
    }
}
