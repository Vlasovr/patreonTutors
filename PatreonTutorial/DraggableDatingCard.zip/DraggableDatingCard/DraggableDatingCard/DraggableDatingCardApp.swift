//
//  DraggableDatingCardApp.swift
//  DraggableDatingCard
//
//  Created by Damra on 20.09.2024.
//

import SwiftUI

@main
struct DraggableDatingCardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
