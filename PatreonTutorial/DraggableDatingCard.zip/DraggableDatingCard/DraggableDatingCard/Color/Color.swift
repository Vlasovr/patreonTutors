//
//  Color.swift
//  DatingAppTemplate
//
//  Created by Damra on 18.09.2024.
//

import Foundation
import SwiftUI

extension Color {
    static var lightPink: Color = Color.init(red: 254/255, green: 244/255, blue: 242/255)
    static var darkPink: Color = Color.init(red: 254/255, green: 126/255, blue: 142/255)
}
