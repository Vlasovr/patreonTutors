//
//  DiscoverView.swift
//  DraggableDatingCard
//
//  Created by Damra on 20.09.2024.
//

import Foundation
import SwiftUI

struct DiscoverView: View {
    @State private var dragOffsets: [CGSize] = Array(repeating: .zero, count: 6)
    @State private var showMatchOverlay = false
    
    let profiles = [
        ("Emily Johnson, 28", "New York, USA", "13.8 km away"),
        ("Sophia Müller, 32", "Berlin, Germany", "7.2 km away"),
        ("Isabella Rossi, 25", "Rome, Italy", "10.5 km away"),
        ("Emma García, 30", "Madrid, Spain", "8.3 km away"),
        ("Chloe Dupont, 27", "Paris, France", "5.9 km away"),
        ("Anna Svensson, 35", "Stockholm, Sweden", "11.4 km away")
        ]
    let profileImage = ["Emily Johnson","Sophia Müller","Isabella Rossi","Emma García","Chloe Dupont","Anna Svensson"
    ]
    var body: some View {
        ZStack {
            VStack {
                // Profile Cards with Animations
                ZStack {
                    ForEach(profiles.indices.reversed(), id: \.self) { index in
                        let profile = profiles[index]
                        
                        ProfileCard(profile: profile, offset: $dragOffsets[index], profileImage: profileImage[index])
                            .offset(dragOffsets[index])
                            .rotationEffect(.degrees(Double(dragOffsets[index].width / 40)))
                            .gesture(
                                DragGesture()
                                    .onChanged { value in
                                        dragOffsets[index] = value.translation
                                    }
                                    .onEnded { value in
                                        if abs(value.translation.width) > 250 && index < 5 {
                                            // Dragging far enough, simulate dismiss
                                            withAnimation {
                                                dragOffsets[index] = CGSize(width: value.translation.width * 2, height: 0)
                                                showMatchOverlay = true
                                            }
                                        } else {
                                            // Return to original position
                                            withAnimation {
                                                dragOffsets[index] = .zero
                                                showMatchOverlay = false
                                            }
                                        }
                                    }
                                )
                            .animation(.spring(), value: dragOffsets[index])
                    }
                }
            }
        }
        .frame(height: 350)
    }
}

#Preview {
    DiscoverView()
}
