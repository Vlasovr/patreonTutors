//
//  ProfileCard.swift
//  DraggableDatingCard
//
//  Created by Damra on 20.09.2024.
//

import Foundation
import SwiftUI

// ProfileCard Component
struct ProfileCard: View {
    var profile: (String, String, String)
    @Binding var offset: CGSize
    let profileImage: String
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 25)
                .fill(.white)
                .frame(height: 500)
            
            VStack(spacing: 2){
                ZStack {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.gray.opacity(0.3))
                        .frame(height: 300)
                    Image(profileImage).resizable().frame(height: 300)
                        .scaledToFit()
                        .cornerRadius(20)
                }
                .padding(.top, 20)
                
                Spacer()
                
                Text(profile.0) // Name and age
                    .font(.custom("Rubik-Medium", size: 25))
                Text(profile.1) // Location
                    .font(.custom("Rubik-Regular", size: 18))
                    .foregroundColor(.gray)
                Text(profile.2)
                    .font(.custom("Rubik-Light", size: 16))
                    .foregroundStyle(.gray)
                
                Spacer()
                
                // Action buttons
                HStack(spacing: 35) {
                    CircleButton(icon: "xmark", color: .pink.opacity(0.1), circleframe: 65, imageframe: 15, imagecolor: .pink)
                    CircleButton(icon: "heart.fill", color: .pink, circleframe: 65, imageframe: 35, imagecolor: .white)
                    CircleButton(icon: "star.fill", color: .pink.opacity(0.1), circleframe: 65, imageframe: 20, imagecolor: .pink)
                }
                .padding(.bottom, 30)
            }
            .padding(.horizontal)
            .padding(.top, 20)
        }
    }
}
