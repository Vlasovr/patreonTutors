import SwiftUI
import CoreHaptics

// MARK: - Data Model for each segment
struct SegmentItem: Identifiable, Hashable {
    let id = UUID()
    let label: String
    let iconName: String?
}

// MARK: - Custom Segmented Control
struct AdvancedSegmentedControl: View {
    // Features / Customizations
    let items: [SegmentItem]
    @Binding var selectedIndex: Int
    
    // Appearance
    var backgroundGradient: LinearGradient = LinearGradient(
        colors: [.white, .gray.opacity(0.1)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    var highlightGradient: LinearGradient = LinearGradient(
        colors: [.blue, .green],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    var textColor: Color = .primary
    var highlightTextColor: Color = .white
    var font: Font = .headline
    var iconSize: CGFloat = 18                // Custom icon size
    var iconColor: Color = .white             // Custom icon color
    var hasIcons: Bool = true
    
    // Layout
    var isVertical: Bool = false
    var spacing: CGFloat = 12
    var cornerRadius: CGFloat = 12
    var highlightCornerRadius: CGFloat = 10
    var horizontalPadding: CGFloat = 16
    var verticalPadding: CGFloat = 8
    
    // Border & Shadow
    var borderColor: Color = .gray
    var borderWidth: CGFloat = 1
    var shadowColor: Color = .gray.opacity(0.4)
    var shadowRadius: CGFloat = 4
    
    // Animation & Haptics
    var animation: Animation = .spring(response: 0.3, dampingFraction: 0.7, blendDuration: 0.1)
    var useHaptics: Bool = true
    
    // Matched geometry namespace
    @Namespace private var highlightNamespace
    
    // Haptic engine
    @State private var engine: CHHapticEngine?
    
    public init(
        items: [SegmentItem],
        selectedIndex: Binding<Int>,
        backgroundGradient: LinearGradient = LinearGradient(
            colors: [.white, .gray.opacity(0.1)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        ),
        highlightGradient: LinearGradient = LinearGradient(
            colors: [.blue, .green],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        ),
        textColor: Color = .primary,
        highlightTextColor: Color = .white,
        font: Font = .headline,
        iconSize: CGFloat = 18,
        iconColor: Color = .white,
        hasIcons: Bool = true,
        isVertical: Bool = false,
        spacing: CGFloat = 12,
        cornerRadius: CGFloat = 12,
        highlightCornerRadius: CGFloat = 10,
        horizontalPadding: CGFloat = 16,
        verticalPadding: CGFloat = 8,
        borderColor: Color = .gray,
        borderWidth: CGFloat = 1,
        shadowColor: Color = .gray.opacity(0.4),
        shadowRadius: CGFloat = 4,
        animation: Animation = .spring(response: 0.3, dampingFraction: 0.7, blendDuration: 0.1),
        useHaptics: Bool = true
    ) {
        self._selectedIndex = selectedIndex
        self.items = items
        self.backgroundGradient = backgroundGradient
        self.highlightGradient = highlightGradient
        self.textColor = textColor
        self.highlightTextColor = highlightTextColor
        self.font = font
        self.iconSize = iconSize
        self.iconColor = iconColor
        self.hasIcons = hasIcons
        self.isVertical = isVertical
        self.spacing = spacing
        self.cornerRadius = cornerRadius
        self.highlightCornerRadius = highlightCornerRadius
        self.horizontalPadding = horizontalPadding
        self.verticalPadding = verticalPadding
        self.borderColor = borderColor
        self.borderWidth = borderWidth
        self.shadowColor = shadowColor
        self.shadowRadius = shadowRadius
        self.animation = animation
        self.useHaptics = useHaptics
    }
    
    var body: some View {
        ZStack(alignment: isVertical ? .topLeading : .leading) {
            backgroundView
            
            // We wrap segments in an overlay so we can place a sliding highlight behind them
            if isVertical {
                verticalLayout
            } else {
                horizontalLayout
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius))
        .overlay(
            RoundedRectangle(cornerRadius: cornerRadius)
                .stroke(borderColor, lineWidth: borderWidth)
        )
        .shadow(color: shadowColor, radius: shadowRadius, x: 0, y: 2)
        .onAppear {
            prepareHaptics()
        }
    }
    
    // MARK: - Background
    private var backgroundView: some View {
        backgroundGradient
            .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    
    // MARK: - Horizontal Layout
    private var horizontalLayout: some View {
        HStack(spacing: 0) {
            ForEach(items.indices, id: \.self) { index in
                GeometryReader { geometry in
                    segmentButton(for: index, in: geometry.size)
                }
                .frame(minWidth: 50) // minimum width for each segment
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, verticalPadding)
    }
    
    // MARK: - Vertical Layout
    private var verticalLayout: some View {
        VStack(spacing: 0) {
            ForEach(items.indices, id: \.self) { index in
                GeometryReader { geometry in
                    segmentButton(for: index, in: geometry.size)
                }
                .frame(height: 44) // fixed height for each segment
            }
        }
        .padding(.horizontal, horizontalPadding)
    }
    
    // MARK: - Segment Button
    private func segmentButton(for index: Int, in geometrySize: CGSize) -> some View {
        ZStack {
            // Highlight view (if selected)
            if selectedIndex == index {
                highlightGradient
                    .matchedGeometryEffect(id: "highlight", in: highlightNamespace)
                    .cornerRadius(highlightCornerRadius)
                    .frame(width: geometrySize.width, height: geometrySize.height)
                    .animation(nil)
            }
            
            // Content (icon + text)
            HStack(spacing: 4) {
                if hasIcons, let icon = items[index].iconName {
                    Image(systemName: icon)
                        .resizable()
                        .scaledToFit()
                        .foregroundColor(selectedIndex == index ? highlightTextColor : textColor)
                        .frame(width: iconSize, height: iconSize)
                }
                Text(items[index].label)
                    .font(font)
                    .foregroundColor(selectedIndex == index ? highlightTextColor : textColor)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .onTapGesture {
            withAnimation(animation) {
                selectedIndex = index
                if useHaptics {
                    complexSuccessHaptic()
                }
            }
        }
    }
    
    // MARK: - Haptics Preparation
    private func prepareHaptics() {
        guard useHaptics else { return }
        do {
            self.engine = try CHHapticEngine()
            try engine?.start()
        } catch {
            print("Failed to start haptic engine: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Complex Success Haptic
    private func complexSuccessHaptic() {
        guard useHaptics, let engine = engine else { return }
        
        var events = [CHHapticEvent]()
        
        // Sharp attack
        let sharpAttack = CHHapticEvent(
            eventType: .hapticTransient,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 1.0),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 1.0)
            ],
            relativeTime: 0
        )
        
        // Smooth follow-up
        let smoothFollowUp = CHHapticEvent(
            eventType: .hapticTransient,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.5),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.1)
            ],
            relativeTime: 0.1
        )
        
        events.append(sharpAttack)
        events.append(smoothFollowUp)
        
        do {
            let pattern = try CHHapticPattern(events: events, parameters: [])
            let player = try engine.makePlayer(with: pattern)
            try player.start(atTime: 0)
        } catch {
            print("Failed to play haptic: \(error.localizedDescription)")
        }
    }
}

// MARK: - Example Usage in a ContentView
struct ContentView: View {
    let segmentItems: [SegmentItem] = [
        SegmentItem(label: "Home", iconName: "house"),
        SegmentItem(label: "Profile", iconName: "person.circle"),
        SegmentItem(label: "Settings", iconName: "gear"),
        SegmentItem(label: "Help", iconName: "questionmark.circle")
    ]
    
    @State private var selectedIndex: Int = 0
    
    var body: some View {
        VStack(spacing: 20) {
            // Horizontal advanced segmented control
            AdvancedSegmentedControl(
                items: segmentItems,
                selectedIndex: $selectedIndex,
                backgroundGradient: LinearGradient(
                    colors: [.white, .blue.opacity(0.1)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                highlightGradient: LinearGradient(
                    colors: [.blue, .purple],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                textColor: .blue,
                highlightTextColor: .white,
                font: .headline,
                iconSize: 16,
                iconColor: .white,
                hasIcons: true,
                isVertical: false,
                spacing: 12,
                cornerRadius: 16,
                highlightCornerRadius: 10,
                horizontalPadding: 16,
                verticalPadding: 12,
                borderColor: .blue,
                borderWidth: 1,
                shadowColor: Color.blue.opacity(0.3),
                shadowRadius: 6,
                animation: .spring(response: 0.4, dampingFraction: 0.6, blendDuration: 0.1),
                useHaptics: true
            )
            .frame(height: 60)
            .padding(.horizontal)
            
            // Vertical advanced segmented control
            AdvancedSegmentedControl(
                items: segmentItems,
                selectedIndex: $selectedIndex,
                backgroundGradient: LinearGradient(
                    colors: [.gray.opacity(0.2), .gray.opacity(0.05)],
                    startPoint: .top,
                    endPoint: .bottom
                ),
                highlightGradient: LinearGradient(
                    colors: [.orange, .red],
                    startPoint: .leading,
                    endPoint: .trailing
                ),
                textColor: .black,
                highlightTextColor: .white,
                font: .subheadline,
                iconSize: 20,
                iconColor: .white,
                hasIcons: true,
                isVertical: true,
                spacing: 8,
                cornerRadius: 12,
                highlightCornerRadius: 8,
                horizontalPadding: 10,
                verticalPadding: 8,
                borderColor: .orange,
                borderWidth: 2,
                shadowColor: Color.orange.opacity(0.3),
                shadowRadius: 8,
                animation: .easeInOut,
                useHaptics: true
            )
            .frame(height: 300)
            
            // Display which segment is selected
            Text("Selected: \(segmentItems[selectedIndex].label)")
                .font(.title2)
                .bold()
        }
        .padding(.vertical, 20)
    }
}

// MARK: - Main Entry Point
@main
struct MainApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
