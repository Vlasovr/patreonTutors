//
//  ContentView.swift
//  sourcecode84
//
//  Created by M.Damra on 24.02.2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        QuantumTrial()
            .preferredColorScheme(.dark)
    }
}

#Preview {
    ContentView()
}

struct QuantumTrial: View {
    @State private var particles: [Particle] = []
    var body: some View {
        Canvas { context, size in
            for particle in particles {
                let path = Path(ellipseIn: CGRect(x: particle.x, y: particle.y, width: 25, height: 25))
                context.fill(path, with: .color(particle.color.opacity(particle.opacity)))
            }
        }
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { value in
                    let newParticle = Particle(x: value.location.x, y: value.location.y, color: [.green, .mint, .cyan, .purple].randomElement()!)
                    particles.append(newParticle)
                }
        )
        .onReceive(Timer.publish(every: 0.01, on: .main, in: .common).autoconnect()) { _ in
            particles = particles.filter { $0.life > 0 }.map { p in
                var particle = p
                particle.y -= 1
                particle.life -= 0.01
                particle.x += CGFloat.random(in: -0.5...0.5)
                return particle
            }
        }
    }
}

struct Particle: Identifiable {
    let id = UUID()
    var x: CGFloat
    var y: CGFloat
    var life: Double = 1.0
    let color: Color
    var opacity: Double { life * 0.8 }
}
