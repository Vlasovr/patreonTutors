//
//  sourcecode84App.swift
//  sourcecode84
//
//  Created by M.Damra on 24.02.2025.
//

import SwiftUI

@main
struct sourcecode84App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}
