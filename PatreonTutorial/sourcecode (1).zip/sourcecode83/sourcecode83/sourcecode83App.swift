//
//  sourcecode83App.swift
//  sourcecode83
//
//  Created by M.Damra on 24.02.2025.
//

import SwiftUI

@main
struct sourcecode83App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}
