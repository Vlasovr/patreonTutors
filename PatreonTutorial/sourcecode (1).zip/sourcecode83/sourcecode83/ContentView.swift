//
//  ContentView.swift
//  sourcecode83
//
//  Created by M.Damra on 24.02.2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NeuroButton()
    }
}

#Preview {
    ContentView()
        .preferredColorScheme(.dark)
}

struct NeuroButton: View {
    @State private var touchLocation = CGPoint.zero
    @State private var neuralActivity: CGFloat = 0
    var body: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(.black)
            .frame(width: .infinity)
            .overlay(
                ZStack {
                    ForEach(0..<15) { i in
                        Circle()
                            .fill(RadialGradient(gradient: Gradient(colors: [.green.opacity(0.3), .clear]), center: .center, startRadius: 0, endRadius: 50))
                            .frame(width: neuralActivity * 100)
                            .position(touchLocation)
                            .offset(x: CGFloat.random(in: -30...30), y: CGFloat.random(in: -30...30))
                    }
                }
                    .blendMode(.screen)
            )
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        touchLocation = value.location
                        neuralActivity = 1 // MARK: YAZMA
                    }
                    .onEnded { _ in // MARK: YAZMA
                        withAnimation(.easeOut(duration: 0.5)) {
                            neuralActivity = 0
                        }
                    }
            )
    }
}
