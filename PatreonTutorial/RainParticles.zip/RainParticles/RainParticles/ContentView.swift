//
//  ContentView.swift
//  RainParticles
//
//  Created by Selçuk Aslantas on 13.09.2024.
//

import SwiftUI

struct ContentView: View {
    @State var opacity = 0.0
    
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            //snowingBG()
            rainingBG()
            //liefingBG()
            //allparticleBG(texture: "kargo2",pRotationSpeed: 0)
            
            VStack {
                
                ZStack {
                    RoundedRectangle(cornerRadius: 30).foregroundColor(.orange)
                        //.snowFallLanding(viewWidth: 300, viewHeight: 200,cornerR: 30, opacity: 1)
                        .rainFallLanding(viewWidth: 300, viewHeight: 200,cornerR: 30, opacity: 0.7)
                    Text("Rain Particle")
                        .font(.system(size: 40))
                        .kerning(-0.5)
                        .bold()
                        .foregroundColor(.black)
                }
                
                //celebrationBG()
            } // VStack
            
           
            
            
        } // ZStack
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                withAnimation(.easeIn(duration: 1)) {
                    opacity = 1.0
                }
            }//DispatchQueue
        }
        
    }//body
}//struct

#Preview {
    ContentView()
}
