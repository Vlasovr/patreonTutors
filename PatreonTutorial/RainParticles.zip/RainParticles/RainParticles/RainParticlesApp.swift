//
//  RainParticlesApp.swift
//  RainParticles
//
//  Created by Selçuk Aslantas on 13.09.2024.
//

import SwiftUI

@main
struct RainParticlesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
