//
//  RainParticleEfect.swift
//  notesandremember
//
//  Created by Selçuk on 13.03.2022.
//

import SwiftUI
import SpriteKit

class RainScene: SKScene {

    let rainEmitterNode = SKEmitterNode(fileNamed: "rain.sks")

    override func didMove(to view: SKView) {
        guard let rainEmitterNode = rainEmitterNode else { return }
        //rainEmitterNode.particleSize = CGSize(width: 50, height: 50)
        //rainEmitterNode.particleLifetime = 2
        //rainEmitterNode.particleLifetimeRange = 6
        rainEmitterNode.speed = 1
        addChild(rainEmitterNode)
    }

    override func didChangeSize(_ oldSize: CGSize) {
        guard let rainEmitterNode = rainEmitterNode else { return }
        rainEmitterNode.particlePosition = CGPoint(x: size.width/2, y: size.height)
        rainEmitterNode.particlePositionRange = CGVector(dx: size.width, dy: size.height)
    }
}

//****Butonların yazıların üstüne damlama kalma efecti******

class RainSceneFallLanding: SKScene {

    let rainEmitterNode = SKEmitterNode(fileNamed: "rainFallLanding.sks")

    override func didMove(to view: SKView) {
        guard let rainEmitterNode = rainEmitterNode else { return }
        rainEmitterNode.particleSize = CGSize(width: 50, height: 50)
        rainEmitterNode.particleLifetime = 2
        rainEmitterNode.particleLifetimeRange = 6
        rainEmitterNode.speed = 1
        addChild(rainEmitterNode)
    }

    override func didChangeSize(_ oldSize: CGSize) {
        guard let rainEmitterNode = rainEmitterNode else { return }
        rainEmitterNode.particlePosition = CGPoint(x: size.width/2, y: size.height)
        rainEmitterNode.particlePositionRange = CGVector(dx: size.width, dy: size.height)
    }
}

//********************

func rainingBG() -> some View {
    
    //kar yagisi degiskeni
    var scene: SKScene {
            let scene = RainScene()
            scene.scaleMode = .resizeFill
            scene.backgroundColor = .clear
            return scene
        }
    
    return ZStack {
        SpriteView(scene: scene, options: [.allowsTransparency])
                        .ignoresSafeArea()
                        .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
    }//ZStack
    
    
}//func raining() -> some View

//********************************************

extension View {
    public func rainFallLanding(viewWidth: CGFloat = UIScreen.main.bounds.width - 40, viewHeight: CGFloat = 300, cornerR: CGFloat = 0, opacity: Double = 1.0) -> some View {
     
        
        //kar kalıntısı degiskeni
        var scene1: SKScene {
                let scene = RainSceneFallLanding()
                scene.scaleMode = .resizeFill
                scene.backgroundColor = .clear
                return scene
            }
        //********************
        
        return ZStack(alignment: .top) {
            self.frame(width: viewWidth, height: viewHeight, alignment: .center)
            SpriteView(scene: scene1, options: [.allowsTransparency])
                .frame(width: viewWidth - (2 * cornerR) , height: 5, alignment: .center).opacity(opacity).offset(y: -4.2)
        }//ZStack
            
    }
    
    
}

