//
//  HapticFeedback.swift
//  MaskImageTemplate
//
//  Created by Damra on 19.09.2024.
//

import SwiftUI

class HapticFeedback {
    ///MARK: USE
    ///HapticFeedback.playSelection()
    
    #if os(watchOS)
    //watchOS implementation
    static func playSelection() -> Void {
        WKInterfaceDevice.current().play(.click)
    }
    #elseif os(iOS)
    //iOS implementation
    let selectionFeedbackGenerator = UISelectionFeedbackGenerator()
    static func playSelection() -> Void {
        UISelectionFeedbackGenerator().selectionChanged()
    }
    #else
    static func playSelection() -> Void {
        //No-op
    }
    #endif
}
