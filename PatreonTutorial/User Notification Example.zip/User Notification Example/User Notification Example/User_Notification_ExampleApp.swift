//
//  User_Notification_ExampleApp.swift
//  User Notification Example
//
//  Created by Damra on 6.10.2023.
//

import SwiftUI

@main
struct User_Notification_ExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
