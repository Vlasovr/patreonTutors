//
//  ContentView.swift
//  User Notification Example
//
//  Created by Damra on 6.10.2023.
//

import SwiftUI
import UserNotifications

struct ContentView: View {
    @AppStorage("isNotificationAuthorized") var isNotificationAuthorized = false
    var body: some View {
        if isNotificationAuthorized {
            Button("Send Notification") {
                sendNotification()
            }
        }else {
            Button(action: {
                requestNotificationAuthorization()
                
            }){
                Text("Request notification permission")
            }
        }
    }
}

func sendNotification() {
    // Creating notification content
    let content = UNMutableNotificationContent()
    content.title = "New Notification"
    content.subtitle = "Hello, this is a notification"
    content.sound = UNNotificationSound.default
    
    //Notification trigger time (e.g after 10 seconds)
    let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false)
    
    //Create a notification request
    let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
    
    //Send the notification to the notification center
    UNUserNotificationCenter.current().add(request) { error in
        if let error = error {
            print("Error sending notification: \(error.localizedDescription)")
        }else {
            print("Notification sent!")
        }
    }
}

func requestNotificationAuthorization() {
    @AppStorage("isNotificationAuthorized") var isNotificationAuthorized = false
    UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { (granted, error) in
        if let error = error {
            print("Error sending notification: \(error.localizedDescription)")
            return
        }
        
        if granted {
            //User has given permission
            isNotificationAuthorized = true
            print("Notification permission granted.")
        } else {
            isNotificationAuthorized = false
            print("Notification permission denied.")
        }
        
    }
}


#Preview {
    ContentView()
}
