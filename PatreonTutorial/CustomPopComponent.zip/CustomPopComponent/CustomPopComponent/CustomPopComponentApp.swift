//
//  CustomPopComponentApp.swift
//  CustomPopComponent
//
//  Created by Altuğ Nuri ASLANTAŞ on 16.09.2024.
//

import SwiftUI

@main
struct CustomPopComponentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
