//
//  ContentView.swift
//  sourcecode40
//
//  Created by M.Damra on 1.02.2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        OTPTextFieldView()
    }
}

#Preview {
    ContentView()
}


// MARK: - OTP Input Screen
struct OTPTextFieldView: View {
    // An array to hold each OTP digit (6 digits).
    @State private var otpCode: [String] = Array(repeating: "", count: 6)
    // Focus state for which OTP field is active.
    @FocusState private var focusedIndex: Int?
    // Used to trigger the shake animation on error.
    @State private var shakeCount: CGFloat = 0
    // Optional error message.
    @State private var errorMessage: String? = nil
    // Countdown for the “Resend OTP” button.
    @State private var resendCountdown: Int = 30
    // Show success overlay after a valid submission.
    @State private var showSuccess: Bool = false
    
    // Timer that fires every second for the countdown.
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    // Maximum countdown value.
    let maxCountdown = 30
    var body: some View {
        ZStack {
            // Background gradient.
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.3), Color.purple.opacity(0.3)]), startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                Text("Enter the 6-digit OTP")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                
                // OTP Fields
                HStack(spacing: 10) {
                    ForEach(0..<6, id: \.self) { index in
                        ZStack {
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(errorMessage != nil ? Color.red : (focusedIndex == index ? Color.blue : Color.gray), lineWidth: 2)
                                .frame(width: 50, height: 50)
                            
                            TextField("", text: Binding(
                                get: { otpCode[index] },
                                set: { newValue in
                                    let filtered = newValue.filter({ $0.isNumber })
                                    otpCode[index] = String(filtered.prefix(1))
                                    
                                    // Move focus automatically.
                                    if !otpCode[index].isEmpty && index < otpCode.count - 1 {
                                        focusedIndex = index + 1
                                    }
                                }
                            ))
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.center)
                            .font(.title2)
                            .frame(width: 50, height: 50)
                            .background(Color.white)
                            .cornerRadius(8)
                            .focused($focusedIndex, equals: index)
                        }
                    }
                }
                .modifier(ShakeEffect(shakes: shakeCount))
                .padding(.horizontal)
                
                // Error Message
                if let error = errorMessage {
                    Text(error)
                        .foregroundColor(.red)
                        .font(.caption)
                        .transition(.opacity)
                }
                
                // Paste & Clear Buttons
                HStack(spacing: 20) {
                    Button {
                        pasteOTP()
                    } label: {
                        HStack {
                            Image(systemName: "doc.on.clipboard")
                            Text("Paste OTP")
                        }
                        .padding(8)
                        .background(Color.green.opacity(0.2))
                        .cornerRadius(8)
                    }
                    
                    Button {
                        clearOTP()
                    } label: {
                        HStack {
                            Image(systemName: "xmark.circle")
                            Text("Clear")
                        }
                        .padding(8)
                        .background(Color.gray.opacity(0.2))
                        .cornerRadius(8)
                    }
                }
                
                // Submit Button
                Button {
                    submitOTP()
                } label: {
                    Text("Submit")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .shadow(radius: 5)
                }
                .padding(.horizontal)
                
                // Resend OTP Section
                resendSection
                
                Spacer()
                
            }
            .padding()
            
            // Success Overlay
            if showSuccess {
                Color.black.opacity(0.4)
                    .ignoresSafeArea()
                    .transition(.opacity)
                VStack(spacing: 20) {
                    Image(systemName: "checkmark.seal.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 80, height: 80)
                        .foregroundColor(.green)
                    Text("OTP Verified!")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                }
                .padding()
                .background(Color.black.opacity(0.8))
                .cornerRadius(12)
                .transition(.scale)
            }
        }
        .onAppear {
            focusedIndex = 0
        }
        .onReceive(timer) { _ in
            if resendCountdown > 0 {
                resendCountdown -= 1
            }
        }
    }
    
    // MARK: - Paste OTP
    func pasteOTP() {
        if let pasteText = UIPasteboard.general.string, pasteText.filter({ $0.isNumber }).count == 6 {
            for (index, char) in pasteText.enumerated() {
                if index < 6 {
                    otpCode[index] = String(char)
                }
            }
            focusedIndex = nil
        } else {
            errorMessage = "Clipboard does not contain a valid 6-digit OTP."
            
            withAnimation {
                shakeCount += 1
            }
            
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            
        }
    }
    
     // MARK: - Clear OTP
    func clearOTP() {
        otpCode = Array(repeating: "", count: 6)
        focusedIndex = 0
        errorMessage = nil
    }
    
    // MARK: - Resend Section
    private var resendSection: some View {
        // Calculate progress: 1.0 means time fully remaining, 0.0 means time is up.
        let progress = Double(resendCountdown) / Double(maxCountdown)
        
        return Button(action: resendOTP) {
            ZStack {
                // Capsule background
                Capsule()
                    .fill(resendCountdown > 0 ? Color.gray.opacity(0.2) : Color.blue.opacity(0.2))
                
                // Trimmed stroke with a rotation effect.
                // Change '.degrees(90)' to another angle if you want a different start position.
                Capsule()
                    .trim(from: 0, to: CGFloat(progress))
                    .stroke(
                        AngularGradient(
                            gradient: Gradient(colors: [Color.purple, Color.red, Color.purple]),
                            center: .center
                        ),
                        style: StrokeStyle(lineWidth: 4, lineCap: .round)
                    )
               
                    .animation(.linear, value: progress)
                
                Text(resendCountdown > 0 ? "Resend in \(resendCountdown)s" : "Resend OTP")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(resendCountdown > 0 ? Color.gray : Color.blue)
                    .padding(.vertical, 8)
                    .padding(.horizontal, 16)
            }
            .frame(height: 40)
            
        }
        .disabled(resendCountdown > 0)
        .padding(.top, 8)
        
    }
    
    // MARK: - OTP Submission
    func submitOTP() {
        let code = otpCode.joined()
        if code.count < 6 {
            errorMessage = "Please enter all 6 digits."
            withAnimation {
                shakeCount += 1
            }
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        } else {
            errorMessage = nil
            print("OTP Submitted: \(code)")
            
            UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
            
            withAnimation {
                showSuccess = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                withAnimation {
                    showSuccess = false
                }
            }
        }
    }
    
    // MARK: - Resend OTP
    func resendOTP() {
        otpCode = Array(repeating: "", count: 6)
        focusedIndex = 0
        resendCountdown = maxCountdown
        errorMessage = nil
        print("OTP Resent")
    }
    
}
