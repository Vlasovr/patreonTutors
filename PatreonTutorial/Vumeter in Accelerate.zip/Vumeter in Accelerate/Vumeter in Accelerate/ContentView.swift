//
//  ContentView.swift
//  Vumeter in Accelerate
//
//  Created by Damra on 5.12.2024.
//

import SwiftUI
import Foundation
import AVFoundation
import Accelerate

struct ContentView: View {
    @StateObject private var analyzer = AudioAnalyzer()
    var body: some View {
        ZStack {
            Color.Neumorphic.main.ignoresSafeArea()
            
            VStack {
                Text("SwiftUICodes")
                .font(.largeTitle)
                .softOuterShadow()

                Text("🎵 VU Meter 🎵")
                .font(.largeTitle)
                .softOuterShadow()

                topMeter()
                centerMeter()
                bottomMeter()
                
                HStack {
                    Button {
                        if let fileURL = Bundle.main.url(forResource: "audio", withExtension: "mp3") {
                            analyzer.start(fileURL: fileURL)
                        }
                    } label: {
                        Image(systemName: "play.circle.fill")
                            .resizable()
                            .frame(width: 50, height: 50)
                            .foregroundStyle(.green)
                            .softOuterShadow()
                    }
                    
                    Button {
                        analyzer.stop()
                        analyzer.fftMagnitudes.removeAll()
                    } label: {
                        Image(systemName: "stop.circle.fill")
                            .resizable()
                            .frame(width: 50, height: 50)
                            .foregroundStyle(.red)
                            .softOuterShadow()
                    }
                }
            }
        }
    }
    
     @ViewBuilder
    private func topMeter() -> some View {
        //MARK: Top
        HStack(alignment: .center, spacing: 2) {
            ForEach(analyzer.fftMagnitudes.indices, id: \.self) { index in
                VStack {
                    Rectangle()
                        .fill(Color.red)
                        .frame(width: 4, height: max(CGFloat(analyzer.fftMagnitudes[index]) * 2, 1)) // Scale the height
                        .animation(.linear(duration: 0.1), value: analyzer.fftMagnitudes[index])
                    
                    Spacer()
                }
            }
        }
        .frame(maxHeight: 120)
        .padding()
    }
    
    @ViewBuilder
   private func centerMeter() -> some View {
       //MARK: Top
       HStack(alignment: .center, spacing: 2) {
           ForEach(analyzer.fftMagnitudes.indices, id: \.self) { index in
               Rectangle()
                   .fill(.linearGradient(colors: [.mint, .purple], startPoint: .top, endPoint: .bottom))
                   .frame(width: 4, height: max(CGFloat(analyzer.fftMagnitudes[index]) * 2, 1)) // Scale the height
                   .animation(.linear(duration: 0.1), value: analyzer.fftMagnitudes[index])
           }
       }
       .frame(maxHeight: 120)
       .padding()
   }
    
    @ViewBuilder
   private func bottomMeter() -> some View {
       //MARK: Top
       HStack(alignment: .center, spacing: 2) {
           ForEach(analyzer.fftMagnitudes.indices, id: \.self) { index in
               VStack {
                   Spacer()
                   
                   Rectangle()
                       .fill(Color.red)
                       .frame(width: 4, height: max(CGFloat(analyzer.fftMagnitudes[index]) * 2, 1)) // Scale the height
                       .animation(.linear(duration: 0.1), value: analyzer.fftMagnitudes[index])
               }
           }
       }
       .frame(maxHeight: 120)
       .padding()
   }
    
}

#Preview {
    ContentView()
}

class AudioAnalyzer: ObservableObject {
    private var audioEngine = AVAudioEngine()
    private var playerNode = AVAudioPlayerNode()
    private var fftNode: AVAudioMixerNode!
    private let fftSize = 512 // FFT size (power of 2)
    private var bufferSize: Int { fftSize / 2 }
    
    @Published var fftMagnitudes: [Float] = Array(repeating: 0, count: 256)
    
    func start(fileURL: URL) {
        do {
             // Load the audio file
            let audioFile = try AVAudioFile(forReading: fileURL)
            
            // Attach and connect nodes
            audioEngine.attach(playerNode)
            fftNode = AVAudioMixerNode()
            audioEngine.attach(fftNode)
            
            audioEngine.connect(playerNode, to: fftNode, format: audioFile.processingFormat)
            audioEngine.connect(fftNode, to: audioEngine.mainMixerNode, format: audioFile.processingFormat)
            
            // Install a tap to analyze audio data
            fftNode.installTap(onBus: 0, bufferSize: AVAudioFrameCount(fftSize), format: audioFile.processingFormat) { [weak self] buffer, time in
                self?.analyze(buffer: buffer)
            }
            
            // Schedule the audio file for playback
            playerNode.scheduleFile(audioFile, at: nil)
            
            // Start the audio engine
            try audioEngine.start()
            playerNode.play()
        } catch {
            print("Error initializing audio: \(error.localizedDescription)")
        }
    }
    
    private func analyze(buffer: AVAudioPCMBuffer) {
        guard let channelData = buffer.floatChannelData else { return }
        let channelDataArray = Array(UnsafeBufferPointer(start: channelData[0], count: Int(buffer.frameLength)))
        
        // Perform FFT
        let fftSetup = vDSP_create_fftsetup(vDSP_Length(log2(Float(fftSize))), FFTRadix(kFFTRadix2))
        var real = [Float](repeating: 0, count: bufferSize)
        var imaginary = [Float](repeating: 0, count: bufferSize)
        var splitComplex = DSPSplitComplex(realp: &real, imagp: &imaginary)
        
        channelDataArray.withUnsafeBytes {
            $0.bindMemory(to: DSPComplex.self).baseAddress?.withMemoryRebound(to: DSPComplex.self, capacity: bufferSize) {
                vDSP_ctoz($0, 2, &splitComplex, 1, vDSP_Length(bufferSize))
            }
        }
        
        var magnitudes = [Float](repeating: 0.0, count: bufferSize)
        vDSP_zvmags(&splitComplex, 1, &magnitudes, 1, vDSP_Length(bufferSize))
        
        let normalizedMagnitudes = magnitudes.map { 20.0 * log10($0) }.map { max(0, $0) } // Normalize to dB scale
        
        DispatchQueue.main.async {
            self.fftMagnitudes = Array(normalizedMagnitudes.prefix(256)) // Update published data
        }
        
        vDSP_destroy_fftsetup(fftSetup)
        
    }
    
    func stop() {
        playerNode.stop()
        audioEngine.stop()
        audioEngine.reset()
    }
}

