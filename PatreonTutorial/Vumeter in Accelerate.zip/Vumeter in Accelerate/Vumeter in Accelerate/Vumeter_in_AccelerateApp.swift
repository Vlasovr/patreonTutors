//
//  Vumeter_in_AccelerateApp.swift
//  Vumeter in Accelerate
//
//  Created by Damra on 5.12.2024.
//

import SwiftUI

@main
struct Vumeter_in_AccelerateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
