
import SwiftUI

@main
struct Custom3DPickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

