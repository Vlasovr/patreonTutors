
import SwiftUI

let frameworkOptions: [String] = [
    "AppKit", "SceneKit", "SpriteKit", "MapKit", "HealthKit", "HomeKit", "GameKit"
    ]

let projectOptions: [String] = [
    "iOS Enterprise Apps", "iOS Utility Apps", "iOS Games", "macOS Productivity Apps", "watchOS Fitness Apps"
    ]

let yearOptions: [String] = [
    "Apple Event 2024", "Apple Event 2023", "Apple Event 2022", "Apple Event 2021", "Apple Event 2020"
    ]


struct ContentView: View {
    @State private var frameworkConfig: PickerConfig = .init(text: "AppKit")
    @State private var projectConfig: PickerConfig = .init(text: "iOS Enterprise Apps")
    @State private var yearConfig: PickerConfig = .init(text: "Apple Event 2024")
    var body: some View {
        NavigationStack {
            List {
                Section("Configuration") {
                    Button {
                        frameworkConfig.show.toggle()
                    } label: {
                        HStack {
                            Text("Framework")
                                .foregroundStyle(.gray)
                            
                            Spacer(minLength: 0)
                            
                            SourcePickerView(config: $frameworkConfig)
                        }
                    }
                    
                    Button {
                        projectConfig.show.toggle()
                    } label: {
                        HStack {
                            Text("Projects")
                                .foregroundStyle(.gray)
                            
                            Spacer(minLength: 0)
                            
                            SourcePickerView(config: $projectConfig)
                        }
                    }
                    
                    Button {
                        yearConfig.show.toggle()
                    } label: {
                        HStack {
                            Text("Year")
                                .foregroundStyle(.gray)
                            
                            Spacer(minLength: 0)
                            
                            SourcePickerView(config: $yearConfig)
                        }
                    }
                }
            }
            .navigationTitle("Custom Picker")
        }
        .customPicker($frameworkConfig, items: frameworkOptions)
        .customPicker($projectConfig, items: projectOptions)
        .customPicker($yearConfig, items: yearOptions)
    }
}

// Custom View Modifier Extension
extension View {
    @ViewBuilder
    func customPicker(_ config: Binding<PickerConfig>, items: [String]) -> some View {
        self
            .overlay {
                if config.wrappedValue.show {
                    CustomPickerView(texts: items, config: config)
                        .transition(.identity)
                }
            }
    }
}

// Source View
struct SourcePickerView: View {
    @Binding var config: PickerConfig
    var body: some View {
        Text(config.text)
            .foregroundStyle(.blue)
            .frame(height: 20)
            .opacity(config.show ? 0 : 1)
            .onGeometryChange(for: CGRect.self) { proxy in
                proxy.frame(in: .global)
            } action: { newValue in
                config.sourceFrame = newValue
            }
    }
}

// Picker Config
struct PickerConfig {
    var text: String
    init(text: String) {
        self.text = text
    }
    
    var show: Bool = false
    // Used for Custom Matched Geometry Effect
    var sourceFrame: CGRect = .zero
}

// Custom Picker View
fileprivate struct CustomPickerView: View {
    var texts: [String]
    @Binding var config: PickerConfig
    // View Private Properties
    @State private var activeOption: String?
    @State private var showContents: Bool = false
    @State private var showScrollView: Bool = false
    @State private var expandItems: Bool = false
    var body: some View {
        GeometryReader {
            let size = $0.size
            
            Rectangle()
                .fill(.ultraThinMaterial)
                .opacity(showContents ? 1 : 0)
                .ignoresSafeArea()
            
            ScrollView(.vertical) {
                LazyVStack(spacing: 0) {
                    ForEach(texts, id: \.self) { option in
                        CardView(option, size: size)
                    }
                }
                .scrollTargetLayout()
            }
            // Making it to start and stop at the center
            .safeAreaPadding(.top, (size.height * 0.5) - 20)
            .safeAreaPadding(.bottom, (size.height * 0.5))
            .scrollPosition(id: $activeOption, anchor: .center)
            .scrollTargetBehavior(.viewAligned(limitBehavior: .always))
            .scrollIndicators(.hidden)
            .opacity(showScrollView ? 1 : 0)
            .allowsHitTesting(expandItems && showScrollView)
            
            let offset: CGSize = .init(
                width: showContents ? size.width * -0.3 : config.sourceFrame.minX,
                height: showContents ? -10 : config.sourceFrame.minY
            )
            
            Text(config.text)
                .fontWeight(showContents ? .semibold : .regular)
                .foregroundStyle(.blue)
                .frame(height: 20)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: showContents ? .trailing : .topLeading)
                .offset(offset)
                .opacity(showScrollView ? 0 : 1)
                .ignoresSafeArea(.all, edges: showContents ? [] : .all)
            
            CloseButton()
        }
        .task {
            guard activeOption == nil else { return }
            activeOption = config.text
            withAnimation(.easeInOut(duration: 0.3)) {
                showContents = true
            }
            
            try? await Task.sleep(for: .seconds(0.3))
            showScrollView = true
            
            withAnimation(.snappy(duration: 0.3, extraBounce: 0)) {
                expandItems = true
            }
        }
        .onChange(of: activeOption) { oldValue, newValue in
            if let newValue {
                config.text = newValue
            }
        }
    }
    
    // Close Button
    @ViewBuilder
    func CloseButton() -> some View {
        Button {
            Task {
                withAnimation(.easeInOut(duration: 0.2)) {
                    expandItems = false
                }
                
                try? await Task.sleep(for: .seconds(0.2))
                showScrollView = false
                withAnimation(.easeInOut(duration: 0.2)) {
                    showContents = false
                }
                
                try? await Task.sleep(for: .seconds(0.2))
                config.show = false
            }
        } label: {
            Image(systemName: "xmark")
                .font(.title2)
                .foregroundStyle(Color.primary)
                .frame(width: 45, height: 45)
                .contentShape(.rect)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .trailing)
        .offset(x: showContents ? -50 : -20, y: -10)
        .opacity(showContents ? 1 : 0)
        .blur(radius: showContents ? 0 : 5)
    }
    
    // Card View
    @ViewBuilder
    private func CardView(_ text: String, size: CGSize) -> some View {
        GeometryReader { proxy in
            let width = proxy.size.width
            
            Text(text)
                .fontWeight(.semibold)
                .foregroundStyle(config.text == text ? .blue : .gray)
                .blur(radius: expandItems ? 0 : config.text == text ? 0 : 5)
                .offset(y: offset(proxy))
                .clipped()
                .offset(x: -width * 0.3)
                .rotationEffect(.init(degrees: expandItems ? -rotation(proxy, size) : .zero), anchor: .topTrailing)
                .opacity(opacity(proxy, size))
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .trailing)
        }
        .frame(height: 20)
        .lineLimit(1)
        .zIndex(config.text == text ? 1000 : 0)
    }
    
    private func offset(_ proxy: GeometryProxy) -> CGFloat {
        let minY = proxy.frame(in: .scrollView(axis: .vertical)).minY
        return expandItems ? 0 : -minY
    }
    
    private func rotation(_ proxy: GeometryProxy, _ size: CGSize) -> CGFloat {
        let height = size.height * 0.5
        let minY = proxy.frame(in: .scrollView(axis: .vertical)).minY
        let maxRotation: CGFloat = 220
        let progress = minY / height
        return progress * maxRotation
    }
    
    private func opacity(_ proxy: GeometryProxy, _ size: CGSize) -> CGFloat {
        let minY = proxy.frame(in: .scrollView(axis: .vertical)).minY
        let height = size.height * 0.5
        let progress = (minY / height) * 2.8
        let opacity = progress < 0 ? 1 + progress : 1 - progress
        return opacity
    }
}

struct CustomPicker: View {
    var body: some View {
        Text("Hello, World!")
    }
}

#Preview {
    ContentView()
}

