//
//  ContentView.swift
//  sourcecode80
//
//  Created by M.Damra on 23.02.2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        PixelRiver()
            .ignoresSafeArea()
            .preferredColorScheme(.dark)
    }
}

#Preview {
    ContentView()
}

struct PixelRiver: View {
    @State private var pixels: [(id: UUID, color: Color, position: CGPoint)] = []
    var body: some View {
        GeometryReader { geo in
            ZStack {
                ForEach(pixels, id: \.id) { pixel in
                    Circle()
                        .fill(pixel.color)
                        .frame(width: 10, height: 10)
                        .position(pixel.position)
                }
            }
            .rotationEffect(.degrees(-180))
            .drawingGroup()
            .onAppear {
                Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { _ in
                    let newPixel = (id: UUID(), color: Color(hue: Double.random(in: 0.1...0.8), saturation: 1, brightness: 1), position: CGPoint(x: CGFloat.random(in: 0...geo.size.width), y: geo.size.height))
                    pixels.append(newPixel)
                    
                    withAnimation(.linear(duration: 3)) {
                        pixels = pixels.map {
                            var p = $0
                            p.position.y -= 30
                            p.color = p.color.opacity(Double.random(in: 0.3...1))
                            return p
                        }.filter { $0.position.y > -30 }
                    }
                }
            }
        }
    }
}
