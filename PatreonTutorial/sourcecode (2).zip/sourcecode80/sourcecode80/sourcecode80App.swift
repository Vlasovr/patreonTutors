//
//  sourcecode80App.swift
//  sourcecode80
//
//  Created by M.Damra on 23.02.2025.
//

import SwiftUI

@main
struct sourcecode80App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
