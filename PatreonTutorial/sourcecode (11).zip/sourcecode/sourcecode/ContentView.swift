import SwiftUI

@main
struct TypewriterTextApp: App {
    var body: some Scene {
        WindowGroup {
            TypewriterTextView()
                .preferredColorScheme(.light) // Default color scheme
        }
    }
}

struct TypewriterTextView: View {
    // Text to be displayed with typewriter animation
    let fullText = "This is a typewriter animation. Customize it as you like!"
    
    // State variables
    @State private var displayedText = ""
    @State private var timer: Timer? = nil
    @State private var animationSpeed: Double = 0.1
    @State private var isAnimating = false
    @State private var showSettings = false
    @State private var textColor: Color = .primary
    @State private var backgroundColor: Color = .white
    @State private var fontSize: CGFloat = 24
    @State private var fontStyle: Font.Design = .monospaced
    
    var body: some View {
        ZStack {
            // Background color
            backgroundColor.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 30) {
                // Text Display Area
                Text(displayedText)
                    .font(.system(size: fontSize, weight: .medium, design: fontStyle))
                    .foregroundColor(textColor)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color(.systemBackground).opacity(0.8))
                    .cornerRadius(15)
                    .shadow(color: Color.black.opacity(0.2), radius: 10, x: 0, y: 5)
                    .overlay(
                        RoundedRectangle(cornerRadius: 15)
                            .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                    )
                
                // Control Buttons
                HStack(spacing: 20) {
                    Button(action: {
                        resetTypewriter()
                    }) {
                        Text("Restart")
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .shadow(color: Color.blue.opacity(0.3), radius: 5, x: 0, y: 2)
                    }
                    
                    Button(action: {
                        if isAnimating {
                            pauseTypewriter()
                        } else {
                            startTypewriter()
                        }
                    }) {
                        Text(isAnimating ? "Pause" : "Resume")
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(isAnimating ? Color.orange : Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .shadow(color: (isAnimating ? Color.orange : Color.green).opacity(0.3), radius: 5, x: 0, y: 2)
                    }
                }
                
                // Animation Speed Slider
                VStack(spacing: 10) {
                    Slider(value: $animationSpeed, in: 0.05...0.5, step: 0.05) {
                        Text("Speed: \(String(format: "%.2f", animationSpeed)) sec")
                    }
                    .accentColor(.blue)
                    
                    // Customize Appearance Button
                    Button(action: {
                        showSettings.toggle()
                    }) {
                        Text("Customize Appearance")
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.purple)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .shadow(color: Color.purple.opacity(0.3), radius: 5, x: 0, y: 2)
                    }
                }
                .padding(.horizontal)
            }
            .padding()
            
            // Settings Menu
            if showSettings {
                Color.black.opacity(0.4)
                    .edgesIgnoringSafeArea(.all)
                    .onTapGesture {
                        showSettings = false
                    }
                
                VStack(spacing: 20) {
                    Text("Customize Appearance")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.primary)
                    
                    // Text Color Picker
                    ColorPicker("Text Color", selection: $textColor)
                    
                    // Background Color Picker
                    ColorPicker("Background Color", selection: $backgroundColor)
                    
                    // Font Size Stepper
                    Stepper(value: $fontSize, in: 12...48, step: 2) {
                        Text("Font Size: \(Int(fontSize))")
                    }
                    
                    // Font Style Picker
                    Picker("Font Style", selection: $fontStyle) {
                        Text("Monospaced").tag(Font.Design.monospaced)
                        Text("Serif").tag(Font.Design.serif)
                        Text("Rounded").tag(Font.Design.rounded)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    
                    // Done Button
                    Button(action: {
                        showSettings = false
                    }) {
                        Text("Done")
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                }
                .padding()
                .background(Color(.systemBackground))
                .cornerRadius(15)
                .shadow(color: Color.black.opacity(0.2), radius: 10, x: 0, y: 5)
                .padding()
            }
        }
        .onAppear {
            startTypewriter()
        }
        .onDisappear {
            timer?.invalidate()
        }
    }
    
    // Start the typewriter animation
    func startTypewriter() {
        isAnimating = true
        timer?.invalidate()
        displayedText = ""
        
        var currentIndex = 0
        timer = Timer.scheduledTimer(withTimeInterval: animationSpeed, repeats: true) { _ in
            if currentIndex < fullText.count {
                let index = fullText.index(fullText.startIndex, offsetBy: currentIndex)
                displayedText.append(fullText[index])
                currentIndex += 1
            } else {
                timer?.invalidate()
                isAnimating = false
            }
        }
    }
    
    // Pause the typewriter animation
    func pauseTypewriter() {
        isAnimating = false
        timer?.invalidate()
    }
    
    // Reset the typewriter animation
    func resetTypewriter() {
        displayedText = ""
        startTypewriter()
    }
}
