//
//  TransferableDragDropApp.swift
//  TransferableDragDrop
//
//  Created by Altuğ Nuri ASLANTAŞ on 4.10.2024.
//

import SwiftUI

@main
struct TransferableDragDropApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
