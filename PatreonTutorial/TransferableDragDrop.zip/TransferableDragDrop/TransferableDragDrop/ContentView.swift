//
//  ContentView.swift
//  TransferableDragDrop
//
//  Created by Altuğ Nuri ASLANTAŞ on 4.10.2024.
//

import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var viewModel = SwiftUICodesViewModel()
    var body: some View {
        VStack {
            SwiftUICodesColumn(
                title: "To Do",
                tasks: viewModel.tasks.filter { $0.status == .toDo },
                isTargeted: $viewModel.isToDoTarget,
                onDrop: { droppedTasks in
                    viewModel.updateTasks(droppedTasks, to: .toDo)
                }
            )
            SwiftUICodesColumn(
                title: "In Progress",
                tasks: viewModel.tasks.filter { $0.status == .inProgress },
                isTargeted: $viewModel.isInProgressTarget,
                onDrop: { droppedTasks in
                    viewModel.updateTasks(droppedTasks, to: .inProgress)
                }
            )
            SwiftUICodesColumn(
                title: "Done",
                tasks: viewModel.tasks.filter { $0.status == .done },
                isTargeted: $viewModel.isDoneTarget,
                onDrop: { droppedTasks in
                    viewModel.updateTasks(droppedTasks, to: .done)
                }
            )
        }
    }
}
class SwiftUICodesViewModel: ObservableObject {
    @Published var tasks: [Task] = [
        Task(title: "Example1", status: .toDo),
        Task(title: "Example2", status: .toDo),
        Task(title: "Example3", status: .toDo)
    ]
    @Published var isToDoTarget: Bool = false
    @Published var isInProgressTarget: Bool = false
    @Published var isDoneTarget: Bool = false
    func updateTasks(_ droppedTasks: [Task], to status: TaskStatus) {
        for task in droppedTasks {
            if let index = tasks.firstIndex(where: { $0.id == task.id }) {
                tasks[index].status = status
            } else {
                var newTask = task
                newTask.status = status
                tasks.append(newTask)
            }
        }
    }
}

struct SwiftUICodesColumn: View {
    let title: String
    let tasks: [Task]
    @Binding var isTargeted: Bool
    let onDrop: ([Task]) -> Void
    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.footnote.bold())
                .padding(.bottom, 5)
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(isTargeted ? Color.teal.opacity(0.15) : Color(.secondarySystemFill))
                    .frame(maxWidth: .infinity)
                VStack(alignment: .leading, spacing: 12) {
                    ForEach(tasks) { task in
                        Text(task.title)
                            .padding(12)
                            .background(Color(uiColor: .secondarySystemGroupedBackground))
                            .cornerRadius(8)
                            .shadow(radius: 1, x: 1, y: 1)
                            .draggable(task)
                    }
                    Spacer()
                }
                .padding(.vertical)
            }
            .dropDestination(for: Task.self) { droppedTasks, _ in
                onDrop(droppedTasks)
                return true
            } isTargeted: { isOver in
                isTargeted = isOver
            }
        }
        .padding()
    }
}

struct Task: Identifiable, Hashable, Codable {
    let id: UUID
    var title: String
    var status: TaskStatus
    init(id: UUID = UUID(), title: String, status: TaskStatus) {
        self.id = id
        self.title = title
        self.status = status
    }
}

enum TaskStatus: String, Codable, Hashable {
    case toDo
    case inProgress
    case done
}

extension Task: Transferable {
    static var transferRepresentation: some TransferRepresentation {
        CodableRepresentation(contentType: .task)
    }
}

extension UTType {
    static var task: UTType {
        UTType(exportedAs: "com.swiftuicodes.transferable")
    }
}


#Preview {
    ContentView()
}
