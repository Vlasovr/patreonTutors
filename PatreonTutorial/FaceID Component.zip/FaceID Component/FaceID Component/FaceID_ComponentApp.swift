//
//  FaceID_ComponentApp.swift
//  FaceID Component
//
//  Created by Damra on 12.07.2024.
//

import SwiftUI

@main
struct FaceID_ComponentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
