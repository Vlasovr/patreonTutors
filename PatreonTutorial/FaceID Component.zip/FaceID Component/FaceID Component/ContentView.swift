//
//  ContentView.swift
//  FaceID Component
//
//  Created by Damra on 12.07.2024.
//

import LocalAuthentication
import SwiftUI

struct ContentView: View {
    @State private var isUnlocked = false
    var body: some View {
           VStack {
               if isUnlocked {
                   Text("Unlocked! 🎉")
                       .font(.largeTitle)
                       .padding()
                   
                   Button(action: {
                       self.isUnlocked = false
                   }) {
                       Text("Lock Again")
                           .foregroundColor(.white)
                           .padding()
                           .background(Color.red)
                           .cornerRadius(10)
                   }
               } else {
                   Text("Locked 🔒")
                       .font(.largeTitle)
                       .padding()
                   
                   Button(action: authenticate) {
                       Text("Unlock with FaceID")
                           .foregroundColor(.white)
                           .padding()
                           .background(Color.blue)
                           .cornerRadius(10)
                   }
               }
           }
           //.onAppear(perform: authenticate)
       }

    func authenticate() {
        let context = LAContext()
        var error: NSError?

        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            let reason = "We need to unlock your data"

            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) { success, _ in
                DispatchQueue.main.async {
                    if success {
                        self.isUnlocked = true
                    } else {
                        print("")
                    }
                }
            }

        } else {
            print("No Biometric")
        }
    }
}

#Preview {
    ContentView()
}
