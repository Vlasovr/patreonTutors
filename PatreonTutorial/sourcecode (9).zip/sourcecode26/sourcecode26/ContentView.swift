//
//  ContentView.swift
//  sourcecode26
//
//  Created by M.Damra on 28.01.2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        HeroAnimationView()
    }
}

#Preview {
    ContentView()
}
