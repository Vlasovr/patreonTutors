//
//  HeroItem.swift
//  sourcecode26
//
//  Created by M.Damra on 28.01.2025.
//

import Foundation
import SwiftUI

struct HeroItem: Identifiable {
    let id = UUID()
    let title: String
    let icon: String
    let color: Color
    let shortDescription: String
    let fullDescription: String
    let duration: Int
    let rating: Double
    let level: String
}
