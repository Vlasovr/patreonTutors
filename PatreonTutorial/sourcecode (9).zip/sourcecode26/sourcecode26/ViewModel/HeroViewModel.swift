//
//  HeroViewModel.swift
//  sourcecode26
//
//  Created by M.Damra on 28.01.2025.
//

import Foundation
import SwiftUI

class HeroViewModel: ObservableObject {
    @Published var selectedItem: HeroItem? = nil
    
    let items: [HeroItem] = [
        HeroItem(
            title: "Morning Yoga",
            icon: "sun.max.fill",
            color: .orange,
            shortDescription: "Start your day right",
            fullDescription: "A gentle morning yoga sequence designed to awaken your body and mind. Perfect for all levels, this session focuses on sun salutations and breathing techniques.",
            duration: 20,
            rating: 4.8,
            level: "BEginner"
        ),
        HeroItem(
            title: "Power Flow",
            icon: "bolt.fill",
            color: .purple,
            shortDescription: "Energizing workout",
            fullDescription: "Dynamic vinyasa flow to build strength and flexibility. This intermediate-level practice will challenge your balance and endurance.",
            duration: 45,
            rating: 4.9,
            level: "Intermediate"
        ),
        HeroItem(
            title: "Yin Relaxation",
            icon: "moon.fill",
            color: .indigo,
            shortDescription: "Deep stretch & relax",
            fullDescription: "Slow-paced yin yoga practice targeting deep connective tissues. Use props and hold poses longer to release tension and improve flexibility.",
            duration: 30,
            rating: 4.7,
            level: "All Levels"
        ),
        HeroItem(
            title: "Core Strength",
            icon: "flame.fill",
            color: .red,
            shortDescription: "Build core power",
            fullDescription: "Focus on building core strength and stability through targeted exercises and yoga poses. Suitable for intermediate to advanced practitioners.",
            duration: 25,
            rating: 4.6,
            level: "Advanced"
        )
    ]
}
