//
//  sourcecode26App.swift
//  sourcecode26
//
//  Created by M.Damra on 28.01.2025.
//

import SwiftUI

@main
struct sourcecode26App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
