//
//  GridItemView.swift
//  sourcecode26
//
//  Created by M.Damra on 28.01.2025.
//

import Foundation
import SwiftUI

struct GridItemView: View {
    let item: HeroItem
    let namespace: Namespace.ID
    var body: some View {
        VStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(item.color.gradient)
                .matchedGeometryEffect(id: "background\(item.id)", in: namespace)
                .frame(height: 150)
                .overlay(
                    VStack {
                        Image(systemName: item.icon)
                            .font(.system(size: 40))
                            .matchedGeometryEffect(id: "icon\(item.id)", in: namespace)
                        Text(item.title)
                            .font(.headline)
                            .matchedGeometryEffect(id: "title\(item.id)", in: namespace)
                    }
                        .foregroundStyle(.white)
                )
            
            Text(item.shortDescription)
                .font(.caption)
                .foregroundColor(.secondary)
                .padding(.bottom, 8)
        }
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(Color(.systemBackground))
                .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
        )
        .matchedGeometryEffect(id: "card\(item.id)", in: namespace)
    }
}
