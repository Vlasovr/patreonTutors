//
//  InfoBadge.swift
//  sourcecode26
//
//  Created by M.Damra on 28.01.2025.
//

import Foundation
import SwiftUI

struct InfoBadge: View {
    let title: String
    let value: String
    var body: some View {
        VStack {
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
            Text(value)
                .font(.system(size: 18, weight: .bold))
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .cornerRadius(12)
    }
}
