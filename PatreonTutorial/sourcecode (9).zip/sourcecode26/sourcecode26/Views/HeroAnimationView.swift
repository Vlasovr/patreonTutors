//
//  HeroAnimationView.swift
//  sourcecode26
//
//  Created by M.Damra on 28.01.2025.
//

import Foundation
import SwiftUI

struct HeroAnimationView: View {
    @Namespace private var animationNamespace
    @StateObject private var viewModel = HeroViewModel()
    var body: some View {
        ZStack {
            // GridView
            ScrollView {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 20), count: 2), spacing: 20) {
                    ForEach(viewModel.items) { item in
                        GridItemView(item: item, namespace: animationNamespace)
                            .onTapGesture {
                                withAnimation(.bouncy) {
                                    viewModel.selectedItem = item
                                }
                            }
                    }
                }
                .padding()
            }
            .opacity(viewModel.selectedItem == nil ? 1 : 0)
            
            // Detail View
            if let selectedItem = viewModel.selectedItem {
                DetailView(
                    item: selectedItem,
                    namespace: animationNamespace,
                    dismiss: {
                        viewModel.selectedItem = nil
                    }
                )
                .zIndex(1)
                .transition(.asymmetric(insertion: .opacity, removal: .opacity))
            }
        }
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
    }
}

#Preview {
    ContentView()
}
