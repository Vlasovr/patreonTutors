//
//  DetailView.swift
//  sourcecode26
//
//  Created by M.Damra on 28.01.2025.
//

import Foundation
import SwiftUI

struct DetailView: View {
    let item: HeroItem
    let namespace: Namespace.ID
    let dismiss: () -> Void
    
    @State private var dragOffset: CGSize = .zero
    @GestureState private var isDragging = false
    var body: some View {
        ZStack(alignment: .topTrailing) {
            ScrollView {
                VStack(spacing: 30) {
                    // Hero Image
                    RoundedRectangle(cornerRadius: 30)
                        .fill(item.color.gradient)
                        .matchedGeometryEffect(id: "background\(item.id)", in: namespace)
                        .frame(height: 400)
                        .overlay(
                            VStack {
                                Image(systemName: item.icon)
                                    .font(.system(size: 60))
                                    .matchedGeometryEffect(id: "icon\(item.id)", in: namespace)
                                Text(item.title)
                                    .font(.largeTitle.bold())
                            }
                                .foregroundStyle(.white)
                        )
                        .offset(y: -dragOffset.height * 0.5)
                        .gesture(
                            DragGesture()
                                .onChanged { value in
                                    dragOffset = value.translation
                                }
                                .onEnded { value in
                                    if abs(value.translation.height) > 200 {
                                        withAnimation {
                                            dismiss()
                                        }
                                    }
                                    dragOffset = .zero
                                }
                        )
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Detailed Information")
                            .font(.title2.bold())
                        
                        Text(item.fullDescription)
                            .foregroundColor(.secondary)
                        
                        HStack {
                            InfoBadge(title: "Level", value: item.level)
                            InfoBadge(title: "Duration", value: "\(item.duration) min")
                            InfoBadge(title: "Rating", value: "\(item.rating)")
                        }
                    }
                    .padding()
                }
            }
            .background(
                RoundedRectangle(cornerRadius: 30)
                    .fill(Color(.systemBackground))
                    .matchedGeometryEffect(id: "card\(item.id)", in: namespace)
            )
            .ignoresSafeArea()
            
            // close button
            Button {
                withAnimation(.bouncy) {
                    dismiss()
                }
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 30))
                    .foregroundColor(.white)
                    .padding(8)
                    .background(.ultraThinMaterial, in: Circle())
            }
            .padding(30)
            .offset(x: dragOffset.width * 0.1, y: dragOffset.height * 0.1)
        }
        .offset(dragOffset)
        .scaleEffect(isDragging ? 0.95 : 1)
        .background(
            Color.black
                .opacity(0.4 * Double(abs(dragOffset.height / 500)))
                .ignoresSafeArea()
                .onTapGesture {
                    dismiss()
                }
        )
    }
}
