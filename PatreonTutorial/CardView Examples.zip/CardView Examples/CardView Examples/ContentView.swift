//
//  ContentView.swift
//  CardView Examples
//
//  Created by Damra on 19.10.2023.
//

import SwiftUI
import CollectionViewPagingLayout


struct ContentView: View {
    @State var selection = 1
    var body: some View {
        
        TabView(selection: $selection) {
            stackView().tabItem { Text("StackPageView") }.tag(1)
            ScaleTransformView().tabItem{Text("ScaleTransformView")}.tag(2)
            SnapShotView().tabItem{Text("SnapShotView")}.tag(3)
        }
    }
}

#Preview {
    ContentView()
}

struct stackView: View {
    //Replace with your data
    struct Item: Identifiable {
        let id: UUID = .init()
        let number: Int
    }
    let items = Array(0..<7).map {
        Item(number: $0)
    }
    
    var options: StackTransformViewOptions {
        .layout(.rotary)
    }
    
    var body: some View {
        StackPageView(items) { item in
            // Build your view here
            ZStack{
                RoundedRectangle(cornerRadius: 25).fill(Color.orange)
                Text("\(item.number)")
            }
        }
        .options(options)
        //The padding arround each page
        //You can use '.fractionalWidth' and '.fractionalHeight'
        .pagePadding(vertical: .absolute(100), horizontal: .absolute(80))
    }
}

struct ScaleTransformView: View {
    //Replace with your data
    struct Item: Identifiable {
        let id: UUID = .init()
        let number: Int
    }
    let items = Array(0..<7).map {
        Item(number: $0)
    }
    
    var options: ScaleTransformViewOptions {
        .layout(.invertedCylinder)
    }
    
    var body: some View {
        ScalePageView(items) { item in
            ZStack{
                RoundedRectangle(cornerRadius: 25).fill(Color.indigo)
                Text("\(item.number)")
            }
        }
        .options(options)
        //The padding arround each page
        //You can use '.fractionalWidth' and '.fractionalHeight'
        .pagePadding(vertical: .absolute(100), horizontal: .absolute(80))
    }
}

struct SnapShotView: View {
    //Replace with your data
    struct Item: Identifiable {
        let id: UUID = .init()
        let number: Int
    }
    let items = Array(0..<7).map {
        Item(number: $0)
    }
    
    var options: SnapshotTransformViewOptions {
        .layout(.puzzle)
    }
    var body: some View {
        SnapshotPageView(items) { item in
            ZStack{
                RoundedRectangle(cornerRadius: 25).fill(Color.green)
                Text("\(item.number)")
            }
        }
        .options(options)
        //The padding arround each page
        //You can use '.fractionalWidth' and '.fractionalHeight'
        .pagePadding(vertical: .absolute(100), horizontal: .absolute(80))
    }
}
