import SwiftUI
import Zip // Import the Zip library for zip/unzip functionality

struct ContentView: View {
    // State variables to manage zipping and unzipping processes
    @State private var isProcessing = false
    @State private var message = ""
    @State private var progress: Double = 0.0

    var body: some View {
        // Use a ZStack to set a background color
        ZStack {
            // Background gradient
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.3), Color.purple.opacity(0.3)]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all) // Extend the gradient to cover the entire screen
            
            VStack(spacing: 40) { // Vertical stack with spacing between elements
                // App title
                Text("File Compressor")
                    .font(.largeTitle) // Large font size for the title
                    .fontWeight(.bold) // Bold text
                    .foregroundColor(.white) // White text color
                    .shadow(radius: 10) // Add shadow for depth

                // Image representing compression
                Image(systemName: "archivebox")
                    .resizable() // Make the image resizable
                    .scaledToFit() // Scale the image to fit its container
                    .frame(width: 100, height: 100) // Set image size
                    .foregroundColor(.white) // White color
                    .shadow(radius: 10) // Add shadow

                // HStack containing Zip and Unzip buttons
                HStack(spacing: 30) {
                    // Zip Button
                    Button(action: {
                        zipFiles() // Call the zipFiles function when tapped
                    }) {
                        VStack {
                            Image(systemName: "folder.fill.badge.plus") // Icon for zipping
                                .font(.largeTitle) // Large icon size
                                .padding()
                                .background(Color.green) // Green background
                                .foregroundColor(.white) // White icon color
                                .clipShape(Circle()) // Circular shape
                                .shadow(radius: 5) // Shadow effect
                            
                            Text("Zip Files") // Button label
                                .foregroundColor(.white) // White text color
                                .fontWeight(.semibold) // Semi-bold text
                        }
                    }
                    .disabled(isProcessing) // Disable button while processing

                    // Unzip Button
                    Button(action: {
                        unzipFiles() // Call the unzipFiles function when tapped
                    }) {
                        VStack {
                            Image(systemName: "folder.fill.badge.minus") // Icon for unzipping
                                .font(.largeTitle) // Large icon size
                                .padding()
                                .background(Color.orange) // Orange background
                                .foregroundColor(.white) // White icon color
                                .clipShape(Circle()) // Circular shape
                                .shadow(radius: 5) // Shadow effect
                            
                            Text("Unzip Files") // Button label
                                .foregroundColor(.white) // White text color
                                .fontWeight(.semibold) // Semi-bold text
                        }
                    }
                    .disabled(isProcessing) // Disable button while processing
                }

                // Progress Indicator
                if isProcessing {
                    VStack {
                        ProgressView(value: progress) // Progress bar showing current progress
                            .progressViewStyle(LinearProgressViewStyle(tint: .white)) // White progress bar
                            .padding()
                        
                        Text("Processing... \(Int(progress * 100))%") // Display progress percentage
                            .foregroundColor(.white) // White text color
                            .fontWeight(.medium) // Medium text weight
                    }
                }

                // Message Display
                Text(message) // Display status messages
                    .foregroundColor(.white) // White text color
                    .padding()
                    .background(Color.black.opacity(0.5)) // Semi-transparent black background
                    .cornerRadius(10) // Rounded corners
            }
            .padding() // Add padding around the VStack
        }
    }
    
    // Function to zip files
    func zipFiles() {
        isProcessing = true // Indicate that processing has started
        message = "Starting to zip files..." // Update message
        progress = 0.0 // Reset progress

        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let fileManager = FileManager.default // Access the file manager
                let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0] // Get the documents directory
                let filesToZip = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil) // Retrieve files to zip
                
                let zipFilePath = documentsURL.appendingPathComponent("Archive.zip") // Define the zip file path
                
                // Remove existing zip file if it exists
                if fileManager.fileExists(atPath: zipFilePath.path) {
                    try fileManager.removeItem(at: zipFilePath)
                }
                
                // Perform the zipping process
                try Zip.zipFiles(paths: filesToZip, zipFilePath: zipFilePath, password: nil, progress: { currentProgress in
                    DispatchQueue.main.async {
                        self.progress = currentProgress // Update progress on the main thread
                    }
                })
                
                DispatchQueue.main.async {
                    self.message = "Files successfully zipped to \(zipFilePath.lastPathComponent)" // Update message on success
                    self.isProcessing = false // Indicate that processing has finished
                }
            } catch {
                DispatchQueue.main.async {
                    self.message = "Error zipping files: \(error.localizedDescription)" // Update message on error
                    self.isProcessing = false // Indicate that processing has finished
                }
            }
        }
    }
    
    // Function to unzip files
    func unzipFiles() {
        isProcessing = true // Indicate that processing has started
        message = "Starting to unzip files..." // Update message
        progress = 0.0 // Reset progress

        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let fileManager = FileManager.default // Access the file manager
                let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0] // Get the documents directory
                let zipFilePath = documentsURL.appendingPathComponent("Archive.zip") // Define the zip file path
                
                // Check if the zip file exists
                guard fileManager.fileExists(atPath: zipFilePath.path) else {
                    DispatchQueue.main.async {
                        self.message = "Zip file not found." // Update message if zip file is missing
                        self.isProcessing = false // Indicate that processing has finished
                    }
                    return
                }
                
                // Perform the unzipping process
                try Zip.unzipFile(zipFilePath, destination: documentsURL, overwrite: true, password: nil, progress: { currentProgress in
                    DispatchQueue.main.async {
                        self.progress = currentProgress // Update progress on the main thread
                    }
                })
                
                DispatchQueue.main.async {
                    self.message = "Files successfully unzipped." // Update message on success
                    self.isProcessing = false // Indicate that processing has finished
                }
            } catch {
                DispatchQueue.main.async {
                    self.message = "Error unzipping files: \(error.localizedDescription)" // Update message on error
                    self.isProcessing = false // Indicate that processing has finished
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView() // Preview the ContentView
    }
}
