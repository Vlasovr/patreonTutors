//
//  zipandunzipApp.swift
//  zipandunzip
//
//  Created by Altuğ Nuri ASLANTAŞ on 30.11.2024.
//

import SwiftUI

@main
struct zipandunzipApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
