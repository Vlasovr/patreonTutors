//
//  sourcecode30App.swift
//  sourcecode30
//
//  Created by M.Damra on 29.01.2025.
//

import SwiftUI

@main
struct sourcecode30App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
