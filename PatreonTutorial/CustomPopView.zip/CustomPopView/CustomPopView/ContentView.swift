
import SwiftUI

struct ContentView: View {
    @State private var showPasswordPopup: Bool = false
    @State private var showErrorPopup: Bool = false
    @State private var isIncorrectPassword: Bool = false
    @State private var isRetrying: Bool = false
    
    let items = (1...20).map { "Item \($0)" } // Titles for the cards
    
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: [
                    GridItem(.adaptive(minimum: 150))
                ], spacing: 16) {
                    ForEach(items, id: \ .self) { item in
                        CardView(title: item)
                    }
                }
                .padding()
            }
            .navigationTitle("Documents")
            
            Button("Unlock File") {
                showPasswordPopup.toggle()
            }
            .padding()
        }
        .popupView(isPresented: $showPasswordPopup) {
            showErrorPopup = isIncorrectPassword
            isIncorrectPassword = false
        } content: {
            PasswordPrompt(show: $showPasswordPopup) { password in
                if password == "123456" {
                    print("Unlocked")
                } else {
                    isIncorrectPassword = true
                }
            }
        }
        .popupView(isPresented: $showErrorPopup) {
            showPasswordPopup = isRetrying
            isRetrying = false
        } content: {
            ErrorAlert(show: $showErrorPopup) {
                isRetrying = true
            }
        }
    }
}


struct ErrorAlert: View {
    @Binding var show: Bool
    var onRetry: () -> ()
    
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: "lock.trianglebadge.exclamationmark.fill")
                .font(.title)
                .foregroundStyle(.white)
                .frame(width: 65, height: 65)
                .background {
                    Circle()
                        .fill(.red.gradient)
                        .background {
                            Circle()
                                .fill(.background)
                                .padding(-5)
                        }
                }
            
            Text("Wrong Password")
                .fontWeight(.semibold)
            
            Text("Please enter the correct password to unlock the file.")
                .multilineTextAlignment(.center)
                .font(.caption)
                .foregroundStyle(.gray)
                .padding(.top, 5)
            
            HStack(spacing: 10) {
                Button {
                    show = false
                } label: {
                    Text("Cancel")
                        .foregroundStyle(.white)
                        .fontWeight(.semibold)
                        .padding(.vertical, 8)
                        .padding(.horizontal, 25)
                        .background {
                            RoundedRectangle(cornerRadius: 12)
                                .fill(.red.gradient)
                        }
                }
                
                Button {
                    show = false
                    onRetry()
                } label: {
                    Text("Try Again")
                        .foregroundStyle(.white)
                        .fontWeight(.semibold)
                        .padding(.vertical, 8)
                        .padding(.horizontal, 25)
                        .background {
                            RoundedRectangle(cornerRadius: 12)
                                .fill(.blue.gradient)
                        }
                }
            }
            .padding(.top, 10)
        }
        .frame(width: 250)
        .padding([.horizontal, .bottom], 20)
        .background {
            RoundedRectangle(cornerRadius: 25)
                .fill(.background)
                .padding(.top, 25)
        }
    }
}

struct CardView: View {
    let title: String
    
    var body: some View {
        VStack {
            Image(systemName: "doc.text")
                .resizable()
                .scaledToFit()
                .frame(height: 100)
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 15)
                        .fill(Color.blue.opacity(0.2))
                )
            
            Text(title)
                .font(.headline)
                .foregroundColor(.primary)
                .multilineTextAlignment(.center)
                .padding(.top, 8)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 15)
                .fill(Color.white)
                .shadow(color: .gray.opacity(0.4), radius: 4, x: 2, y: 2)
        )
    }
}

struct PopupConfig {
    var backgroundColor: Color = Color.primary.opacity(0.25)
}


struct PopupModifier<PopupContent: View>: ViewModifier {
    var config: PopupConfig
    @Binding var isPresented: Bool
    var onDismiss: () -> ()
    @ViewBuilder var popupContent: PopupContent
    @State private var showPopup: Bool = false
    @State private var animatePopup: Bool = false
    
    func body(content: Content) -> some View {
        let screenHeight = screenSize.height
        
        content
            .fullScreenCover(isPresented: $showPopup, onDismiss: onDismiss) {
                ZStack {
                    Rectangle()
                        .fill(config.backgroundColor)
                        .ignoresSafeArea()
                        .opacity(animatePopup ? 1 : 0)
                    
                    popupContent
                        .offset(y: animatePopup ? 0 : (screenHeight / 2))
                        .task {
                            guard !animatePopup else { return }
                            withAnimation(.spring()) {
                                self.animatePopup = true
                            }
                        }
                        .ignoresSafeArea(.container, edges: .all)
                }
            }
            .onChange(of: isPresented) { newValue in
                if newValue {
                    togglePopup(true)
                } else {
                    Task {
                        withAnimation(.easeIn) {
                            self.animatePopup = false
                        }
                        try? await Task.sleep(for: .seconds(0.4))
                        togglePopup(false)
                    }
                }
            }
    }
    
    func togglePopup(_ state: Bool) {
        var transaction = Transaction()
        transaction.disablesAnimations = true
        
        withTransaction(transaction) {
            showPopup = state
        }
    }
    
    var screenSize: CGSize {
        UIScreen.main.bounds.size
    }
}

#Preview {
    ContentView()
}

