//
//  ShopAppTemplateApp.swift
//  ShopAppTemplate
//
//  Created by Damra on 19.12.2024.
//

import SwiftUI

@main
struct ShopAppTemplateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
