//
//  ProductCard.swift
//  ShopAppTemplate
//
//  Created by Damra on 19.12.2024.
//

import Foundation
import SwiftUI

// Product Card
struct ProductCard: View {
    let product: Product
    let onPress: () -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.gray.opacity(0.1))
                
                if let imageUrl = product.images.first, let url = URL(string: imageUrl) {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case let .success(image):
                            image
                                .resizable()
                                .scaledToFit()
                                .padding(20)
                        default:
                            ProgressView()
                        }
                    }
                }
            }
            .aspectRatio(1.0, contentMode: .fit)
            
            Text(product.title)
                .font(.body)
                .lineLimit(2)
            
            HStack {
                Text("$\(product.price, specifier: "%.2f")")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(Color(red: 1.0, green: 0.46, blue: 0.26))
                
                Spacer()
                
                Button(action: {}) {
                    Circle()
                        .fill(product.isFavourite ? Color(red: 1.0, green: 0.46, blue: 0.26).opacity(0.15)
                              : Color.gray.opacity(0.1))
                        .frame(width: 24, height: 24)
                        .overlay(
                            Image(systemName: product.isFavourite ? "heart.fill" : "heart")
                                .foregroundColor(product.isFavourite ? Color.red : Color.gray)
                                .font(.system(size: 12))
                            )
                }
            }
        }
        .onTapGesture {
            onPress()
        }
    }
}

struct Product: Identifiable {
    let id: Int
    let title: String
    let description: String
    let images: [String]
    let colors: [Color]
    let rating: Double
    let price: Double
    let isFavourite: Bool
    let isPopular: Bool
}
