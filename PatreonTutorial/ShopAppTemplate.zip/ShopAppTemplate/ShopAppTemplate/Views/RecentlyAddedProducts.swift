//
//  RecentlyAddedProducts.swift
//  ShopAppTemplate
//
//  Created by Damra on 19.12.2024.
//

import Foundation
import SwiftUI

// Recently Added Products Section
struct RecentlyAddedProducts: View {
    let products: [Product]
    var body: some View {
        VStack(spacing: 16) {
            PaddingView {
                SectionTitle(title: "Recently Added", action: {})
            }
            
            PaddingView {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                    ForEach(products) { product in
                        ProductCard(product: product, onPress: {})
                    }
                }
            }
        }
    }
}
