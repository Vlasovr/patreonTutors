//
//  PaddingView.swift
//  ShopAppTemplate
//
//  Created by Damra on 19.12.2024.
//

import Foundation
import SwiftUI

// A little help for view padding
struct PaddingView<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }
    var body: some View {
        HStack {
            content
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 20)
    }
    
}
