//
//  HomeView.swift
//  ShopAppTemplate
//
//  Created by Damra on 19.12.2024.
//

import Foundation
import SwiftUI

struct HomeView: View {
    @State private var searchText: String = ""
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    HomeHeader(searchText: $searchText)
                    DiscountBanner()
                    PopularProducts(products: demoProduct)
                    RecentlyAddedProducts(products: demoProduct)
                }
                .padding(.vertical, 16)
            }
            .navigationBarBackButtonHidden()
        }
    }
}

#Preview {
    HomeView()
}


let demoProduct: [Product] = [
    Product(
        id: 1,
        title: "Wireless Controller for PS4™",
        description: description,
        images: ["https://pisces.bbystatic.com/image2/BestBuy_US/images/products/6356/6356223_sd.jpg;maxHeight=640;maxWidth=550;format=webp"],
        colors: [Color(red: 0.96, green: 0.39, blue: 0.37),
                 Color(red: 0.51, green: 0.43, blue: 0.72),
                 Color(red: 0.87, green: 0.80, blue: 0.61),
                 Color.white],
        rating: 4.8,
        price: 64.99,
        isFavourite: true,
        isPopular: true
    ),
    Product(
        id: 2,
        title: "Nike Sport White - Man Pant",
        description: description,
        images: ["https://media.karousell.com/media/photos/products/2023/9/23/_nike_m6xl_unisex_shorts_casua_1695488952_31bbc946_progressive.jpg"],
        colors: [Color(red: 0.96, green: 0.39, blue: 0.37),
                 Color(red: 0.51, green: 0.43, blue: 0.72),
                 Color(red: 0.87, green: 0.80, blue: 0.61),
                 Color.white],
        rating: 4.1,
        price: 50.5,
        isFavourite: false,
        isPopular: true
    ),
    Product(
        id: 3,
        title: "Gloves XC Omega - Polygon",
        description: description,
        images: ["https://www.static-src.com/wcsstore/Indraprastha/images/catalog/full//102/MTA-93185715/no-brand_sarung-tangan-sepeda-gloves-xc-beval-polygon-original_full01.jpg"],
        colors: [Color(red: 0.96, green: 0.39, blue: 0.37),
                 Color(red: 0.51, green: 0.43, blue: 0.72),
                 Color(red: 0.87, green: 0.80, blue: 0.61),
                 Color.white],
        rating: 4.1,
        price: 36.55,
        isFavourite: true,
        isPopular: true
    ),
    Product(
        id: 4,
        title: "Gloves XC Omega - Polygon",
        description: description,
        images: ["https://productimages.hepsiburada.net/s/147/960-1280/110000102168222.jpg"],
        colors: [Color(red: 0.96, green: 0.39, blue: 0.37),
                 Color(red: 0.51, green: 0.43, blue: 0.72),
                 Color(red: 0.87, green: 0.80, blue: 0.61),
                 Color.white],
        rating: 4.1,
        price: 36.55,
        isFavourite: false,
        isPopular: true
    )
]

let description = ""
