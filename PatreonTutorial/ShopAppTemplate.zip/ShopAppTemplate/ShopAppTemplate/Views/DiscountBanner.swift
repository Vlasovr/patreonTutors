//
//  DiscountBanner.swift
//  ShopAppTemplate
//
//  Created by Damra on 19.12.2024.
//

import Foundation
import SwiftUI

// Discount Banner
struct DiscountBanner: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("A Summer Surprise")
            Text("Cashback 20%")
                .font(.system(size: 24, weight: .bold))
        }
        .foregroundColor(.white)
        .padding(.horizontal, 20)
        .padding(.vertical, 16)
        .frame(maxWidth: .infinity)
        .background(Color(red: 0.29, green: 0.20, blue: 0.60))
        .cornerRadius(20)
        .padding(.horizontal, 20)
    }
}
