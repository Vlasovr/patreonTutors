//
//  SearchField.swift
//  ShopAppTemplate
//
//  Created by Damra on 19.12.2024.
//

import Foundation
import SwiftUI

// Search Field
struct SearchField: View {
    @Binding var text: String
    var body: some View {
        TextField("Search product", text: $text)
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(12)
    }
}
