//
//  PopularProducts.swift
//  ShopAppTemplate
//
//  Created by Damra on 19.12.2024.
//

import Foundation
import SwiftUI

// Popular Products Section
struct PopularProducts: View {
    let products: [Product]
    var body: some View {
        VStack(spacing: 16){
            PaddingView {
                SectionTitle(title: "Popular Products", action: {})
            }
            
            PaddingView {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                    ForEach(products) { product in
                        ProductCard(product: product, onPress: {})
                    }
                }
            }
        }
    }
}
