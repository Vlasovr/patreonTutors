//
//  IconBtnWithCounter.swift
//  ShopAppTemplate
//
//  Created by Damra on 19.12.2024.
//

import Foundation
import SwiftUI

// IconBtnWithCounter
struct IconBtnWithCounter: View {
    let iconName: String
    let count: Int
    let action: () -> Void
    var body: some View {
        Button {
            action()
        } label: {
            ZStack(alignment: .topTrailing) {
                Circle()
                    .fill(Color.gray.opacity(0.1))
                    .frame(width: 46, height: 46)
                Image(systemName: iconName)
                    .renderingMode(.template)
                    .foregroundColor(.gray)
                    .font(.system(size: 20))
                    .offset(x: -10, y: 10)

                if count > 0 {
                    Circle()
                        .fill(Color.red)
                        .frame(width: 20, height: 20)
                        .overlay(
                            Text("\(count)")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundColor(.white)
                        )
                }
            }
        }
    }
}
