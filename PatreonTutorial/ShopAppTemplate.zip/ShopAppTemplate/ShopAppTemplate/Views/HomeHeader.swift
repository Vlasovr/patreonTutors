//
//  HomeHeader.swift
//  ShopAppTemplate
//
//  Created by Damra on 19.12.2024.
//

import Foundation
import SwiftUI

// Home Header
struct HomeHeader: View {
    @Binding var searchText: String
    var body: some View {
        HStack {
            SearchField(text: $searchText)
            Spacer(minLength: 16)
            IconBtnWithCounter(iconName: "cart", count: 0, action: {})
            Spacer(minLength: 8)
            IconBtnWithCounter(iconName: "bell", count: 3, action: {})
        }
        .padding(.horizontal, 20)
    }
}
