//
//  SectionTitle.swift
//  ShopAppTemplate
//
//  Created by Damra on 19.12.2024.
//

import Foundation
import SwiftUI

struct SectionTitle: View {
    let title: String
    let action: () -> Void
    var body: some View {
        HStack {
            Text(title)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.black)
            Spacer()
            Button(action: action) {
                Text("See more")
                    .foregroundColor(.gray)
            }
        }
    }
}
