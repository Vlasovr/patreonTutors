import SwiftUI
import Combine

struct ContentView: View {
    @State private var isBreathing = false
    @State private var breathPhase = 0 // 0: Inhale, 1: Hold, 2: Exhale
    @State private var animationScale: CGFloat = 1.0
    @State private var flowerRotation: Double = 0.0
    @State private var petalOpacity: Double = 0.0
    @State private var stars: [Star] = []
    @State private var blossomScale: CGFloat = 0.8
    @State private var blossomOpacity: Double = 0.0
    
    // Timer to handle breath phases
    let timer = Timer.publish(every: 4, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack {
            // Night Background with Stars and Gradient Overlay
            NightBackgroundView(stars: stars)
                .edgesIgnoringSafeArea(.all)
                .onAppear {
                    generateStars()
                }
            
            VStack {
                Spacer()
                
                // Animated Breathing Circle with Centered Text
                ZStack {
                    Circle()
                        .fill(
                            RadialGradient(gradient: Gradient(colors: [Color.white.opacity(0.8), Color.blue]),
                                           center: .center,
                                           startRadius: 20,
                                           endRadius: 200)
                        )
                        .frame(width: 200 * animationScale, height: 200 * animationScale)
                        .shadow(color: Color.blue.opacity(0.7), radius: 10, x: 0, y: 0)
                        .animation(Animation.easeInOut(duration: 4).repeatForever(autoreverses: true), value: animationScale)
                        .onAppear {
                            startBreathingAnimation()
                        }
                    
                    // Centered Breath Phase Text
                    Text(currentPhaseText())
                        .font(.system(size: 40, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .transition(.opacity)
                        .animation(.easeInOut, value: breathPhase)
                        .padding(5)
                        .background(Color.black.opacity(0.5))
                        .cornerRadius(10)
                }
                
                // Realistic Flower Animation
                RealisticFlowerView(rotation: flowerRotation, petalOpacity: petalOpacity, blossomScale: blossomScale, blossomOpacity: blossomOpacity)
                    .frame(width: 150, height: 150)
                    .shadow(color: Color.purple.opacity(0.7), radius: 10, x: 0, y: 0)
                    .animation(Animation.easeInOut(duration: 4).repeatForever(autoreverses: true), value: flowerRotation)
                    .onAppear {
                        startFlowerAnimation()
                    }
                
                Spacer()
            }
            
            // Fixed Start/Stop Button at the Bottom
            VStack {
                Spacer()
                
                Button(action: {
                    toggleBreathing()
                }) {
                    HStack {
                        Image(systemName: isBreathing ? "pause.circle.fill" : "play.circle.fill")
                            .font(.title)
                        Text(isBreathing ? "Stop" : "Start")
                            .font(.headline)
                            .fontWeight(.semibold)
                    }
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue.opacity(0.8))
                    .cornerRadius(20)
                    .shadow(color: Color.blue.opacity(0.7), radius: 5, x: 0, y: 0)
                    .padding(.horizontal, 20)
                }
                .padding(.bottom, safeAreaInsets().bottom > 0 ? safeAreaInsets().bottom + 20 : 20)
            }
            
            // Moving Starfield Overlay
            StarFieldView(stars: stars)
        }
        .onReceive(timer) { _ in
            guard self.isBreathing else { return }
            self.breathPhase = (self.breathPhase + 1) % 3
            updateBreathPhase()
        }
    }
    
    // MARK: - Helper Functions
    
    // Starts the breathing animation
    func startBreathingAnimation() {
        self.animationScale = 1.5
        self.isBreathing = true
    }
    
    // Starts the flower animation
    func startFlowerAnimation() {
        withAnimation {
            self.flowerRotation = 360
            self.petalOpacity = 1.0
            self.blossomScale = 1.0
            self.blossomOpacity = 1.0
        }
    }
    
    // Toggles the breathing session
    func toggleBreathing() {
        self.isBreathing.toggle()
        if self.isBreathing {
            startBreathingAnimation()
            startFlowerAnimation()
        } else {
            self.animationScale = 1.0
            self.flowerRotation = 0.0
            self.petalOpacity = 0.0
            withAnimation {
                self.blossomScale = 0.8
                self.blossomOpacity = 0.0
            }
        }
    }
    
    // Returns the current breath phase text
    func currentPhaseText() -> String {
        switch breathPhase {
        case 0:
            return "Inhale"
        case 1:
            return "Hold"
        case 2:
            return "Exhale"
        default:
            return ""
        }
    }
    
    // Updates visual elements based on breath phase
    func updateBreathPhase() {
        switch breathPhase {
        case 0: // Inhale
            withAnimation(.easeInOut(duration: 4)) {
                self.animationScale = 1.5
                self.flowerRotation += 30
                self.blossomScale = 1.0
                self.blossomOpacity = 1.0
            }
        case 1: // Hold
            withAnimation(.easeInOut(duration: 2)) {
                self.animationScale = 1.5
                self.flowerRotation += 15
                self.blossomScale = 1.05
                self.blossomOpacity = 1.0
            }
        case 2: // Exhale
            withAnimation(.easeInOut(duration: 4)) {
                self.animationScale = 1.0
                self.flowerRotation += 30
                self.blossomScale = 0.8
                self.blossomOpacity = 0.0
            }
        default:
            break
        }
    }
    
    // Generates a list of stars with random positions and properties
    func generateStars() {
        var generatedStars: [Star] = []
        for _ in 0..<100 {
            let star = Star(
                id: UUID(),
                position: CGPoint(x: CGFloat.random(in: 0...UIScreen.main.bounds.width),
                                 y: CGFloat.random(in: 0...UIScreen.main.bounds.height)),
                size: CGFloat.random(in: 1...3),
                opacity: Double.random(in: 0.3...1.0),
                twinkleDuration: Double.random(in: 1.0...3.0)
            )
            generatedStars.append(star)
        }
        self.stars = generatedStars
    }
    
    // Retrieves safe area insets
    func safeAreaInsets() -> UIEdgeInsets {
        UIApplication.shared.windows.first?.safeAreaInsets ?? UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
}

struct NightBackgroundView: View {
    var stars: [Star]
    
    var body: some View {
        ZStack {
            // Dark Gradient Background
            LinearGradient(gradient: Gradient(colors: [Color.black, Color.blue.opacity(0.7)]),
                           startPoint: .top,
                           endPoint: .bottom)
            ForEach(stars) { star in
                Circle()
                    .fill(Color.white.opacity(star.opacity))
                    .frame(width: star.size, height: star.size)
                    .position(star.position)
            }
        }
    }
}

struct StarFieldView: View {
    var stars: [Star]
    
    var body: some View {
        ForEach(stars) { star in
            Circle()
                .fill(Color.white.opacity(star.opacity))
                .frame(width: star.size, height: star.size)
                .position(star.position)
                .animation(Animation.linear(duration: star.twinkleDuration).repeatForever(autoreverses: true).speed(Double.random(in: 0.5...1.5)), value: star.opacity)
                .onAppear {
                    // Trigger twinkling effect by toggling opacity
                }
        }
    }
}

struct Star: Identifiable {
    let id: UUID
    var position: CGPoint
    var size: CGFloat
    var opacity: Double
    var twinkleDuration: Double
}

struct RealisticFlowerView: View {
    var rotation: Double
    var petalOpacity: Double
    var blossomScale: CGFloat
    var blossomOpacity: Double
    
    var body: some View {
        ZStack {
            // Petals
            ForEach(0..<8) { i in
                Petal()
                    .rotationEffect(.degrees(Double(i) * 45))
                    .opacity(petalOpacity)
            }
            // Blossom Center
            Circle()
                .fill(
                    RadialGradient(gradient: Gradient(colors: [Color.yellow, Color.orange]),
                                   center: .center,
                                   startRadius: 10,
                                   endRadius: 30)
                )
                .frame(width: 50, height: 50)
                .scaleEffect(blossomScale)
                .opacity(blossomOpacity)
                .shadow(color: Color.orange.opacity(0.7), radius: 10, x: 0, y: 0)
        }
        .rotationEffect(.degrees(rotation))
    }
}

struct Petal: View {
    var body: some View {
        Ellipse()
            .fill(
                LinearGradient(gradient: Gradient(colors: [Color.pink, Color.red]),
                               startPoint: .top,
                               endPoint: .bottom)
            )
            .frame(width: 20, height: 60)
            .offset(y: -30)
            .shadow(color: Color.red.opacity(0.5), radius: 5, x: 0, y: 5)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
