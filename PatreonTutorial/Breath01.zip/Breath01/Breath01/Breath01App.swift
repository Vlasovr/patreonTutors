import SwiftUI

@main
struct Breath01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
