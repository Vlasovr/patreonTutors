//
//  ContentView.swift
//  MediaPlayerUIDesign
//
//  Created by Damra on 11.11.2024.
//

import SwiftUI

let songs = ["Good For You", "Señorita", "Worth It", "Perfect", "Nevermind"]
let artist = ["Selena Gomez", "Camila Cabello & Shawn Mendes", "Fifth Harmony", "Ed Sheeran", "Dennis Lloyd"]
let musictypes = ["HipHop","Pop","Rock","Rap"]
let musictypesImage = ["hiphop","pop","rock","rap"]
let tabIcon = ["house","magnifyingglass","rectangle.on.rectangle","heart"]

struct ContentView: View {
    @State var isPlaying: Bool = false
    @Namespace private var animation // MatchGeometryEffect namespace
    @AppStorage("selectedIndex") var selectedIndex = 0
    var body: some View {
        NavigationStack {
            MediaPlayer(isPlaying: $isPlaying)
        }
        .safeAreaInset(edge: .bottom) {
            VStack {
                ZStack {
                    Rectangle()
                        .fill(Color("blue"))
                        .frame(height: 120)
                        .cornerRadius(20, 10, 0, 0) // We give each corner a separate radius value.
                    
                    HStack(spacing: 20){
                        Image(artist[selectedIndex])
                            .resizable()
                            .frame(width: 65, height: 65)
                            .clipShape(Circle())
                            .overlay {
                                Circle()
                                    .stroke(.white, lineWidth: 3)
                            }
                        VStack(alignment: .leading){
                            Text(songs[selectedIndex])
                                .font(.custom("Rubik-Medium", size: 22))
                                .foregroundStyle(Color("text"))
                            Text(artist[selectedIndex])
                                .font(.custom("Rubik-Medium", size: 15))
                                .foregroundStyle(.gray.opacity(0.5))
                        }
                        
                        Spacer()
                        
                        Image(systemName: isPlaying ? "pause.rectangle.fill" : "play.square.fill")
                            .resizable()
                            .frame(width: 45, height: 45)
                            .foregroundStyle(.white)
                            .cornerRadius(15)
                            .onTapGesture {
                                withAnimation(.bouncy) {
                                    isPlaying.toggle()
                                }
                            }
                    }.padding(.horizontal).offset(y: -10)
                }.matchedGeometryEffect(id: "mediaplayer", in: animation).offset(y: isPlaying ? 30 : 150)
                
                ZStack {
                    RoundedRectangle(cornerRadius: 25)
                        .fill(.white)
                        .frame(height: 100)
                    HStack {
                        ForEach(tabIcon.indices, id: \.self) { items in
                            Spacer()
                            Image(systemName: tabIcon[items])
                                .resizable()
                                .scaledToFit()
                                .frame(width: 30, height: 30)
                                .foregroundStyle(Color("text"))
                            
                            Spacer()
                        }
                    }.padding(.horizontal)
                }//Custom Tabbar
                
            }
            
        }.ignoresSafeArea()
    }
}

#Preview {
    ContentView()
}
