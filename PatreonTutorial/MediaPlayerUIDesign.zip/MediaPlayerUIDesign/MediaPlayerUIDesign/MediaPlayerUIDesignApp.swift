//
//  MediaPlayerUIDesignApp.swift
//  MediaPlayerUIDesign
//
//  Created by Damra on 11.11.2024.
//

import SwiftUI

@main
struct MediaPlayerUIDesignApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
