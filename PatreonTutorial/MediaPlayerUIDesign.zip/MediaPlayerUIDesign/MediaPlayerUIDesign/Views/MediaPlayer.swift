//
//  MediaPlayer.swift
//  MediaPlayerUIDesign
//
//  Created by Damra on 11.11.2024.
//

import SwiftUI

struct MediaPlayer: View {
    @AppStorage("selectedIndex") var selectedIndex = 0
    @State var progress: CGFloat = 0
    @Binding var isPlaying: Bool
    var body: some View {
        ZStack {
            Color.Neumorphic.main.ignoresSafeArea()
            VStack {
                Header()
                ScrollView(.vertical, showsIndicators: false) {
                    CarouselCardView()
                    HStack {
                        SegmentedControl().offset(x: -30, y: -110)
                        VStack {
                            ForEach(songs.indices, id: \.self) { items in
                                playlist(
                                    soundname: songs[items],
                                    artistname: artist[items],
                                    artistImage: artist[items]
                                )
                                .offset(x: -60)
                                .padding(.bottom)
                                
                                .onTapGesture {
                                    withAnimation(.bouncy) {
                                        selectedIndex = items
                                        isPlaying = true
                                    }
                                }
                            }
                        }.frame(maxHeight: 450)
                    }.padding(.top, 30)
                    
                    Rectangle()
                        .fill(.clear)
                        .frame(height: isPlaying ? 150 : 50)
                    
                }
            }
        }
    }
}
