//
//  CarouselCardView.swift
//  MediaPlayerUIDesign
//
//  Created by Damra on 11.11.2024.
//

import SwiftUI

struct CarouselCardView: View {
    @State private var selectedIndex = 0

    @AppStorage("currentSongIndex") var currentSongIndex: Int = 0 // To track the current song

    var body: some View {
        VStack {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    ForEach(musictypes.indices, id: \.self) { index in
                        VStack {
                            ZStack {
                                CardView(
                                    imageName: musictypesImage[index],
                                    itemName: songs[index]
                                )
                                    .frame(height: 350) // Adjust size as needed
                                    .tag(index)

                                VStack {
                                    Spacer()
                                    HStack {
                                        // Optional: Displaying current item number
                                        Text(musictypes[index])
                                            .font(.custom("Rubik-Bold", size: 25))
                                            .foregroundColor(.white)

                                        Spacer()

                                        Image(systemName: "play.square.fill")
                                            .resizable()
                                            .frame(width: 45, height: 45)
                                            .foregroundStyle(.white)
                                            .cornerRadius(15)
                                    }.padding(.horizontal, 25)
                                }.frame(height: 320)
                            }
                        }
                    }
                }.scrollTargetLayout()
            }
            .contentMargins(.horizontal, 80)
            .scrollTargetBehavior(.paging)
        }
    }
}
