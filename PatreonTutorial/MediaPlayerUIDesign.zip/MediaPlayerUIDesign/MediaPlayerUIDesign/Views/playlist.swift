//
//  playlist.swift
//  MediaPlayerUIDesign
//
//  Created by Damra on 11.11.2024.
//

import SwiftUI

struct playlist: View {
    let soundname: String
    let artistname: String
    let artistImage: String
    var body: some View {
        HStack {
            Image(artistImage)
                .resizable()
                .frame(width: 65, height: 65)
                .cornerRadius(15)
            VStack(alignment: .leading){
                Text(soundname)
                    .font(.custom("Rubik-Medium", size: 22))
                    .foregroundStyle(Color("text"))
                Text(artistname)
                    .font(.custom("Rubik-Medium", size: 15))
                    .foregroundStyle(.gray.opacity(0.5))
            }
            
            Spacer()
            
            Image(systemName: "heart")
                .resizable()
                .scaledToFit()
                .frame(width: 20, height: 20)
                .foregroundStyle(.gray.opacity(0.5))
            
        }
    }
}
