//
//  SegmentedControl.swift
//  MediaPlayerUIDesign
//
//  Created by Damra on 11.11.2024.
//

import SwiftUI

struct SegmentedControl: View {
    @State private var selectedTab: String = "Recent" // Track the selected tab
    @Namespace private var animation // MatchGeometryEffect namespace
    @State var selectedItem = 0
    let title = ["Like", "Recent"]
    var body: some View {
        HStack(spacing: 35) {
            HStack(spacing: 35) {
                ForEach(title.indices, id: \.self) { items in
                    VStack {
                        Circle()
                            .foregroundStyle(Color("text"))
                            .frame(width: 7, height: 7)
                            .matchedGeometryEffect(id: "circle", in: animation)
                            .offset(x: selectedItem == 1 ? 85 : 0)

                        Text(title[items])
                            .font(.custom("Rubik-Medium", size: 18))
                            .foregroundStyle(Color("text").opacity(selectedItem == items ? 1 : 0.4))
                            .onTapGesture {
                                withAnimation(.bouncy) {
                                    selectedItem = items
                                }
                            }
                    }
                }
            }
        }
        .rotationEffect(.degrees(-90))
    }
}
