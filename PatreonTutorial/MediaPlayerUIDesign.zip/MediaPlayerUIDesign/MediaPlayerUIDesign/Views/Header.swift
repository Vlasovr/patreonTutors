//
//  Header.swift
//  MediaPlayerUIDesign
//
//  Created by Damra on 11.11.2024.
//

import SwiftUI

struct Header: View {
    var body: some View {
        HStack {
            Text("Discover")
                .font(.custom("Rubik-Medium", size: 35))
                .foregroundStyle(Color("text"))

            Spacer()

            Button {
            } label: {
                Image(systemName: "line.3.horizontal.decrease")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 35, height: 35)
                    .foregroundStyle(Color("text"))
            }
        }.padding(.horizontal)
    }
}
