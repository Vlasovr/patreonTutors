
import SwiftUI

@main
struct FocusExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
