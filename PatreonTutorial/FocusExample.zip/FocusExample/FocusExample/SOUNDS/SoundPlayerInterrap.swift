//
//  SoundPlayerExample.swift
//  Denememmmm
//
//  Created by Selçuk ASLANTAŞ on 1.12.2022.
//

import SwiftUI
import AVFAudio
import AVFoundation
import MediaPlayer

/*
 Kullanılacak Yer
 @StateObject var musicPlayer = MusicPlayer()
 
 ***** ve initi kullanmak istemezsek *****
 
 .onAppear {
     //Arkaplnda çalışması için capabilityden background modes audio airplay i aç ve alttaki kodu başlat
     musicPlayer.activePlayBackground()
     timer.updateTimerCounter(value: counterV)
     musicPlayer.setUpPlayer(soundName: "Game1", soundType: "m4a")
     //burası tus kilini ve ust kucuk yerde görünmesi için alttaki 2 yer
     //ilki resim ve bilgi mesajı
     musicPlayer.setupNowPlaying(artist: "The game is being played", title: "Games", image: "mathbook")
     //tus kilidi ve ustteki kucuk kısımdaki kontrol için
     musicPlayer.setupRemoteTransportControls()
     //Çakışma Kodu (Telefon Araması Gibi ya da Youtube Gibi)
     //musicPlayer.setupNotifications()
 }
  bu şekilde kullanılır.
 */


let audioSession = AVAudioSession.sharedInstance()

class MusicPlayer: ObservableObject {
    @Published private var player = AVAudioPlayer()
    var playingSoundCheck: Bool {
        return self.player.isPlaying
    }
    /*
     @AppStorage("gameSoundVolume") var gameSoundVolume: Double = 0.8 {
         didSet {
             updateVolume()
         }
     }
     */
    
    init() {
        /*
         setUpPlayer()
         setupNowPlaying()
         setupRemoteTransportControls()
         setupNotifications()
         */
    }

    func setUpPlayer(soundName: String, soundType: String, slientAndBackgroundPlay: Bool = true, repeatV: Bool = false) {
        
        if slientAndBackgroundPlay {
            activePlayBackgroundAndSlient()
        } else {
            deActivePlayBackgroundAndSlient()
        }
        
        do {
            if let url = Bundle.main.url(forResource: soundName, withExtension: soundType) {
                player = try AVAudioPlayer(contentsOf: url)
                player.prepareToPlay()
                if repeatV {
                    player.numberOfLoops = -1
                }
                player.play()
            } else {
                print("Error: URL is nil. Check the sound name and type.")
            }
        } catch let error as NSError {
            print("Failed to init audio player: \(error)")
        }
        
        
    }
    

    func setupRemoteTransportControls() {
        // Get the shared MPRemoteCommandCenter
        let commandCenter = MPRemoteCommandCenter.shared()
        //activePlayBackgroundAndSlient()
        // Add handler for Play Command
        commandCenter.playCommand.addTarget { [unowned self] event in
            print("Play command - is playing: \(self.player.isPlaying)")
            if !self.player.isPlaying {
                self.play()
                return .success
            }
            return .commandFailed
        }

        // Add handler for Pause Command
        commandCenter.pauseCommand.addTarget { [unowned self] event in
            print("Pause command - is playing: \(self.player.isPlaying)")
            if self.player.isPlaying {
                self.pause()
                return .success
            }
            return .commandFailed
        }
    }
    
    func activePlayBackgroundAndSlient() {
        //Musigin arkaplanda çalışması için gerekli
        do {
            // Öncelikle session'ı durdurun (deactivate)
            try audioSession.setActive(false)
            // Sonra kategori ve opsiyonları ayarlayın
            //try audioSession.setCategory(AVAudioSession.Category.playback, mode: AVAudioSession.Mode.default,options: .defaultToSpeaker)
            try audioSession.setCategory(.playAndRecord, options: [.defaultToSpeaker])
            // Son olarak session'ı tekrar aktif hale getirin
            try audioSession.setActive(true)
        } catch let error as NSError {
            print("Setting category to AVAudioSessionCategoryPlayback failed: \(error)")
        }
    }
    
    func deActivePlayBackgroundAndSlient() {
        
        do {
            //try audioSession.setCategory(AVAudioSession.Category.playback, mode: AVAudioSession.Mode.default)
            // Öncelikle session'ı durdurun (deactivate)
            try audioSession.setActive(false)
            //Muzigin arkaplanda ve sessiz modda çalışmaması için (Ambient)
            //try audioSession.setCategory(AVAudioSession.Category.ambient, mode: AVAudioSession.Mode.default,options: .defaultToSpeaker)
                try audioSession.setCategory(.ambient)
            // Son olarak session'ı tekrar aktif hale getirin
            try audioSession.setActive(true)
        } catch let error as NSError {
            print("Setting category to AVAudioSessionCategoryPlayback failed: \(error)")
        }
    }
    

    func setupNowPlaying(artist: String, title: String, image: String) {
        // Define Now Playing Info
        var nowPlayingInfo = [String : Any]()
        nowPlayingInfo[MPMediaItemPropertyTitle] = title
        nowPlayingInfo[MPMediaItemPropertyArtist] = artist
        

        if let image = UIImage(named: image) {
            nowPlayingInfo[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: image.size) { size in
                return image
            }
        }
        nowPlayingInfo[MPNowPlayingInfoPropertyElapsedPlaybackTime] = player.currentTime
        nowPlayingInfo[MPMediaItemPropertyPlaybackDuration] = player.duration
        nowPlayingInfo[MPNowPlayingInfoPropertyPlaybackRate] = player.rate

        // Set the metadata
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nowPlayingInfo
    }
    

    func play() {
        player.play()
        //playPauseButton.setTitle("Pause", for: UIControl.State.normal)
        updateNowPlaying(isPause: false)
        print("Play - current time: \(player.currentTime) - is playing: \(player.isPlaying)")
    }
    
    func stop() {
        player.stop()
        //playPauseButton.setTitle("Pause", for: UIControl.State.normal)
        updateNowPlaying(isPause: false)
        print("Play - current time: \(player.currentTime) - is playing: \(player.isPlaying)")
    }

    func pause() {
        player.pause()
        //playPauseButton.setTitle("Play", for: UIControl.State.normal)
        updateNowPlaying(isPause: true)
        print("Pause - current time: \(player.currentTime) - is playing: \(player.isPlaying)")
    }
    
    /*
     func updateVolume() {
             player.setVolume(Float(gameSoundVolume) / 10, fadeDuration: 0.1)
             print("Volume updated to: \(gameSoundVolume)")
         }
     */

    /*
     func updateNowPlaying(isPause: Bool) {
         // Define Now Playing Info
         var nowPlayingInfo = MPNowPlayingInfoCenter.default().nowPlayingInfo!

         nowPlayingInfo[MPNowPlayingInfoPropertyElapsedPlaybackTime] = player.currentTime
         nowPlayingInfo[MPNowPlayingInfoPropertyPlaybackRate] = isPause ? 0 : 1

         // Set the metadata
         MPNowPlayingInfoCenter.default().nowPlayingInfo = nowPlayingInfo
     }
     */
    
    func updateNowPlaying(isPause: Bool) {
        if var nowPlayingInfo = MPNowPlayingInfoCenter.default().nowPlayingInfo {
            nowPlayingInfo[MPNowPlayingInfoPropertyElapsedPlaybackTime] = player.currentTime
            nowPlayingInfo[MPNowPlayingInfoPropertyPlaybackRate] = isPause ? 0 : 1

            // Set the metadata
            MPNowPlayingInfoCenter.default().nowPlayingInfo = nowPlayingInfo
        } else {
            print("Now Playing Info is nil")
        }
    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        print("Audio player did finish playing: \(flag)")
        if (flag) {
            updateNowPlaying(isPause: true)
            //playPauseButton.setTitle("Play", for: UIControl.State.normal)
        }
    }
    
    //************* Çakışma Kodu (Telefon Araması Gibi ya da Youtube Gibi) *************
    func setupNotifications() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self,
                                       selector: #selector(handleInterruption),
                                       name: AVAudioSession.interruptionNotification,
                                       object: nil)
        
        /*
         notificationCenter.addObserver(self,
                                            selector: #selector(handleRouteChange),
                                            name: AVAudioSession.routeChangeNotification,
                                            object: nil)
         */
    }

    @objc func handleInterruption(notification: Notification) {
        guard let userInfo = notification.userInfo,
            let typeValue = userInfo[AVAudioSessionInterruptionTypeKey] as? UInt,
            let type = AVAudioSession.InterruptionType(rawValue: typeValue) else {
                return
        }

        if type == .began {
            print("Interruption began")
            // Interruption began, take appropriate actions
        }
        else if type == .ended {
            if let optionsValue = userInfo[AVAudioSessionInterruptionOptionKey] as? UInt {
                let options = AVAudioSession.InterruptionOptions(rawValue: optionsValue)
                if options.contains(.shouldResume) {
                    // Interruption Ended - playback should resume
                    print("Interruption Ended - playback should resume")
                    play()
                } else {
                    // Interruption Ended - playback should NOT resume
                    print("Interruption Ended - playback should NOT resume")
                }
            }
        }
    }
  
   //************* Route Change Kodu (Kulaklık, airplay Gibi) ***********
    /*
   @objc func handleRouteChange(notification: Notification) {
       guard let userInfo = notification.userInfo,
           let reasonValue = userInfo[AVAudioSessionRouteChangeReasonKey] as? UInt,
           let reason = AVAudioSession.RouteChangeReason(rawValue:reasonValue) else {
               return
       }
       switch reason {
       case .newDeviceAvailable:
           let session = AVAudioSession.sharedInstance()
           for output in session.currentRoute.outputs where output.portType == AVAudioSession.Port.headphones {
               print("headphones connected")
               DispatchQueue.main.sync {
                   self.play()
               }
               break
           }
       case .oldDeviceUnavailable:
           if let previousRoute =
               userInfo[AVAudioSessionRouteChangePreviousRouteKey] as? AVAudioSessionRouteDescription {
               for output in previousRoute.outputs where output.portType == AVAudioSession.Port.headphones {
                   print("headphones disconnected")
                   DispatchQueue.main.sync {
                       self.pause()
                   }
                   break
               }
           }
       default: ()
       }
   }
     */

   //*************
   
}
