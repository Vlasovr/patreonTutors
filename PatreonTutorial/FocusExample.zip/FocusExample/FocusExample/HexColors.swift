

import SwiftUI

extension Color {
    static func random() -> Color {
        return Color(red: Double.random(in: 0...1), green: Double.random(in: 0...1), blue: Double.random(in: 0...1))
    }
}

//hex color
extension Color {
    init(hex: UInt, alpha: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xff) / 255,
            green: Double((hex >> 08) & 0xff) / 255,
            blue: Double((hex >> 00) & 0xff) / 255,
            opacity: alpha
        )
    }
}

func ColorSelect(colorHex: UInt) -> Color {
    Color(hex: colorHex)
}

extension View {
    public func gradientFGLinear(colors: [Color],startP: UnitPoint,endP: UnitPoint) -> some View {
        self.overlay(LinearGradient(gradient: .init(colors: colors),
                                    startPoint: startP,
                                    endPoint: endP))
            .mask(self)
    }
    
    public func gradientFGRadial(colors: [Color]) -> some View {
        self.overlay(RadialGradient(gradient: .init(colors: colors), center: .center, startRadius: 2, endRadius: 600))
            .mask(self)
    }
    
    public func gradientFGAngular(colors: [Color]) -> some View {
        self.overlay(AngularGradient(gradient: .init(colors: colors), center: .center))
            .mask(self)
    }
    
    
}



/*
 
 extension View {
     func foregroundColorHex(colorHex: UInt) -> Color {
         Color(hex: colorHex)
     }
 }
 */
var greenWater = Color(hex: 0x43736e)

var darkColorG = [Color(hex: 0x4D4855),Color(hex: 0xA399B2)]
var sunsetChartG1 = [Color(hex: 0xFCDE9C), Color(hex: 0x7C1D6F).opacity(0.1)]

var lightGray1 = Color(hex: 0xFAFAFA)
var lightGray2 = Color(hex: 0xF5F5F5)
var lightGray3 = Color(hex: 0xECECEC)
var lightGray4 = Color(hex: 0xDEDEDE)
var lightGray5 = Color(hex: 0xD4D4D4)

var creamColor = Color(hex: 0xf9e4bc)
var gameColor1 = Color(hex: 0xB9257A)

var calmG: [Color] = [Color(hex: 0x1973D1),Color(hex: 0x560283)]
var GoldSilverG: [Color] = [Color(hex: 0xFCDE9C),Color(hex: 0xaaaaaa),Color(hex: 0x525252)]
var sunsetG1 = [Color(hex: 0xFCDE9C), Color(hex: 0xFAA476), Color(hex: 0xF0746E), Color(hex: 0xE34F6F), Color(hex: 0xDC3977), Color(hex: 0xB9257A), Color(hex: 0x7C1D6F)]
var magentaG = [Color(hex: 0xF3CBD3), Color(hex: 0xEAA9BD), Color(hex: 0xDD88AC), Color(hex: 0xCA699D), Color(hex: 0xB14D8E), Color(hex: 0x91357D), Color(hex: 0x6C2167)]
var DullBlueG = [Color(hex: 0x003366),Color(hex: 0x174978),Color(hex: 0x2F5F8A),Color(hex: 0x46769B),Color(hex: 0x5E8CAD),Color(hex: 0x75A2BF)]
var DDullBlueG = [Color(hex: 0x003366),Color(hex: 0x174978),Color(hex: 0x2F5F8A)]
var purpleLove: [Color] = [Color(hex: 0xcc2b5e),Color(hex: 0x753a88)]


var sleepScreen1 = Color(hex: 0x0C0413)
var sleepScreen2 = Color(hex: 0x644686)
var sleepScreen3 = Color(hex: 0xF4EBCA)

var sleepScreenA1 = Color(hex: 0xA5D721)
var sleepScreenA2 = Color(hex: 0x5D8700)

var sleepScreenB1 = Color(hex: 0x3A5A40)
var sleepScreenB2 = Color(hex: 0x344E41)

var sleepScreenC1 = Color(hex: 0x050515)
var sleepScreenC2 = Color(hex: 0x100541)

var sleepScreenD1 = Color(hex: 0x2c2b6b)
var sleepScreenD2 = Color(hex: 0x000c19)

var bgColorDark1 = Color(hex: 0x0C0413)
var bgColorDark2 = Color(hex: 0x00254d)

//pastel colors
var pastelA0 = Color(hex: 0xafd8a8a)
var pastelA1 = Color(hex: 0xa4b6dd)
var pastelA2 = Color(hex: 0xd09292)
var pastelA3 = Color(hex: 0xc094cc)
var pastelA4 = Color(hex: 0xa2d0c0)
var pastelA5 = Color(hex: 0xc37892)
var pastelA6 = Color(hex: 0xB9E8FC)

//pastel naturel
var pastelN1 = Color(hex: 0x818185)

//pastel colors
var pastel1 = Color(hex: 0xa4b6dd)
var pastel2 = Color(hex: 0xd09292)
var pastel3 = Color(hex: 0xc094cc)
var pastel4 = Color(hex: 0xa2d0c0)
var pastel5 = Color(hex: 0xc37892)
var pastel6 = Color(hex: 0x566D7E)
var pastel7 = Color(hex: 0xfe8366)
var pastel8 = Color(hex: 0xa75e66)
var pastel9 = Color(hex: 0x886eaa)
var pastel10 = Color(hex: 0xE8A0BF)
var pastel11 = Color(hex: 0xC0DBEA)
var pastel12 = Color(hex: 0xB2A4FF)
var pastel13 = Color(hex: 0xEDC6B1)
var pastel14 = Color(hex: 0x867070)
var pastel15 = Color(hex: 0xF1F7B5)
var pastel16 = Color(hex: 0x65647C)
var pastel17 = Color(hex: 0xFFFBC1)
var pastel18 = Color(hex: 0x829460)
var pastel19 = Color(hex: 0x5F7161)
var pastel20 = Color(hex: 0x874C62)


var chartFirst = Color(hex: 0xffc500)
var platinum = Color(hex: 0xE5E4E2)
var brown1 = Color(hex: 0x613317)
//gray
var darkgray = Color(hex: 0x3A3B3C)
var darkgray1 = Color(hex: 0x222222)
var darkgray2 = Color(hex: 0x333333)
var darkgray3 = Color(hex: 0x444444)
var darkgray4 = Color(hex: 0x555555)
var ırongray = Color(hex: 0x52595D)

//blue
var marbleblue = Color(hex: 0x566D7E)
var bluejay = Color(hex: 0x2B547E)
var darkslate = Color(hex: 0x2B3856)
//light green
var aquamarine = Color(hex: 0x7FFFD4)
var magicmint = Color(hex: 0xAAF0D1)

var indigo = Color(hex: 0x4B0082)
//yellow
var organicbrown = Color(hex: 0xE3F9A6)
var parchment = Color(hex: 0xFFFFC2)

var darkRed = Color(hex: 0xbf0000)
var bisque = Color(hex: 0xFFE4C4)
var sandybrown = Color(hex: 0xF4A460)
var pastelred = Color(hex: 0xF67280)
var darkraspberry = Color(hex: 0x872657)
var lipstickpink = Color(hex: 0xC48793)
var pastelorange = Color(hex: 0xF8B88B)
var lightred = Color(hex: 0xFFCCCB)
var bashfulpink = Color(hex: 0xC25283)
var brightmaroon = Color(hex: 0xC32148)
var orchidpurple = Color(hex: 0xB048B5)
var plumpurple = Color(hex: 0x583759)
var darkmagenta = Color(hex: 0x8B008B)
var softıvory = Color(hex: 0xFAF0DD)
var seashell = Color(hex: 0xFFF5EE)
var slateblue = Color(hex: 0x6A5ACD)
var midnightblue = Color(hex: 0x191970)
var venomgreen = Color(hex: 0x728C00)
var darkforestgreen = Color(hex: 0x254117)
var nightblue = Color(hex: 0x151B54)

var ındiansaffron = Color(hex: 0xFF7722) //orange1

/*
 Color(hex: 0x000000)
 Color(hex: 0x000000, alpha: 0.2)
 */

var dullgreenyellow = Color(hex: 0xB1FB17) //fosforlu acik yesil renk ton 4 -----Guzel renk
var scarlet = Color(hex: 0xFF2400) //fosforlu kırmızı ton 2
var neonyellow = Color(hex: 0xFFFF33)//fosforlu acik sarı renk ton 1
var neonorange = Color(hex: 0xFF6700) //fosforlu turuncu ton1
var brightneonpink = Color(hex: 0xF433FF)

extension View {
    public func gradientFGLinear(colors: [Color], startPoint: UnitPoint? = .topLeading, endPoint: UnitPoint? = .bottomTrailing) -> some View {
        self.overlay(LinearGradient(gradient: .init(colors: colors),
                                    startPoint: startPoint!,
                                    endPoint: endPoint!))
            .mask(self)
    }
    
    public func gradientFGRadial(colors: [Color], center: UnitPoint? = .center, startRadius: CGFloat? = 2, endRadius: CGFloat? = 600) -> some View {
        self.overlay(RadialGradient(gradient: .init(colors: colors), center: center!, startRadius: startRadius!, endRadius: endRadius!))
            .mask(self)
    }
    
    public func gradientFGAngular(colors: [Color], center: UnitPoint? = .center, startAngleDeg: Double? = .zero, endAngleDeg: Double? = .zero) -> some View {
        self.overlay(AngularGradient(gradient: .init(colors: colors), center: center!, startAngle: Angle(degrees: startAngleDeg!), endAngle: .degrees(endAngleDeg!)))
            .mask(self)
    }
    
    
}


