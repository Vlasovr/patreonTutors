

import AVFoundation
import SwiftUI

// Main content view struct
struct ContentView: View {
    var body: some View {
        VStack {
            FocusAppView() // Embedding the FocusAppView component
        }
    }
}

// Preview provider for ContentView
#Preview {
    ContentView()
}

// View representing the main focus application
struct FocusAppView: View {
    @State private var focusTime: Double = 5 // Timer in minutes, default set to 5 minutes
    @State private var remainingTime: Int = Int(5 * 60) // Remaining time in seconds
    @State private var isTimerRunning = false // Boolean to track timer state
    @State private var cancelCountdown: Int = 10 // Countdown for cancellation, default 10 seconds
    @State private var initialTime: Int = Int(5 * 60) // Initial timer value in seconds
    @State private var quote: String = "" // Random motivational quote displayed during the timer
    private let maxTime: Double = 120 // Maximum focus time in minutes
    private let minTime: Double = 5 // Minimum focus time in minutes
    // Audio manager instance to handle sound playback
    private let audioManager = AudioManager()
    var body: some View {
        ZStack {
            // Background gradient styling
            LinearGradient(gradient: Gradient(colors: [Color(hex: 0x121C84), Color(hex: 0x8278DA)]),
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .edgesIgnoringSafeArea(.all)
            VStack(spacing: 20) {
                Text("Focus Time") // Header label
                    .font(.headline)
                    .foregroundColor(.white.opacity(0.8))
                Text("\(Int(focusTime)) minutes") // Display selected focus time in minutes
                    .font(.custom("Bebas Neue", size: 40))
                    .foregroundColor(.white)
                    .padding(.top, -10)
                // Custom circular slider to adjust the focus time
                CircularSlider(value: $focusTime, minTime: minTime, maxTime: maxTime, isTimerRunning: isTimerRunning)
                    .frame(width: 250, height: 250)
                    .padding()
                    .onChange(of: focusTime) { newValue in
                        remainingTime = Int(newValue * 60) // Update remaining time when focus time changes
                    }
                // Display remaining time in minutes and seconds
                Text("\(timeString(from: remainingTime))")
                    .font(.custom("Bebas Neue", size: 70))
                    .monospacedDigit()
                    .foregroundColor(.white.opacity(0.9))
                    .padding()
                // Display random quote
                Text(quote)
                    .font(.headline)
                    .foregroundColor(.yellow)
                    .padding()
                    .multilineTextAlignment(.center)
                    .transition(.opacity)
                    .animation(.easeInOut, value: quote)
                // Button to start or stop the timer
                Button(action: {
                    startFocusTimer()
                }) {
                    Text(isTimerRunning ? "Stop" : "Start")
                        .font(.title2)
                        .fontWeight(.bold)
                        .padding(.horizontal, 40)
                        .padding(.vertical, 15)
                        .background(isTimerRunning ? Color.red : Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(40)
                        .shadow(color: isTimerRunning ? Color.red.opacity(0.5) : Color.green.opacity(0.5), radius: 10, x: 0, y: 5)
                }
                // Cancel countdown display with tap gesture to cancel the timer
                Text("Cancel (\(cancelCountdown))")
                    .font(.headline)
                    .foregroundColor(.red)
                    .padding(.top, 5)
                    .onTapGesture {
                        cancelTimer() // Cancel the timer on tap
                    }
                    .opacity(isTimerRunning && cancelCountdown > 0 ? 1 : 0) // Show only when timer is running and countdown > 0
                    .transition(.opacity.combined(with: .slide))
                    .animation(.easeInOut)
            }
            .padding(.horizontal, 30)
            .onReceive(timer) { _ in
                updateTimer() // Update timer every second
            }
        }
    }
    // Timer setup for 1-second interval updates
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    // Function to start or stop the focus timer
    private func startFocusTimer() {
        if isTimerRunning {
            withAnimation {
                isTimerRunning = false // Stop the timer
                audioManager.stopSound() // Stop sound playback
            }
            remainingTime = initialTime // Reset remaining time
            cancelCountdown = 10 // Reset cancellation countdown
        } else {
            withAnimation {
                isTimerRunning = true // Start the timer
            }
            initialTime = Int(focusTime) * 60 // Set initial time based on focus time
            remainingTime = initialTime
            cancelCountdown = 10 // Reset cancellation countdown
            selectRandomQuote() // Display a new quote
            audioManager.playSound() // Play sound on timer start
        }
    }
    // Function to update the timer every second
    private func updateTimer() {
        if isTimerRunning {
            if cancelCountdown > 0 {
                cancelCountdown -= 1 // Decrease cancel countdown
            }
            if remainingTime > 0 {
                remainingTime -= 1 // Decrease remaining time
            } else {
                withAnimation {
                    isTimerRunning = false // Stop the timer when it reaches zero
                }
                remainingTime = initialTime // Reset the timer
                audioManager.playSound() // Play sound when timer ends
            }
        }
    }
    
    // Function to cancel the timer and reset values
    private func cancelTimer() {
        withAnimation {
            isTimerRunning = false // Stop the timer
        }
        remainingTime = initialTime // Reset remaining time
        cancelCountdown = 10 // Reset cancel countdown
        audioManager.playSound() // Play sound when timer is canceled
    }
    
    // Function to convert seconds to a time string format (MM:SS)
    private func timeString(from seconds: Int) -> String {
        let minutes = Int(seconds / 60)
        let seconds = seconds % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
    
    // Function to select a random motivational quote
    private func selectRandomQuote() {
        let quotes = [
            "Stay focused and never give up.",
            "Your only limit is your mind.",
            "Focus on your goal.",
            "You can do it!",
            "Keep moving forward.",
            "Success is the result of patience and persistence.",
            "Today's work is done for today.",
        ]
        quote = quotes.randomElement() ?? "" // Pick a random quote from the array
    }
}

// Circular slider component
struct CircularSlider: View {
    @Binding var value: Double
    var minTime: Double
    var maxTime: Double
    var isTimerRunning: Bool
    var body: some View {
        GeometryReader { geometry in
            let size = min(geometry.size.width, geometry.size.height)
            let radius = size / 2
            let angle = Angle(degrees: ((value - minTime) / (maxTime - minTime)) * 360 - 90)
            let knobPosition = CGPoint(
                x: radius + cos(Double(angle.radians)) * radius,
                y: radius + sin(Double(angle.radians)) * radius
            )
            ZStack {
                Circle()
                    .fill(Color.white.opacity(0.1)) // Background circle
                Circle()
                    .stroke(Color.gray.opacity(isTimerRunning ? 0 : 0.8), lineWidth: 15) // Outer ring
                Circle()
                    .trim(from: 0, to: CGFloat((value - minTime) / (maxTime - minTime))) // Progress arc
                    .stroke(Color.orange.opacity(isTimerRunning ? 0 : 1), style: StrokeStyle(lineWidth: 15, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                Circle() // Knob for adjusting the time
                    .fill(Color.white.opacity(isTimerRunning ? 0 : 1))
                    .frame(width: 30, height: 30)
                    .position(knobPosition)
                    .gesture(
                        DragGesture()
                            .onChanged { drag in
                                let vector = CGVector(dx: drag.location.x - radius, dy: drag.location.y - radius)
                                let angle = atan2(vector.dy, vector.dx) + .pi / 2
                                let adjustedAngle = angle < 0 ? angle + 2 * .pi : angle
                                let newValue = (adjustedAngle / (2 * .pi)) * (maxTime - minTime) + minTime
                                self.value = (newValue / 5).rounded() * 5 // Adjust value in 5-minute increments
                            }
                    )
                // Center icon
                Image("focus2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: size * 0.5, height: size * 0.5)
                    .foregroundColor(.blue.opacity(0.8))
                    .shadow(radius: 10)
            }
            .frame(width: size, height: size)
        }
    }
}

// Audio manager to handle sound playback
class AudioManager {
    var player: AVAudioPlayer?
    // Function to play sound
    func playSound() {
        guard let url = Bundle.main.url(forResource: "sound4", withExtension: "m4a") else { return }
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.play()
        } catch {
            print("Sound playback failed: \(error.localizedDescription)")
        }
    }
    // Function to stop sound
    func stopSound() {
        guard let isplaying = player?.isPlaying else { return }
        player?.stop()
    }
}

