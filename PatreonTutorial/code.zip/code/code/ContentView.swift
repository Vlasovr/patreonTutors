import SwiftUI

struct ButtonToProgressView: View {
    @State private var animateBorder = false
    @State private var isProgress = false
    @State private var progress: CGFloat = 0.0

    var body: some View {
        VStack(spacing: 30) {
            if !isProgress {
                Button(action: {
                    // Animate the gradient border from 0 to full stroke over 1 second.
                    withAnimation(.linear(duration: 1)) {
                        animateBorder = true
                    }
                    // After border animation, transition to progress bar.
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        withAnimation {
                            isProgress = true
                        }
                        // Increase progress in 10 steps (0.1 each) every 0.2 seconds.
                        Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { timer in
                            if progress < 1.0 {
                                withAnimation(.linear(duration: 0.2)) {
                                    progress += 0.1
                                }
                            } else {
                                timer.invalidate()
                            }
                        }
                    }
                }) {
                    Text("Press")
                        .font(.headline)
                        .foregroundColor(.black)
                        .padding()
                        .frame(width: 200, height: 60)
                        .background(Color.white)
                        .cornerRadius(12)
                }
                // Overlay with an animated gradient border.
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .trim(from: 0, to: animateBorder ? 1 : 0)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [Color.red, Color.blue]),
                                startPoint: .leading,
                                endPoint: .trailing
                            ),
                            style: StrokeStyle(lineWidth: 4, lineCap: .round)
                        )
                        .animation(.linear(duration: 1), value: animateBorder)
                )
            } else {
                // Progress bar view which fills according to the progress value.
                ProgressBarView(progress: progress)
                    .frame(height: 20)
                    .padding(.horizontal)
            }
        }
        .padding(30)
    }
}

struct ProgressBarView: View {
    var progress: CGFloat // value between 0 and 1

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                // Background track
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.gray.opacity(0.2))
                // Foreground progress fill with a continuous gradient.
                RoundedRectangle(cornerRadius: 10)
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: [Color.green, Color.yellow]),
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(width: geometry.size.width * progress)
                    .animation(.linear, value: progress)
            }
        }
    }
}

struct ContentView: View {
    var body: some View {
        ButtonToProgressView()
    }
}

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
