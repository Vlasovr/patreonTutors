//
//  moodApp.swift
//  mood
//
//  Created by M.Damra on 7.01.2025.
//

import SwiftUI

@main
struct moodApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
