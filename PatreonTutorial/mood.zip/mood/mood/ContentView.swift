//
//  ContentView.swift
//  mood
//
//  Created by M.Damra on 7.01.2025.
//

import SwiftUI

struct ContentView: View {
    @State private var feedbackLevel: Int = 1
    var body: some View {
        ZStack {
            backgroundColor.ignoresSafeArea()
                .animation(.spring(), value: backgroundColor)
            
            VStack {
                Text("Feedback")
                    .font(.largeTitle)
                    .padding()
                
                Spacer()
                
                feedbackEmoji
                    .frame(width: 120, height: 120)
                    .padding()
                
                Text(mood)
                    .font(.largeTitle)
                    .fontWeight(.black)
                    .foregroundStyle(.white)
                    .padding(.bottom, 50)
                
                ZStack {
                    CustomSlider(value: Binding(
                        get: { Double(feedbackLevel) },
                        set: { feedbackLevel = Int($0) }
                    ), range: 1...3)
                        .frame(width: 250)
                        .animation(.spring, value: feedbackLevel)
                    
                    HStack {
                        VStack {
                            Circle()
                                .fill(.white)
                                .frame(width: 20, height: 20)
                                .padding(.bottom)
                            
                            Text("Bad")
                                .font(.title2)
                                .fontWeight(.semibold)
                                .foregroundStyle(.white)
                        }
                        
                        Spacer()
                        
                        VStack {
                            Circle()
                                .fill(.white)
                                .frame(width: 20, height: 20)
                                .padding(.bottom)
                            
                            Text("Not Bad")
                                .font(.title2)
                                .fontWeight(.semibold)
                                .foregroundStyle(.white)
                        }
                        
                        Spacer()
                        
                        VStack {
                            Circle()
                                .fill(.white)
                                .frame(width: 20, height: 20)
                                .padding(.bottom)
                            
                            Text("Good")
                                .font(.title2)
                                .fontWeight(.semibold)
                                .foregroundStyle(.white)
                        }
                        
                    }.padding(.horizontal, 65).offset(x: 4, y: 25)
                    
                }
                
                Spacer()
                
            }
        }
    }
    
    // Different face (emoji) drawing according to feedback level
    private var feedbackEmoji: some View {
        switch feedbackLevel {
        case 1:
            // Sad face
            return AnyView (
                ZStack {
                    // Eyebrows and mouth
                    Path { path in
                        // Eyebrows
                        // Left eyebrow
                        path.move(to: CGPoint(x: 10, y: 10))
                        path.addQuadCurve(to: CGPoint(x: 45, y: -10),control: CGPoint(x: 35, y: 0))
                        
                        // Right eyebrow
                        path.move(to: CGPoint(x: 75, y: -10))
                        path.addQuadCurve(to: CGPoint(x: 105, y: 10),control: CGPoint(x: 85, y: 0))
                        
                        // Mouth (sad)
                        path.move(to: CGPoint(x: 45, y: 75))
                        path.addQuadCurve(to: CGPoint(x: 75, y: 75),control: CGPoint(x: 60, y: 60))
                    }
                    .stroke(.black, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                    
                    // Eyes (large and padded)
                    Path { path in
                        // Left eye
                        path.addEllipse(in: CGRect(x: 15, y: 15, width: 40, height: 40))
                        // Right eye
                        path.addEllipse(in: CGRect(x: 65, y: 15, width: 40, height: 40))
                    }
                    .fill(.black)
                }.scaleEffect(2)
            )
            
        case 2:
            // Neutral face
            return AnyView(
                ZStack {
                    // Eyebrows and mouth
                    Path { path in
                        // Eyebrows
                        // Left eyebrow
                        path.move(to: CGPoint(x: 10, y: 0))
                        path.addLine(to: CGPoint(x: 45, y: 0))
                        
                        // Right eyebrow
                        path.move(to: CGPoint(x: 70, y: 0))
                        path.addLine(to: CGPoint(x: 105, y: 0))
                        
                        // Mouth (straight line)
                        path.move(to: CGPoint(x: 40, y: 75))
                        path.addQuadCurve(to: CGPoint(x: 80, y: 75),control: CGPoint(x: 60, y: 70))
                    }
                    .stroke(.black, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                    
                    // Eyes (large and padded)
                    Path { path in
                        // Left eye
                        path.addEllipse(in: CGRect(x: 15, y: 15, width: 40, height: 40))
                        // Right eye
                        path.addEllipse(in: CGRect(x: 65, y: 15, width: 40, height: 40))
                    }
                    .fill(.black)
                }
                    .scaleEffect(2)
            )
        default:
            return AnyView(
                ZStack {
                    // Eyebrows and mouth
                    Path { path in
                        // Eyebrows
                        // Left eyebrow
                        path.move(to: CGPoint(x: 15, y: 10))
                        path.addQuadCurve(to: CGPoint(x: 45, y: 5),control: CGPoint(x: 25, y: -5))
                        
                        // Right eyebrow
                        path.move(to: CGPoint(x: 75, y: 5))
                        path.addQuadCurve(to: CGPoint(x: 105, y: 10),control: CGPoint(x: 90, y: -5))
                        
                        // Mouth (smile)
                        path.move(to: CGPoint(x: 40, y: 75))
                        path.addQuadCurve(to: CGPoint(x: 80, y: 75), control: CGPoint(x: 60, y: 90))
                    }
                    .stroke(.black, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                    
                    // Eyes (large and padded)
                    Path { path in
                        // Left eye
                        path.addEllipse(in: CGRect(x: 15, y: 15, width: 40, height: 40))
                        // Right eye
                        path.addEllipse(in: CGRect(x: 65, y: 15, width: 40, height: 40))
                    }
                    .fill(.black)
                }.scaleEffect(2)
            )
        }
    }
    
    // Sets the background color according to the feedback level
    private var backgroundColor: Color {
        switch feedbackLevel {
        case 1: return Color.red
        case 2: return Color.yellow
        default: return Color.green
        }
    }
    
    // Adjusts Mood Text according to feedback level
    private var mood: String {
        switch feedbackLevel {
        case 1: return "BAD"
        case 2: return "NOT BAD"
        default: return "GOOD"
        }
    }
    
}

struct CustomSlider: View {
    @Binding var value: Double
    let range: ClosedRange<Double>
    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading){
                // Background trace
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.white)
                    .frame(height: 8)
                
                // Filled part (progress)
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.black)
                    .frame(width: progressWidth(geo: geo), height: 8)
                
                // Thumb (scroll button)
                Circle()
                    .fill(Color.white)
                    .frame(width: 24, height: 24)
                    .position(x: thumbPosition(geo: geo), y: geo.size.height / 2)
                    .gesture(
                        DragGesture()
                            .onChanged { drag in
                                let relativePos = max(0, min(drag.location.x, geo.size.width))
                                let sliderValue = range.lowerBound + Double(relativePos / geo.size.width) * (range.upperBound - range.lowerBound)
                                // Rounding (optional)
                                let steppedValue = round(sliderValue)
                                value = min(max(steppedValue, range.lowerBound), range.upperBound)
                            }
                    )
                
            }
        }.frame(height: 40)
    }
    
    private func progressWidth(geo: GeometryProxy) -> CGFloat {
        let ratio = CGFloat((value - range.lowerBound) / (range.upperBound - range.lowerBound))
        return ratio * geo.size.width
    }
    
    private func thumbPosition(geo: GeometryProxy) -> CGFloat {
        let ratio = CGFloat((value - range.lowerBound) / (range.upperBound - range.lowerBound))
        return ratio * geo.size.width
    }
    
}

#Preview {
    ContentView()
}



