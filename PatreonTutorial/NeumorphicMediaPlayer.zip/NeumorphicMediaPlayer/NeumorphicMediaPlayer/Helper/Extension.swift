//
//  Extension.swift
//  NeumorphicMediaPlayer
//
//  Created by Damra on 9.11.2024.
//

import Foundation
import SwiftUI

// Hex Color Initialization
extension Color {
    init(hex: String) {
        let scanner = Scanner(string: hex)
        _ = scanner.scanString("#")
        var rgb: UInt64 = 0
        scanner.scanHexInt64(&rgb)
        let r = Double((rgb >> 16) & 0xFF) / 255.0
        let g = Double((rgb >> 8) & 0xFF) / 255.0
        let b = Double(rgb & 0xFF) / 255.0
        self.init(red: r, green: g, blue: b)
    }
}

// Neumorphic Effect Extension for Shadow
extension View {
    func neumorphicShadow(darkShadow: Color, lightShadow: Color) -> some View {
        self.shadow(color: darkShadow, radius: 7, x: 10, y: 10)
            .shadow(color: lightShadow, radius: 7, x: -5, y: -5)
    }
}
