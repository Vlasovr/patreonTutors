//
//  NeumorphicMediaPlayerApp.swift
//  NeumorphicMediaPlayer
//
//  Created by Damra on 9.11.2024.
//

import SwiftUI

@main
struct NeumorphicMediaPlayerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
