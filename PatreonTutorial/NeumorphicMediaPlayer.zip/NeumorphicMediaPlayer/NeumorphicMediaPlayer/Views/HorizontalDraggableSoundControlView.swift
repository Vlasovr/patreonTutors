//
//  HorizontalDraggableSoundControlView.swift
//  NeumorphicMediaPlayer
//
//  Created by Damra on 9.11.2024.
//

import Foundation
import SwiftUI

// Horizontal Draggable Volume Control View
struct HorizontalDraggableSoundControlView: View {
    @State private var volume: CGFloat = 0.5 // Initial volume level (0 to 1)
    @State private var dragOffset: CGFloat = 0 // Drag offset to track the gesture
    
    var body: some View {
        ZStack {
            VStack(spacing: 50) {
                
                HStack(spacing: 20){
                    Image(systemName: "volume.1.fill")
                        .imageScale(.small)
                        .foregroundStyle(.white.opacity(0.6))
                    
                    // Volume Control Bar
                    ZStack(alignment: .leading) {
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.gray.opacity(0.2))
                            .frame(width: 200, height: 5)
                        
                        RoundedRectangle(cornerRadius: 20)
                            .fill(LinearGradient(
                                gradient: Gradient(colors: [Color("buttoncolor"), Color.purple]),
                                startPoint: .leading,
                                endPoint: .trailing
                            ))
                            .frame(width: 200 * volume, height: 5) // Adjust width based on volume level
                            .animation(.easeInOut, value: volume)
                    }
                    .gesture(
                        DragGesture()
                            .onChanged { gesture in
                                // Update volume based on the drag gesture
                                updateVolume(from: gesture)
                            }
                    )
                    
                    Image(systemName: "speaker.wave.3.fill")
                        .imageScale(.small)
                        .foregroundStyle(.white.opacity(0.6))
                }
            }
        }
    }
    
    // Update volume function based on drag gesture
    private func updateVolume(from gesture: DragGesture.Value) {
        // Adjust volume based on horizontal drag distance
        let dragAmount = gesture.translation.width
        let volumeChange = dragAmount / 5000 // Sensitivity factor to control responsiveness
        volume = min(max(volume + volumeChange, 0), 1) // Limit volume between 0 and 1
    }
}

#Preview {
    HorizontalDraggableSoundControlView()
}
