//
//  NeumorphicButton.swift
//  NeumorphicMediaPlayer
//
//  Created by Damra on 9.11.2024.
//

import Foundation
import SwiftUI

// Neumorphic Button Component
struct NeumorphicButton: View {
    var iconName: String
    var buttonColor: Color
    var imageColor: Color
    var frame: CGFloat
    var fontsize: CGFloat
    var action: () -> Void = {}
    
    var body: some View {
        Button(action: action) {
            Image(systemName: iconName)
                .font(.system(size: fontsize))
                .foregroundColor(imageColor) // Icon color
                .frame(width: frame, height: frame)
                .background(
                    Circle()
                        .fill(buttonColor)
                        .neumorphicShadow(darkShadow: Color.black.opacity(1), lightShadow: Color("buttoncolor").opacity(0.5)) // Neumorphic shadow effect
                        .softInnerShadow(Circle())
                )
        }
    }
}
