//
//  NeumorphicMediaPlayerView.swift
//  NeumorphicMediaPlayer
//
//  Created by Damra on 9.11.2024.
//

import Foundation
import SwiftUI

struct NeumorphicMediaPlayerView: View {
    @State private var isPlaying = false
    @State private var progress: Double = 0.5
    @State var control = [false,false,false]
    let controlImage = ["line.3.horizontal.decrease","shuffle","repeat"]
    @State var circleprogress: CGFloat = 0.0
    var body: some View {
        ZStack {
            Color.Neumorphic.main.ignoresSafeArea() // Set the background color
            
            VStack(spacing: 30) {
                // Title
                VStack {
                    Text("SwiftUICodes")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.Neumorphic.secondary)
                    
                    Text("Desire")
                        .foregroundColor(.white.opacity(0.5))
                        .font(.subheadline)
                }.padding(.top)
                
                Spacer()
                
                // Circular Sound Wave Icon
                HStack(spacing: 40) {
                    Text("00:00")
                        .font(.footnote)
                        .foregroundStyle(.white.opacity(0.6))
                    
                    ZStack {
                        Circle()
                            .fill(Color(hex: "2A2A2A")) // Use a darker color for the circle background
                            .frame(width: 140, height: 140)
                            .neumorphicShadow(darkShadow: Color.black.opacity(1), lightShadow: Color("buttoncolor").opacity(0.5)) // Neumorphic shadow
                            .softInnerShadow(Circle())
                        
                        Circle()
                            .trim(from: 0.0, to: circleprogress) // Trim the circle to create a progress arc
                            .stroke(lineWidth: 5)
                            .fill(LinearGradient(
                                gradient: Gradient(colors: [Color("buttoncolor"), Color.purple]),
                                startPoint: .leading,
                                endPoint: .trailing
                            ))
                            .frame(width: 135, height: 135)
                            .rotationEffect(.degrees(-90)) // Rotate to start from the top
                            .animation(
                                .easeInOut(duration: 10),
                                value: circleprogress
                            ) //MARK: Kayıtta silinecek.
                        
                        Image(systemName: "waveform")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 60, height: 60)
                            .foregroundColor(Color("buttoncolor")) // Color of the waveform icon
                    }
                    
                    Text("04:56")
                        .font(.footnote)
                        .foregroundStyle(.white.opacity(0.6))
                    
                }
                
                Spacer()
                
                // Draggable Volume Control
                HorizontalDraggableSoundControlView() // Custom draggable volume control
                
                HStack(spacing: 30){
                    // Control buttons for different functions (e.g., filters, shuffle, repeat)
                    ForEach(controlImage.indices, id: \.self) { items in
                        NeumorphicButton(
                            iconName: controlImage[items],
                            buttonColor: Color(hex: "2A2A2A"),
                            imageColor: control[items] ? Color("buttoncolor") : Color.white
                                .opacity(0.6),
                            frame: 45, fontsize: 20) {
                                control[items].toggle()
                            }
                    }
                }.padding([.top, .bottom])
                
                // Playback Control Buttons
                HStack(spacing: 60) {
                    NeumorphicButton(
                        iconName: "backward",
                        buttonColor: Color(hex: "2A2A2A"),
                        imageColor: Color.white.opacity(0.6),
                        frame: 55, fontsize: 20
                    )
                    NeumorphicButton(
                        iconName: isPlaying ? "pause.fill" : "play.fill",
                        buttonColor: Color(hex: "2A2A2A"),
                        imageColor: Color("buttoncolor"),
                        frame: 75, fontsize: 35
                    ) {
                        isPlaying.toggle() // Toggle play/pause state
                        withAnimation(.easeInOut) {
                            circleprogress = 1.0
                        }
                    }
                    NeumorphicButton(
                        iconName: "forward",
                        buttonColor: Color(hex: "2A2A2A"),
                        imageColor: Color.white.opacity(0.6),
                        frame: 55, fontsize: 20
                    )
                }
                
                Spacer()
                
            }
        }
    }
}

#Preview {
    NeumorphicMediaPlayerView()
}
