//
//  code2App.swift
//  code2
//
//  Created by M.Damra on 10.01.2025.
//

import SwiftUI

@main
struct code2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
