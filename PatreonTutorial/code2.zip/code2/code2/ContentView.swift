//
//  ContentView.swift
//  code2
//
//  Created by M.Damra on 10.01.2025.
//

import SwiftUI
import Combine

struct ContentView: View {
    var body: some View {
        HomeView()
            .environmentObject(WeatherViewModel())
    }
}

#Preview {
    ContentView()
}

// MARK: - WeatherFetchState
/// Represents the current state of weather data fetching.
enum WeatherFetchState {
    case idle
    case loading
    case success
    case failure(String) // Holds an error message
}

// MARK: - WeatherViewModel (Combine + ObservableObject)
class WeatherViewModel: ObservableObject {
    
    // Published properties that SwiftUI will observe
    @Published var temperature: String = "--"
    @Published var description: String = "No data yet."
    @Published var humidity: String = "--"
    
    @Published var fetchState: WeatherFetchState = .idle
    
    private var cancellables = Set<AnyCancellable>()
    
    /// Simulates fetching weather data from an API.
    func fetchWeatherData() {
        // Reset state to loading
        fetchState = .loading
        
        // Create multiple mocked publishers for different weather properties
        let temperaturePublisher = Just("25ºC")
            .delay(for: .seconds(2), scheduler: DispatchQueue.main)
            .setFailureType(to: Error.self) // So we can combine them in a single pipeline

        let descriptionPublisher = Just("Sunny with a light breeze")
            .delay(for: .seconds(3), scheduler: DispatchQueue.main)
            .setFailureType(to: Error.self)

        let humidityPublisher = Just("40%")
            .delay(for: .seconds(1), scheduler: DispatchQueue.main)
            .setFailureType(to: Error.self)

        // Combine the three publishers into one pipeline using `zip`
        Publishers.Zip3(temperaturePublisher, descriptionPublisher, humidityPublisher)
            .sink(receiveCompletion: { [weak self] completion in
                switch completion {
                case .finished:
                    // Mark the fetch as success if everything completes
                    DispatchQueue.main.async {
                        self?.fetchState = .success
                    }
                case .failure(let error):
                    // If anything goes wrong, show an error
                    DispatchQueue.main.async {
                        self?.fetchState = .failure(error.localizedDescription)
                    }
                }
            }, receiveValue: { [weak self] temp, desc, humidity in
                // Update each property
                self?.temperature = temp
                self?.description = desc
                self?.humidity = humidity
            })
            .store(in: &cancellables)
    }
}

// MARK: - HomeView
struct HomeView: View {
    @EnvironmentObject var weatherVM: WeatherViewModel
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Ultra thin material background
                Color.clear
                    .background(.ultraThinMaterial)
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 30) {
                        
                        // App Title
                        VStack(spacing: 10) {
                            Image(systemName: "cloud.sun.fill")
                                .symbolRenderingMode(.palette)
                                .foregroundStyle(.yellow, .blue)
                                .font(.system(size: 60))
                            
                            Text("SwiftUI & Combine Weather")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                        }
                        
                        // Tutorial Section
                        tutorialSection
                        
                        // Navigation to WeatherDetailView
                        NavigationLink {
                            WeatherDetailView()
                        } label: {
                            Label("Check Today's Weather", systemImage: "sun.max.fill")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .background(LinearGradient(
                                    colors: [.blue, .green],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                ))
                                .cornerRadius(10)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 40)
                }
            }
        }
    }
    
    private var tutorialSection: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Quick Tutorial")
                .font(.headline)
                .padding(.bottom, 5)
            
            TutorialStepView(
                stepNumber: 1,
                imageName: "1.circle.fill",
                description: "Tap on 'Check Today's Weather' to see current conditions."
            )
            
            TutorialStepView(
                stepNumber: 2,
                imageName: "2.circle.fill",
                description: "Observe how Combine fetches and updates data asynchronously."
            )
            
            TutorialStepView(
                stepNumber: 3,
                imageName: "3.circle.fill",
                description: "Use the refresh button if you'd like to simulate another fetch."
            )
            
            TutorialStepView(
                stepNumber: 4,
                imageName: "4.circle.fill",
                description: "In case of an error, a retry button will appear to fetch again."
            )
        }
        .padding()
        .background(.regularMaterial)
        .cornerRadius(15)
    }
}

// MARK: - WeatherDetailView
struct WeatherDetailView: View {
    @EnvironmentObject var weatherVM: WeatherViewModel
    
    var body: some View {
        ZStack {
            Color.clear
                .background(.ultraThinMaterial)
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                Text("Today's Weather")
                    .font(.title)
                    .fontWeight(.semibold)
                
                // Display weather state
                weatherContent
                
                // Refresh / Retry Button
                fetchOrRetryButton
                
                // Navigation to forecast
                NavigationLink {
                    ForecastListView()
                } label: {
                    Label("View 5-Day Forecast", systemImage: "calendar")
                        .padding()
                        .background(LinearGradient(colors: [.orange, .pink],
                                                   startPoint: .topLeading,
                                                   endPoint: .bottomTrailing))
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                
                Spacer()
            }
            .padding()
        }
        .navigationTitle("Detail")
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text("SwiftUI & Combine")
                    .font(.headline)
            }
        }
    }
    
    // MARK: - Weather Content
    @ViewBuilder
    private var weatherContent: some View {
        switch weatherVM.fetchState {
        case .idle:
            // Prompt user to fetch weather data
            infoView(title: "No Data Fetched", subtitle: "Tap the button below to fetch latest weather.")
            
        case .loading:
            // Show loading spinner
            ProgressView("Fetching Weather...")
                .progressViewStyle(CircularProgressViewStyle(tint: .blue))
                .padding()
            
        case .success:
            // Show weather details
            VStack(spacing: 10) {
                weatherDetailRow(
                    iconName: "thermometer",
                    title: "Temperature",
                    value: weatherVM.temperature
                )
                
                weatherDetailRow(
                    iconName: "cloud.fill",
                    title: "Condition",
                    value: weatherVM.description
                )
                
                weatherDetailRow(
                    iconName: "humidity.fill",
                    title: "Humidity",
                    value: weatherVM.humidity
                )
            }
            .transition(.opacity.combined(with: .scale))
            
        case .failure(let errorMessage):
            // Error view with a message
            VStack(spacing: 10) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.system(size: 50))
                    .foregroundColor(.red)
                
                Text("Error")
                    .font(.title2)
                    .fontWeight(.semibold)
                Text(errorMessage)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
            }
            .transition(.opacity.combined(with: .scale))
        }
    }
    
    // MARK: - Fetch or Retry Button
    private var fetchOrRetryButton: some View {
        Button {
            weatherVM.fetchWeatherData()
        } label: {
            switch weatherVM.fetchState {
            case .idle, .failure:
                Label("Fetch Weather", systemImage: "cloud.sun.fill")
                    .font(.headline)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
                    .foregroundColor(.white)
                
            case .loading:
                Label("Fetching...", systemImage: "clock.fill")
                    .font(.headline)
                    .padding()
                    .background(Color.gray)
                    .cornerRadius(10)
                    .foregroundColor(.white)
                    .opacity(0.7)
                
            case .success:
                Label("Refresh Weather", systemImage: "arrow.clockwise")
                    .font(.headline)
                    .padding()
                    .background(Color.green)
                    .cornerRadius(10)
                    .foregroundColor(.white)
            }
        }
        //.disabled(weatherVM.fetchState == .loading)
        //.animation(.easeInOut, value: weatherVM.fetchState)
    }
    
    // MARK: - Helpers
    private func infoView(title: String, subtitle: String) -> some View {
        VStack(spacing: 8) {
            Image(systemName: "info.circle.fill")
                .font(.system(size: 40))
                .foregroundColor(.blue)
            Text(title)
                .font(.headline)
            Text(subtitle)
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 20)
        }
    }
    
    private func weatherDetailRow(iconName: String, title: String, value: String) -> some View {
        HStack {
            Image(systemName: iconName)
                .foregroundColor(.blue)
                .frame(width: 30)
            Text("\(title):")
                .font(.headline)
            Spacer()
            Text(value)
                .fontWeight(.semibold)
        }
        .padding(.horizontal, 10)
    }
}

// MARK: - ForecastListView
struct ForecastListView: View {
    // A mock array of forecast data for 5 days
    private let fiveDayForecast: [ForecastDay] = [
        ForecastDay(day: "Mon", icon: "cloud.sun.fill", highTemp: "28ºC", lowTemp: "19ºC"),
        ForecastDay(day: "Tue", icon: "cloud.bolt.fill", highTemp: "30ºC", lowTemp: "20ºC"),
        ForecastDay(day: "Wed", icon: "cloud.sun.rain.fill", highTemp: "26ºC", lowTemp: "18ºC"),
        ForecastDay(day: "Thu", icon: "cloud.fog.fill", highTemp: "23ºC", lowTemp: "16ºC"),
        ForecastDay(day: "Fri", icon: "sun.max.fill", highTemp: "29ºC", lowTemp: "21ºC")
    ]
    
    var body: some View {
        ZStack {
            Color.clear
                .background(.ultraThinMaterial)
                .ignoresSafeArea()
            
            List(fiveDayForecast) { forecast in
                HStack {
                    Image(systemName: forecast.icon)
                        .symbolRenderingMode(.palette)
                        .foregroundStyle(.yellow, .blue)
                        .frame(width: 30)
                    
                    Text(forecast.day)
                        .font(.headline)
                    
                    Spacer()
                    
                    Text("High: \(forecast.highTemp)")
                        .font(.subheadline)
                    
                    Text("Low: \(forecast.lowTemp)")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .padding(.vertical, 6)
            }
            .navigationTitle("5-Day Forecast")
        }
    }
}

// MARK: - ForecastDay Model
struct ForecastDay: Identifiable {
    let id = UUID()
    let day: String
    let icon: String
    let highTemp: String
    let lowTemp: String
}

// MARK: - TutorialStepView
struct TutorialStepView: View {
    let stepNumber: Int
    let imageName: String
    let description: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: imageName)
                .font(.title2)
                .foregroundColor(.blue)
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Step \(stepNumber)")
                    .font(.headline)
                Text(description)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 5)
    }
}

