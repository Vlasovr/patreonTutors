//
//  CustomTaskAppApp.swift
//  CustomTaskApp
//
//  Created by Damra on 30.10.2023.
//

import SwiftUI

@main
struct CustomTaskAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
