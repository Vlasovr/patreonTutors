//
//  FirstTextAnimationApp.swift
//  FirstTextAnimation
//
//  Created by Altuğ Nuri ASLANTAŞ on 8.10.2024.
//

import SwiftUI

@main
struct FirstTextAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
