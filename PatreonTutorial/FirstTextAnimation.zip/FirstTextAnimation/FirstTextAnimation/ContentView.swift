//
//  ContentView.swift
//  FirstTextAnimation
//
//  Created by Altuğ Nuri ASLANTAŞ on 8.10.2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            // Background color with slight opacity covering the entire screen
            Color.black.opacity(0.9).edgesIgnoringSafeArea(.all)
            VStack {
                // Main title text with different colors and formatting
                Text(
                    "SwiftUI Codes\n\(Text("Text Animation").foregroundColor(.pink))"
                )
                .font(.system(size: 25)) // Sets the font size
                .fontWeight(.heavy)   // Makes the font bold
                .multilineTextAlignment(.center) // Aligns text to the center
                .lineLimit(2) // Limits the number of text lines to 2
                .minimumScaleFactor(0.1)  // Allows the text to scale down if needed
                .padding()// Adds padding around the text
                .foregroundColor(.green)  // Sets the main text color to green
                // First text animation: Animated "Text Animation" string
                FirstTextAnimationView(
                    text: "Text Animation",
                    startTime: 0.0,
                    textFont: .custom("Bebas Neue", size: 30),
                    textColor: .white
                )
                // Second text animation: Animated "Made By @SwiftuiCodes" string
                FirstTextAnimationView(
                    text: "Made By @SwiftuiCodes",
                    startTime: 1.5, // Adds delay before this text starts animating
                    textFont: .title,
                    textColor: .orange
                )
                .padding(.top, 10)  // Adds space between the first and second animation views
            }
        }
    }
}

struct FirstTextAnimationView: View {
    let characters: Array<String.Element>  // Array of characters from the input text
    @State var offsetYForBounce: CGFloat = -50  // Y-axis offset for bounce animation (starts off-screen)
    @State var opacity: CGFloat = 0 // Opacity for fade-in animation (starts invisible)
    @State var baseTime: Double // Base time delay for animation start
    @State var textColor: Color // Text color passed from initialization
    @State var textFont: Font   // Font used for the text passed from initialization
    // Initialization of the view
    init(
        text: String, // The text to animate
        startTime: Double, // Delay before animation starts
        textFont: Font,// Font style
        textColor: Color = .white  // Default text color is white unless specified
    ){
        self.characters = Array(text)  // Convert input text to an array of characters
        self.baseTime = startTime  // Set the base start time for animation
        self.textFont = textFont   // Set the font style
        self.textColor = textColor // Set the text color
    }
    var body: some View {
        HStack(spacing: 0){  // Horizontal stack of characters with no spacing
            // Loop through each character in the text array
            ForEach(0..<characters.count) { num in
                Text(String(self.characters[num]))  // Display each character as a separate Text view
                    .font(textFont) // Apply the font style
                    .offset(x: 0.0, y: offsetYForBounce) // Apply Y-offset for bounce effect
                    .opacity(opacity)   // Apply opacity for fade-in effect
                    .animation(
                        .spring(response: 0.2, dampingFraction: 0.5, blendDuration: 0.1)
                        .delay(Double(num) * 0.1), // Apply staggered delay for each character
                        value: offsetYForBounce
                    )
                    .foregroundColor(textColor) // Apply the text color
                    .lineLimit(1)   // Limit text to a single line
                    .minimumScaleFactor(0.1)// Scale down the text if needed
            }
            // Trigger animation on tap gesture
            .onTapGesture {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.0) {
                    opacity = 0   // Fade out all characters
                    offsetYForBounce = -50// Move characters off-screen
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                    opacity = 1   // Fade characters back in
                    offsetYForBounce = 0  // Bring characters back to original position
                }
            }
            // When the view appears, start the bounce and opacity animation
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + (0.8 + baseTime)) {
                    opacity = 1   // Make characters visible
                    offsetYForBounce = 0  // Bounce characters into place
                }
            }
        }
    }
}

#Preview {
    ContentView()  // Preview of the ContentView struct for SwiftUI preview canvas
} 
