import SwiftUI
import PDFKit

// A UIViewRepresentable wrapper for PDFView to integrate PDFKit with SwiftUI
struct PDFViewer: UIViewRepresentable {
    let pdfURL: URL
    @Binding var currentPage: Int
    @Binding var zoomScale: CGFloat

    func makeUIView(context: Context) -> PDFView {
        let pdfView = PDFView()
        pdfView.autoScales = true // Automatically scale the PDF to fit the view
        if let document = PDFDocument(url: pdfURL) {
            pdfView.document = document
            // Navigate to the initial page
            if let firstPage = document.page(at: currentPage - 1) {
                pdfView.go(to: firstPage)
            }
        }
        return pdfView
    }

    func updateUIView(_ uiView: PDFView, context: Context) {
        guard let document = uiView.document else { return }

        // Update the current page if it has changed
        if let page = document.page(at: currentPage - 1) {
            uiView.go(to: page)
        }

        // Apply the current zoom scale
        if zoomScale == 1.0 {
            uiView.autoScales = true // Reset to fit the page
        } else {
            uiView.autoScales = false // Disable auto scaling for manual zoom
            uiView.scaleFactor = zoomScale
        }
    }
}

struct ContentView: View {
    @State private var currentPage: Int = 1
    @State private var totalPages: Int = 0
    @State private var zoomScale: CGFloat = 1.0

    var body: some View {
        VStack {
            // Navigation Bar with Previous and Next buttons and page indicator
            HStack {
                // Previous Page Button with SF Symbol
                Button(action: goToPreviousPage) {
                    Image(systemName: "chevron.left")
                        .font(.title2)
                }
                .disabled(currentPage <= 1) // Disable if on the first page

                Spacer()

                // Page Indicator
                Text("Page \(currentPage) / \(totalPages)")
                    .font(.headline)

                Spacer()

                // Next Page Button with SF Symbol
                Button(action: goToNextPage) {
                    Image(systemName: "chevron.right")
                        .font(.title2)
                }
                .disabled(currentPage >= totalPages) // Disable if on the last page
            }
            .padding()
            .background(Color(UIColor.systemGray6)) // Light gray background for the navigation bar

            // PDF Viewer
            if let pdfURL = Bundle.main.url(forResource: "example", withExtension: "pdf") {
                PDFViewer(pdfURL: pdfURL, currentPage: $currentPage, zoomScale: $zoomScale)
                    .onAppear {
                        updateTotalPages(from: pdfURL)
                    }
                    .onChange(of: currentPage) { _ in
                        // Reset zoom scale to fit when page changes
                        zoomScale = 1.0
                    }
            } else {
                // Display an error message if the PDF is not found
                Text("PDF not found!")
                    .foregroundColor(.red)
                    .padding()
            }

            // Zoom Controls
            HStack {
                // Zoom Out Button with SF Symbol
                Button(action: zoomOut) {
                    Image(systemName: "minus.magnifyingglass")
                        .font(.title2)
                }
                .disabled(zoomScale <= 0.5) // Disable if zoom scale is at minimum

                Spacer()

                // Zoom In Button with SF Symbol
                Button(action: zoomIn) {
                    Image(systemName: "plus.magnifyingglass")
                        .font(.title2)
                }
                .disabled(zoomScale >= 3.0) // Disable if zoom scale is at maximum
            }
            .padding()
            .background(Color(UIColor.systemGray6)) // Light gray background for the zoom controls
        }
    }

    // MARK: - Helper Methods

    /// Updates the total number of pages in the PDF document
    private func updateTotalPages(from pdfURL: URL) {
        if let document = PDFDocument(url: pdfURL) {
            totalPages = document.pageCount
        }
    }

    /// Navigates to the previous page if possible
    private func goToPreviousPage() {
        if currentPage > 1 {
            currentPage -= 1
        }
    }

    /// Navigates to the next page if possible
    private func goToNextPage() {
        if currentPage < totalPages {
            currentPage += 1
        }
    }

    /// Increases the zoom scale, up to a maximum value
    private func zoomIn() {
        if zoomScale < 3.0 {
            zoomScale += 0.1
        }
    }

    /// Decreases the zoom scale, down to a minimum value
    private func zoomOut() {
        if zoomScale > 0.5 {
            zoomScale -= 0.1
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
