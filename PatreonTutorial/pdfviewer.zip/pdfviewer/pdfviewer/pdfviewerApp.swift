import SwiftUI

@main
struct pdfviewerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
