//
//  Habit_Tracker_TemplateApp.swift
//  Habit Tracker Template
//
//  Created by Damra on 24.07.2024.
//

import SwiftUI

@main
struct Habit_Tracker_TemplateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
