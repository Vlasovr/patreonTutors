//
//  ContentView.swift
//  Habit Tracker Template
//
//  Created by Damra on 24.07.2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        MainView()
    }
}

#Preview {
    ContentView()
}

struct MainView: View {
    let weekDays = [("Mon", 20),("Tue", 21),("Wed", 22),("Thu", 23),("Fri", 24),("Sat", 25),("Sun", 26)]
    @State private var selectedIndex = 1
    @State private var selectedTabItem = 0
    
    @State private var daysName = ["Morning","Afternoon","Night"]
    @State private var habits = ["4 habits","7 habits","5 habits"]
    
    @State private var exerciseToggle = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Image("background").resizable().ignoresSafeArea()
                Color.clear
                    .background(
                        TransparentBlurView(removeFilters: true)
                            .blur(radius: 9, opaque: true)
                            .background(Color.white.opacity(0.3))
                    )
                    .clipShape(.rect(cornerRadius: 25, style: .continuous))
                    .background(
                        RoundedRectangle(cornerRadius: 25, style: .continuous)
                            .stroke(.white.opacity(0.3), lineWidth: 1.5)
                    )
                    .ignoresSafeArea()

                VStack(spacing: 10) {
                    
                    HStack {
                        Spacer()
                        Text("Today")
                            .font(.custom("Rubik-Bold", size: 40))
                            .foregroundStyle(.white)
                        
                        Spacer()
                        
                        Image(systemName: "ellipsis").resizable()
                            .scaledToFit()
                            .frame(width: 25, height: 25, alignment: .center)
                        
                    }.padding(.horizontal)
                    

                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: weekDays.count)) {
                        ForEach(weekDays, id: \.0) { items, index in
                            ZStack {
                                
                                RoundedRectangle(cornerRadius: 50)
                                    .fill(selectedIndex == index ? .white : .clear)
                                    .frame(width: 55, height: 100)
                                
                                VStack(spacing: 10) {
                                    
                                    Text(items)
                                        .font(.custom("Rubik-Light", size: 20))
                                        .kerning(-1)
                                        .foregroundStyle(selectedIndex == index ? .linearGradient(colors: [Color.purple, Color.pink], startPoint: .top, endPoint: .bottom) : .linearGradient(colors: [.black.opacity(0.7)], startPoint: .top, endPoint: .bottom))
                                    
                                    Text(index.description)
                                        .font(.custom("Rubik-Regular", size: 20))
                                        .kerning(-1)
                                        .foregroundStyle(selectedIndex == index ? .linearGradient(colors: [Color.purple, Color.pink], startPoint: .top, endPoint: .bottom) : .linearGradient(colors: [.black], startPoint: .top, endPoint: .bottom))
                                }
                            }
                            
                            .onTapGesture {
                                withAnimation(.linear(duration: 0.2)) {
                                    selectedIndex = index
                                }
                            }
                            
                        }
                        
                    }.padding(.horizontal).padding(.bottom,40)
                    
                    ZStack {
                        
                        Image("circle")
                            .resizable()
                            .frame(width: 230, height: 230)
                            .opacity(0.7)
                            .offset(y: -210)
                        
                        Image("rounded")
                            .resizable()
                            .frame(maxHeight: 550)
                        
                        VStack {
                            TabView(selection: $selectedTabItem) {
                                
                                VStack(spacing: 5){
                                    
                                    Image("morning")
                                        .resizable()
                                        .renderingMode(.template)
                                        .scaledToFit()
                                        .frame(width: 65, height: 65).foregroundStyle(.linearGradient(colors: [Color.purple, Color.pink], startPoint: .top, endPoint: .bottom))
                                    
                                    Text(daysName[0])
                                        .font(.custom("Rubik-Medium", size: 25))
                                    
                                    Text(habits[0])
                                        .font(.custom("Rubik-Light", size: 16))
                                    
                                }.tag(0)
                                
                                VStack(spacing: 5){
                                    
                                    Image("afternoon")
                                        .resizable()
                                        .renderingMode(.template)
                                        .scaledToFit()
                                        .frame(width: 65, height: 65).foregroundStyle(.linearGradient(colors: [Color.purple, Color.pink], startPoint: .top, endPoint: .bottom))
                                    
                                    Text(daysName[1])
                                        .font(.custom("Rubik-Medium", size: 25))
                                    
                                    Text(habits[1])
                                        .font(.custom("Rubik-Light", size: 16))
                                    
                                }.tag(1)
                                
                                VStack(spacing: 5){
                                    Image("night")
                                        .resizable()
                                        .renderingMode(.template)
                                        .scaledToFit()
                                        .frame(width: 65, height: 65).foregroundStyle(.linearGradient(colors: [Color.purple, Color.pink], startPoint: .top, endPoint: .bottom))
                                    
                                    Text(daysName[2])
                                    
                                        .font(.custom("Rubik-Medium", size: 25))
                                    Text(habits[2])
                                        .font(.custom("Rubik-Light", size: 16))
                                    
                                }.tag(3)
                                
                            }.tabViewStyle(.page(indexDisplayMode: .never)).frame(maxHeight: 130).offset(y: -50)

                            ZStack {
                                RoundedRectangle(cornerRadius: 25)
                                    .fill(.white)
                                    .frame(height: 100)
                                    .shadow(color: .gray.opacity(0.5), radius: 10)
                                
                                HStack {
                                    VStack(alignment: .leading, spacing: 5){
                                        
                                        Text("Exercise")
                                            .font(.custom("Rubik-Regular", size: 30))
                                            .foregroundStyle(.black)
                                        
                                        HStack {
                                            
                                            Image(systemName: "star.fill")
                                                .imageScale(.medium)
                                                .foregroundStyle(.linearGradient(colors: [Color.purple, Color.pink], startPoint: .top, endPoint: .bottom))
                                            
                                            Text("New")
                                                .font(.custom("Rubik-Light", size: 20))
                                                .foregroundStyle(.black)
                                            
                                        }
                                    }
                                    
                                    Spacer()
                                    
                                    Text("0/10")
                                        .font(.custom("Rubik-Medium", size: 35))
                                        .foregroundStyle(.linearGradient(colors: [Color.purple, Color.pink], startPoint: .top, endPoint: .bottom))
                                    
                                }.padding(.horizontal, 20)
                                
                            }.padding(.top)
                                .onTapGesture {
                                    exerciseToggle.toggle()
                                }
                            
                            Spacer()
                            
                        }.padding(.horizontal).frame(maxHeight: 400)

                    }.padding(.top)
                    
                }
            }
        }
        .safeAreaInset(edge: .bottom) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(.white)
                    .frame(height: 100)
                    .shadow(color: .gray.opacity(0.5), radius: 10)
                
                Button {
                    
                } label: {
                    ZStack {
                        Circle()
                            .fill(.linearGradient(colors: [Color.purple, Color.pink], startPoint: .top, endPoint: .bottom))
                            .frame(width: 85, height: 85).opacity(0.5)
                            .offset(y: -50)
                        
                        Circle()
                            .fill(.linearGradient(colors: [Color.purple, Color.pink], startPoint: .top, endPoint: .bottom))
                            .frame(width: 100, height: 100).opacity(0.2)
                            .offset(y: -50)
                        
                        Circle()
                            .fill(.linearGradient(colors: [Color.purple, Color.pink], startPoint: .top, endPoint: .bottom))
                            .frame(width: 70, height: 70)
                            .overlay(
                                Image(systemName: "plus").resizable().frame(width: 35, height: 35).fontWeight(.regular).foregroundColor(.white)
                            )
                            .offset(y: -50)
                    }
                }
                
                HStack {
                    Button {
                        
                    } label: {
                        Image(systemName: "sun.max").resizable().frame(width: 35, height: 35)
                            .foregroundStyle(.linearGradient(colors: [Color.purple, Color.pink], startPoint: .top, endPoint: .bottom))
                    }
                    
                    Spacer()
                    
                    Button {
                        
                    } label: {
                        Image(systemName: "chart.pie").resizable().frame(width: 35, height: 35)
                            .foregroundStyle(.linearGradient(colors: [Color.purple, Color.pink], startPoint: .top, endPoint: .bottom))
                    }
                }.padding(.horizontal, 50)
                
                
            }
        }.ignoresSafeArea()
        
            .fullScreenCover(isPresented: $exerciseToggle) {
                ExerciseView()
            }
        
    }
}

struct ExerciseView: View {
    @Environment(\.dismiss) var dismiss
    var body: some View {
        NavigationStack {
            ZStack {
                Image("background").resizable().ignoresSafeArea()
                Color.clear
                    .background(
                        TransparentBlurView(removeFilters: true)
                            .blur(radius: 9, opaque: true)
                            .background(Color.white.opacity(0.3))
                    )
                    .clipShape(.rect(cornerRadius: 25, style: .continuous))
                    .background(
                        RoundedRectangle(cornerRadius: 25, style: .continuous)
                            .stroke(.white.opacity(0.3), lineWidth: 1.5)
                    )
                    .ignoresSafeArea()
                
                VStack(alignment: .leading, spacing: 30){
                    HStack {
                        Button {
                            dismiss()
                        } label: {
                            Image(systemName: "arrow.left").resizable().scaledToFit().frame(width: 25, height: 25).foregroundColor(.black)
                        }
                        
                        Spacer()
                        
                        Text("Exercise").font(.custom("Rubik-Bold", size: 40)).foregroundStyle(.white)
                        
                        Spacer()
                        
                        Image(systemName: "ellipsis").resizable().scaledToFit().frame(width: 25, height: 25)
                        
                    }
                    
                    HStack {
                        Image(systemName: "clock").resizable().scaledToFit().frame(width: 25, height: 25).foregroundStyle(.linearGradient(colors: [.purple, .pink], startPoint: .top, endPoint: .bottom))
                        
                        Text("Every Afternoon").font(.custom("Rubik-regular", size: 20)).foregroundStyle(.white)
                        
                        Spacer()
                        
                        Image(systemName: "chevron.right").resizable().scaledToFit().frame(width: 15, height: 15).fontWeight(.semibold).foregroundColor(.white)
                        
                    }
                    
                    HStack {
                        Image(systemName: "bell").resizable().scaledToFit().frame(width: 25, height: 25).foregroundStyle(.linearGradient(colors: [.purple, .pink], startPoint: .top, endPoint: .bottom))
                        
                        Text("Add Reminder").font(.custom("Rubik-regular", size: 20)).foregroundStyle(.white)
                        
                        Spacer()
                        
                        Image(systemName: "chevron.right").resizable().scaledToFit().frame(width: 15, height: 15).fontWeight(.semibold).foregroundColor(.white)
                        
                    }
                    
                    ZStack {
                        RoundedRectangle(cornerRadius: 25)
                            .fill(.white)
                            .frame(height: 380)
                        
                        Circle()
                            .fill(.linearGradient(colors: [.purple, .pink], startPoint: .top, endPoint: .bottom))
                            .frame(width: 40, height: 40)
                            .offset(x: 1, y: -8)
                        
                        VStack {
                            Text("July").font(.custom("Rubik-Medium", size: 25)).padding(.bottom)
                            
                            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 7)) {
                                ForEach(WeekDay.allCases, id: \.self) { day in
                                    Text(day.rawValue).font(.custom("Rubik-Regular", size: 18))
                                }
                            }
                            
                            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 7)) {
                                ForEach(1..<32, id: \.self) { numbers in
                                    Text(numbers.description).font(.custom("Rubik-Regular", size: 18))
                                        .foregroundStyle(numbers == 11 ? .white : .black)
                                        .padding(.all, 10)
                                }
                            }
                        }.padding(.horizontal, 5)
                    }
                    
                    ZStack {
                        RoundedRectangle(cornerRadius: 25)
                            .fill(.white)
                            .frame(height: 120)
                        
                        VStack {
                            Text("12\(Text("days").font(.custom("Rubik-Medium", size: 25)))").font(.custom("Rubik-Medium", size: 55)).foregroundStyle(.linearGradient(colors: [.purple, .pink], startPoint: .top, endPoint: .bottom))
                            
                            Text("Your current streak").font(.custom("Rubik-Regular", size: 16))
                            
                        }
                        
                    }
                    
                    Spacer()
                    
                    
                }.padding(.horizontal)
            }
        }
    }
}

enum WeekDay: String, CaseIterable, Identifiable {
    case monday = "Mon"
    case tuesday = "Tue"
    case wednesday = "Wed"
    case thursday = "Thu"
    case friday = "Fri"
    case saturday = "Sat"
    case sunday = "Sun"
    
    var id: String { self.rawValue }
    
    var index: Int {
        switch self {
        case .monday: return 0
        case .tuesday: return 1
        case .wednesday: return 2
        case .thursday: return 3
        case .friday: return 4
        case .saturday: return 5
        case .sunday: return 6
        }
    }
}
