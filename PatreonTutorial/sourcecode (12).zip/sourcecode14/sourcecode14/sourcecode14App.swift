//
//  sourcecode14App.swift
//  sourcecode14
//
//  Created by M.Damra on 23.01.2025.
//

import SwiftUI

@main
struct sourcecode14App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
