//
//  ContentView.swift
//  sourcecode14
//
//  Created by M.Damra on 23.01.2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        QuantumLoader()
    }
}

#Preview {
    ContentView()
}

struct QuantumLoader: View {
    @State private var phase = 0.0
    @State private var rotation = 0.0
    @State private var isCollapsed = true
    var body: some View {
        ZStack {
            // Electron Paths
            ForEach(0..<3) { index in
                Circle()
                    .stroke(
                        AngularGradient(
                            gradient: Gradient(colors: [.clear, .blue, .clear]),
                            center: .center,
                            startAngle: .degrees(0),
                            endAngle: .degrees(360)
                        ),
                        lineWidth: 2
                    )
                    .frame(
                        width: isCollapsed ? 80 : 150,
                        height: isCollapsed ? 80 : 150
                    )
                    .rotation3DEffect(.degrees(rotation), axis: (x: index == 0 ? 1 : 0, y: index == 1 ? 1 : 0, z: index == 2 ? 1 : 0))
            }
            
            // Orbital Particles
            ForEach(0..<8) { index in
                Circle()
                    .fill([.blue, .purple, .cyan].randomElement()!)
                    .frame(width: 8)
                    .offset(x: isCollapsed ? 40 : 75)
                    .rotationEffect(.degrees(Double(index) * 45 + phase))
            }
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 2).repeatForever(autoreverses: true)){
                isCollapsed.toggle()
            }
            withAnimation(.linear(duration: 4).repeatForever(autoreverses: false)){
                phase = 360
                rotation = 720
            }
        }
    }
}
