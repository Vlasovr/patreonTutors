import SwiftUI

@main
struct DetailedOnboardingApp: App {
    // Persist onboarding state so it shows only once.
    @AppStorage("hasOnboarded") var hasOnboarded: Bool = false

    var body: some Scene {
        WindowGroup {
            if hasOnboarded {
                MainView() // Replace with your main app content.
            } else {
                OnboardingView(hasOnboarded: $hasOnboarded)
            }
        }
    }
}

// MARK: - Onboarding View
struct OnboardingView: View {
    @Binding var hasOnboarded: Bool
    @State private var currentPage = 0
    let totalPages = 3

    var body: some View {
        ZStack {
            // Animated gradient background.
            AnimatedBackground()

            VStack {
                Spacer()
                // Use a TabView for a paging effect.
                TabView(selection: $currentPage) {
                    OnboardingPageView(
                        title: "Welcome",
                        subtitle: "Discover amazing features that make life easier.",
                        imageName: "sparkles"
                    )
                    .tag(0)
                    
                    OnboardingPageView(
                        title: "Stay Connected",
                        subtitle: "Engage with a vibrant community and share your ideas.",
                        imageName: "bubble.left.and.bubble.right.fill"
                    )
                    .tag(1)

                    OnboardingPageView(
                        title: "Get Started",
                        subtitle: "Begin your journey now and explore new horizons!",
                        imageName: "paperplane.fill"
                    )
                    .tag(2)
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
                .animation(.easeInOut, value: currentPage)
                
                Spacer()
                
                // Next / Get Started Button with a scaling and shadow animation.
                Button(action: {
                    if currentPage < totalPages - 1 {
                        currentPage += 1
                    } else {
                        withAnimation {
                            hasOnboarded = true
                        }
                    }
                }) {
                    Text(currentPage < totalPages - 1 ? "Next" : "Get Started")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(
                            Capsule()
                                .fill(Color.blue)
                                .shadow(color: Color.black.opacity(0.3), radius: 10, x: 0, y: 5)
                        )
                        .padding(.horizontal, 40)
                        .scaleEffect(1.0)
                        .animation(.spring(response: 0.5, dampingFraction: 0.6), value: currentPage)
                }
                .padding(.bottom, 40)
            }
        }
        .ignoresSafeArea()
    }
}

// MARK: - Onboarding Page View with Detailed Animations
struct OnboardingPageView: View {
    let title: String
    let subtitle: String
    let imageName: String

    @State private var animateText = false
    @State private var animateImage = false

    var body: some View {
        VStack(spacing: 20) {
            Spacer()
            // Animated image: scales, rotates, and fades in.
            Image(systemName: imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 150, height: 150)
                .scaleEffect(animateImage ? 1.0 : 0.5)
                .rotationEffect(.degrees(animateImage ? 0 : -45))
                .opacity(animateImage ? 1.0 : 0.0)
                .animation(Animation.spring(response: 1.0, dampingFraction: 0.5).delay(0.2), value: animateImage)
                .onAppear {
                    animateImage = true
                }
            
            // Animated title: slides in from above with a fade.
            Text(title)
                .font(.largeTitle)
                .bold()
                .foregroundColor(.white)
                .opacity(animateText ? 1.0 : 0.0)
                .offset(y: animateText ? 0 : -20)
                .animation(Animation.easeOut(duration: 1.0).delay(0.5), value: animateText)
            
            // Animated subtitle: slides in from below with a fade.
            Text(subtitle)
                .font(.title2)
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
                .padding(.horizontal, 30)
                .opacity(animateText ? 1.0 : 0.0)
                .offset(y: animateText ? 0 : 20)
                .animation(Animation.easeOut(duration: 1.0).delay(0.7), value: animateText)
            Spacer()
        }
        .onAppear {
            animateText = true
            // Reset image animation when view appears.
            animateImage = false
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                animateImage = true
            }
        }
        .onDisappear {
            // Reset animations when leaving the page.
            animateText = false
            animateImage = false
        }
    }
}

// MARK: - Animated Background View
struct AnimatedBackground: View {
    @State private var animateGradient = false

    var body: some View {
        // A linear gradient that smoothly shifts its start and end points.
        LinearGradient(
            gradient: Gradient(colors: [Color.purple, Color.blue, Color.pink]),
            startPoint: animateGradient ? .topLeading : .bottomTrailing,
            endPoint: animateGradient ? .bottomTrailing : .topLeading
        )
        .animation(Animation.linear(duration: 8).repeatForever(autoreverses: true), value: animateGradient)
        .onAppear {
            animateGradient = true
        }
    }
}

// MARK: - Main App View
struct MainView: View {
    var body: some View {
        Text("Main App")
            .font(.largeTitle)
            .padding()
    }
}
