//
//  ContentView.swift
//  sourcecode23
//
//  Created by M.Damra on 27.01.2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(spacing: 30){
         Text("Fade In Scale")
                .modifier(FadeInScaleEffect())
            
            Text("Slide From Left")
                .modifier(SlideInFromLeft())
            
            Text("3D Rotation")
                .font(.title)
                .modifier(Rotating3DEffect())
            
            Text("Typewriter")
                .modifier(TypewriterEffect(fullText: "Hello SwiftUI!"))
            
            Text("Gradient Pulse")
                .font(.title)
                .modifier(GradientPulseEffect())
            
            StaggeredCharacterEffect(text: "Staggered")
                .font(.title2)
            
            WaveTextEffect(text: "SwiftUICodes Wave")
                .font(.title)
                .bold()
            
            Text("Bounce Shadow")
                .font(.title)
                .modifier(BounceWithShadow())
            
            Text("Blur Fade In")
                .font(.title)
                .modifier(BlurFadeInEffect())
            
        }
    }
}

#Preview {
    ContentView()
}

struct FadeInScaleEffect: ViewModifier {
    @State private var animate = false
    func body(content: Content) -> some View {
        content
            .opacity(animate ? 1 : 0)
            .scaleEffect(animate ? 1 : 0.8)
            .onAppear {
                Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { _ in
                    withAnimation(.easeInOut(duration: 1.5)) {
                        animate.toggle()
                    }
                }
            }
    }
}

struct SlideInFromLeft: ViewModifier {
    @State private var animate = false
    func body(content: Content) -> some View {
        content
            .offset(x: animate ? 0 : -UIScreen.main.bounds.width)
            .animation(.spring(response: 0.6, dampingFraction: 0.7, blendDuration: 0.5), value: animate)
            .onAppear {
                Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { _ in
                    withAnimation(.easeInOut(duration: 1.5)) {
                        animate.toggle()
                    }
                }
            }
    }
}

struct Rotating3DEffect: ViewModifier {
    @State private var rotate = false
    func body(content: Content) -> some View {
        content
            .rotation3DEffect(.degrees(rotate ? 0 : 45), axis: (x: 1.0, y: 0.0, z: 0.0), anchor: .bottom)
            .animation(.easeInOut(duration: 1.5).repeatCount(1, autoreverses: false), value: rotate)
            .onAppear {
                Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { _ in
                    withAnimation(.easeInOut(duration: 1.5)) {
                        rotate.toggle()
                    }
                }
            }
    }
}

struct TypewriterEffect: ViewModifier {
    @State private var typedText = ""
    let fullText: String
    
    func body(content: Content) -> some View {
        Text(typedText)
            .font(.title)
            .onAppear {
                var charIndex = 0
                Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { timer in
                    if charIndex < fullText.count {
                        let index = fullText.index(fullText.startIndex, offsetBy: charIndex)
                        typedText += String(fullText[index])
                        charIndex += 1
                    } else {
                        timer.invalidate()
                    }
                }
            }
    }
}

struct GradientPulseEffect: ViewModifier {
    @State private var animateGradient = false
    
    func body(content: Content) -> some View {
        content
            .foregroundStyle(LinearGradient(colors: [.blue, .purple, .pink], startPoint: .leading, endPoint: .trailing))
            .scaleEffect(animateGradient ? 1.1 : 1.0)
            .animation(.easeInOut(duration: 1.0).repeatForever(autoreverses: true), value: animateGradient)
            .onAppear {
                animateGradient = true
            }
    }
}

struct StaggeredCharacterEffect: View {
    let text: String
    @State private var animate = false
    
    var body: some View {
        HStack(spacing: 0) {
            ForEach(Array(text.enumerated()), id: \.offset) { index, character in
                Text(String(character))
                    .offset(y: animate ? 0 : 50)
                    .opacity(animate ? 1 : 0)
                    .animation(.easeOut(duration: 0.5).delay(Double(index) * 0.05), value: animate)
            }
        }
        .onAppear {
            Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { _ in
                withAnimation(.easeInOut(duration: 1.5)) {
                    animate.toggle()
                }
            }
        }
    }
}

struct WaveTextEffect: View {
    let text: String
    @State private var waveOffset = 0.0
    
    var body: some View {
        HStack(spacing: 0){
            ForEach(Array(text.enumerated()), id: \.offset) { index, character in
                Text(String(character))
                    .offset(y: waveOffset * sin(Double(index) * .pi / 2))
                    .rotation3DEffect(.degrees(waveOffset * 20), axis: (x: 1, y: 0, z: 0))
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 1.0).repeatForever(autoreverses: true)) {
                waveOffset = 1.0
            }
        }
    }
}

struct BounceWithShadow: ViewModifier {
    @State private var bounce = false
    
    func body(content: Content) -> some View {
        content
            .shadow(color: .purple, radius: bounce ? 20 : 5, x: 0, y: bounce ? 10 : 0)
            .scaleEffect(bounce ? 1.2 : 1.0)
            .animation(.spring(response: 0.5, dampingFraction: 0.3, blendDuration: 1).repeatForever(), value: bounce)
            .onAppear {
                bounce = true
            }
    }
}

struct BlurFadeInEffect: ViewModifier {
    @State private var blur: CGFloat = 20
    @State private var opacity: Double = 0
    
    func body(content: Content) -> some View {
        content
            .blur(radius: blur)
            .opacity(opacity)
            .onAppear {
                Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { _ in
                    withAnimation(.easeInOut(duration: 1.5)) {
                        blur = 0
                        opacity = 1
                    }
                }
            }
    }
}
