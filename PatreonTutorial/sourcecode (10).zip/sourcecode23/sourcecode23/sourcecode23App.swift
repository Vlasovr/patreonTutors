//
//  sourcecode23App.swift
//  sourcecode23
//
//  Created by M.Damra on 27.01.2025.
//

import SwiftUI

@main
struct sourcecode23App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
