//
//  ContentView.swift
//  VideoExample
//
//  Created by Damra on 2.11.2024.
//

import SwiftUI

struct ContentView: View {
    // MARK: - State Variables
    @State private var videoURL: URL? = nil
    @State private var showShareSheet: Bool = false
    @State private var showSaveAlert: Bool = false
    @State private var saveAlertMessage: String = ""
    @State private var isProcessing: Bool = false
    
    // Video settings
    @State private var videoDuration: Double = 5.0 // in seconds
    @State private var frameRate: Int = 30 // frames per second
    var body: some View {
        NavigationStack {
            ScrollView(.vertical, showsIndicators: false) {
                VStack(spacing: 30) {
                    // Header
                    Text("SwiftUI to Video Converter")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.center)
                        .padding(.top, 40)
                        .foregroundColor(.primary)
                    
                    // AnimatedSampleView to be captured as video
                    AnimatedSampleView()
                        .padding()
                        .background(Color.yellow.opacity(0.3))
                        .cornerRadius(15)
                        .shadow(radius: 10)
                        .frame(width: 300, height: 200)
                    
                    // Video Settings
                    VideoSettingsView(videoDuration: $videoDuration, frameRate: $frameRate)
                    
                    // Conversion and Export Buttons
                    ConversionButtonsView(isProcessing: isProcessing,
                                          onConvert: {
                        convertViewToVideo()
                    })
                    
                    // Display the Converted Video
                    if let videoURL = videoURL {
                        ConvertedVideoView(videoURL: videoURL, onShare: {
                            showShareSheet = true
                        }, onSave: {
                            saveVideoToPhotos(videoURL)
                        })
                        .transition(.opacity)
                        .animation(.easeInOut, value: videoURL)
                    }
                    
                    Spacer()
                }
                .padding()
            }
            .navigationBarHidden(true)
            .background(
                LinearGradient(gradient: Gradient(colors: [Color(UIColor.systemBackground), Color.blue.opacity(0.1)]),
                               startPoint: .top,
                               endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
                )
            .sheet(isPresented: $showShareSheet) {
                if let videoURL = videoURL {
                    ShareSheet(activityItems: [videoURL])
                }
            }
            .alert(isPresented: $showSaveAlert) {
                Alert(title: Text("Notification"),
                      message: Text(saveAlertMessage),
                      dismissButton: .default(Text("OK")))
            }
        }
    }
    
    // MARK: - Functions
    
    // Converts the AnimatedSampleView to a video and handles the export options
    private func convertViewToVideo() {
        isProcessing = true
        let videoGenerator = VideoGenerator(view: AnimatedSampleView(),
                                            duration: videoDuration,
                                            frameRate: frameRate)
        videoGenerator.generateVideo { result in
            DispatchQueue.main.async {
                isProcessing = false
                switch result {
                case .success(let url):
                    self.videoURL = url
                case .failure(let error):
                    self.saveAlertMessage = "Failed to generate video: \(error.localizedDescription)"
                    self.showSaveAlert = true
                }
            }
        }
    }
    
    // Saves the generated video to the photo library
    private func saveVideoToPhotos(_ url: URL) {
        let videoSaver = VideoSaver()
        videoSaver.successHandler = {
            saveAlertMessage = "Video successfully saved to your photo library."
            showSaveAlert = true
        }
        videoSaver.errorHandler = { error in
            saveAlertMessage = "Error saving video: \(error.localizedDescription)"
            showSaveAlert = true
        }
        videoSaver.saveVideo(url)
    }
}

#Preview {
    ContentView()
}
