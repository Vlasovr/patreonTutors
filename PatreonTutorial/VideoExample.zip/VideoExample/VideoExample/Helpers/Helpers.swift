//
//  ShareSheet.swift
//  VideoExample
//
//  Created by Damra on 2.11.2024.
//

import SwiftUI
import AVFoundation
import Photos
import AVKit

// MARK: - ShareSheet

struct ShareSheet: UIViewControllerRepresentable {
    var activityItems: [Any]
    var applicationActivities: [UIActivity]? = nil

    func makeUIViewController(context: Context) -> some UIViewController {
        let controller = UIActivityViewController(activityItems: activityItems,
                                                  applicationActivities: applicationActivities)
        return controller
    }

    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {}
}

// MARK: - VideoGenerator

class VideoGenerator {
    // MARK: - Properties
    private let view: AnyView
    private let duration: Double
    private let frameRate: Int
    
    // Completion handler type
    typealias CompletionHandler = (Result<URL, Error>) -> Void
    
    // MARK: - Initialization
    init<V: View>(view: V, duration: Double, frameRate: Int) {
        self.view = AnyView(view)
        self.duration = duration
        self.frameRate = frameRate
    }
    
    // MARK: - Video Generation
    
    /// Generates a video from the SwiftUI view
    func generateVideo(completion: @escaping CompletionHandler) {
        DispatchQueue.global(qos: .userInitiated).async {
            // Define video settings
            let width: Int = 300
            let height: Int = 200
            let fps: Int32 = Int32(self.frameRate)
            let totalFrames = Int(self.duration * Double(self.frameRate))
            
            // Create a temporary file URL
            let tempDirectory = FileManager.default.temporaryDirectory
            let fileURL = tempDirectory.appendingPathComponent("output_\(UUID().uuidString).mp4")
            
            // Remove existing file if any
            try? FileManager.default.removeItem(at: fileURL)
            
            // Define AVAssetWriter
            guard let writer = try? AVAssetWriter(outputURL: fileURL, fileType: .mp4) else {
                completion(.failure(VideoGenerationError.assetWriterFailed))
                return
            }
            
            // Define video settings
            let videoSettings: [String: Any] = [
                AVVideoCodecKey: AVVideoCodecType.h264,
                AVVideoWidthKey: width,
                AVVideoHeightKey: height
            ]
            
            // Define AVAssetWriterInput
            let writerInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
            writerInput.expectsMediaDataInRealTime = false
            
            // Define AVAssetWriterInputPixelBufferAdaptor
            let sourceBufferAttributes: [String: Any] = [
                kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32ARGB),
                kCVPixelBufferWidthKey as String: width,
                kCVPixelBufferHeightKey as String: height
            ]
            
            let pixelBufferAdaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: writerInput,
                                                                          sourcePixelBufferAttributes: sourceBufferAttributes)
            
            // Add input to writer
            if writer.canAdd(writerInput) {
                writer.add(writerInput)
            } else {
                completion(.failure(VideoGenerationError.cannotAddInput))
                return
            }
            
            // Start writing
            writer.startWriting()
            writer.startSession(atSourceTime: .zero)
            
            // Ensure the writer input is ready
            guard pixelBufferAdaptor.pixelBufferPool != nil else {
                completion(.failure(VideoGenerationError.pixelBufferPoolFailed))
                return
            }
            
            // Function to render a single frame
            func renderFrame(at frame: Int) -> UIImage? {
                let progress = Double(frame) / Double(totalFrames)
                let animatedView = AnimatedSampleView(progress: progress)
                    .frame(width: CGFloat(width), height: CGFloat(height))
                
                // Render the view to UIImage on the main thread
                var uiImage: UIImage?
                let semaphore = DispatchSemaphore(value: 0)
                
                DispatchQueue.main.async {
                    uiImage = animatedView.asUIImage()
                    semaphore.signal()
                }
                
                // Wait for rendering to complete
                semaphore.wait()
                return uiImage
            }
            
            // Append each frame
            for frame in 0..<totalFrames {
                autoreleasepool {
                    let presentationTime = CMTime(seconds: Double(frame) / Double(self.frameRate), preferredTimescale: 600)
                    
                    guard let uiImage = renderFrame(at: frame),
                          let pixelBuffer = uiImage.pixelBuffer(width: width, height: height) else {
                        completion(.failure(VideoGenerationError.renderFailed))
                        return
                    }
                    
                    while !writerInput.isReadyForMoreMediaData {
                        Thread.sleep(forTimeInterval: 0.1)
                    }
                    
                    if !pixelBufferAdaptor.append(pixelBuffer, withPresentationTime: presentationTime) {
                        completion(.failure(VideoGenerationError.appendFailed))
                        return
                    }
                }
            }
            
            // Finish writing
            writerInput.markAsFinished()
            writer.finishWriting {
                if writer.status == .completed {
                    completion(.success(fileURL))
                } else {
                    completion(.failure(writer.error ?? VideoGenerationError.unknown))
                }
            }
        }
    }
    
    // MARK: - VideoGenerationError
    
    enum VideoGenerationError: Error, LocalizedError {
        case assetWriterFailed
        case cannotAddInput
        case pixelBufferPoolFailed
        case renderFailed
        case appendFailed
        case unknown
        
        var errorDescription: String? {
            switch self {
            case .assetWriterFailed:
                return "Failed to initialize AVAssetWriter."
            case .cannotAddInput:
                return "Cannot add input to AVAssetWriter."
            case .pixelBufferPoolFailed:
                return "Pixel buffer pool is unavailable."
            case .renderFailed:
                return "Failed to render view to pixel buffer."
            case .appendFailed:
                return "Failed to append pixel buffer."
            case .unknown:
                return "An unknown error occurred."
            }
        }
    }
}


// MARK: - UIImage Extension for PixelBuffer

extension UIImage {
    /// Converts UIImage to CVPixelBuffer
    func pixelBuffer(width: Int, height: Int) -> CVPixelBuffer? {
        let attrs = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
                     kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue] as CFDictionary
        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         kCVPixelFormatType_32ARGB,
                                         attrs,
                                         &pixelBuffer)
        guard status == kCVReturnSuccess, let buffer = pixelBuffer else {
            return nil
        }
        
        CVPixelBufferLockBaseAddress(buffer, [])
        let pxdata = CVPixelBufferGetBaseAddress(buffer)
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        guard let context = CGContext(data: pxdata,
                                      width: width,
                                      height: height,
                                      bitsPerComponent: 8,
                                      bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
                                      space: rgbColorSpace,
                                      bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue) else {
            CVPixelBufferUnlockBaseAddress(buffer, [])
            return nil
        }
        
        context.clear(CGRect(x: 0, y: 0, width: width, height: height))
        guard let cgImage = self.cgImage else {
            CVPixelBufferUnlockBaseAddress(buffer, [])
            return nil
        }
        
        context.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
        CVPixelBufferUnlockBaseAddress(buffer, [])
        
        return buffer
    }
}


// MARK: - VideoSaver
// A helper class to save videos to the photo library
class VideoSaver: NSObject {
    var successHandler: (() -> Void)?
    var errorHandler: ((Error) -> Void)?
    
    /// Saves the video to the photo library
    func saveVideo(_ url: URL) {
        // Check authorization status
        let status = PHPhotoLibrary.authorizationStatus()
        switch status {
        case .authorized:
            save(url: url)
        case .denied, .restricted:
            errorHandler?(VideoSaveError.permissionDenied)
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization { newStatus in
                if newStatus == .authorized {
                    self.save(url: url)
                } else {
                    self.errorHandler?(VideoSaveError.permissionDenied)
                }
            }
        @unknown default:
            errorHandler?(VideoSaveError.unknown)
        }
    }
    
    /// Performs the actual saving of the video
    private func save(url: URL) {
        PHPhotoLibrary.shared().performChanges({
            PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
        }) { success, error in
            DispatchQueue.main.async {
                if success {
                    self.successHandler?()
                } else {
                    self.errorHandler?(error ?? VideoSaveError.unknown)
                }
            }
        }
    }
    
    // MARK: - VideoSaveError
    
    enum VideoSaveError: Error, LocalizedError {
        case permissionDenied
        case unknown
        
        var errorDescription: String? {
            switch self {
            case .permissionDenied:
                return "Permission to access the photo library is denied. Please enable it in Settings."
            case .unknown:
                return "An unknown error occurred while saving the video."
            }
        }
    }
}

// MARK: - VideoSettingsView

struct VideoSettingsView: View {
    @Binding var videoDuration: Double
    @Binding var frameRate: Int
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Video Settings")
                .font(.headline)
                .foregroundColor(.primary)
            
            // Video Duration Slider
            VStack(alignment: .leading) {
                Text("Duration: \(String(format: "%.1f", videoDuration)) seconds")
                    .foregroundColor(.secondary)
                Slider(value: $videoDuration, in: 1...10, step: 0.5)
            }
            
            // Frame Rate Picker
            VStack(alignment: .leading) {
                Text("Frame Rate: \(frameRate) fps")
                    .foregroundColor(.secondary)
                Picker("Frame Rate", selection: $frameRate) {
                    ForEach([24, 30, 60], id: \.self) { rate in
                        Text("\(rate) fps").tag(rate)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(10)
        .shadow(radius: 5)
    }
}

// MARK: - ConversionButtonsView

struct ConversionButtonsView: View {
    var isProcessing: Bool
    var onConvert: () -> Void
    
    var body: some View {
        VStack(spacing: 20) {
            // Convert to Video Button
            Button(action: onConvert) {
                HStack {
                    Image(systemName: "video")
                    Text(isProcessing ? "Processing..." : "Convert to Video")
                }
            }
            .disabled(isProcessing)
            .buttonStyle(CustomButtonStyle(backgroundColor: isProcessing ? Color.gray : Color.blue))
        }
        .padding([.leading, .trailing], 20)
    }
}

// MARK: - ConvertedVideoView

struct ConvertedVideoView: View {
    var videoURL: URL
    var onShare: () -> Void
    var onSave: () -> Void
    
    var body: some View {
        VStack {
            Text("Converted Video:")
                .font(.headline)
                .foregroundColor(.primary)
            
            VideoPlayerView(url: videoURL)
                .frame(height: 200)
                .cornerRadius(15)
                .shadow(radius: 5)
                .padding()
            
            // Share Video Button
            Button(action: onShare) {
                HStack {
                    Image(systemName: "square.and.arrow.up")
                    Text("Share Video")
                }
            }
            .buttonStyle(CustomButtonStyle(backgroundColor: Color.orange))
            
            // Save Video Button
            Button(action: onSave) {
                HStack {
                    Image(systemName: "square.and.arrow.down")
                    Text("Save to Photos")
                }
            }
            .buttonStyle(CustomButtonStyle(backgroundColor: Color.purple))
        }
    }
}

// MARK: - VideoPlayerView

struct VideoPlayerView: UIViewControllerRepresentable {
    var url: URL
    
    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = AVPlayer(url: url)
        controller.showsPlaybackControls = true
        return controller
    }
    
    func updateUIViewController(_ uiViewController: AVPlayerViewController, context: Context) {}
}

// MARK: - CustomButtonStyle

struct CustomButtonStyle: ButtonStyle {
    var backgroundColor: Color

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .frame(maxWidth: .infinity)
            .background(backgroundColor.opacity(configuration.isPressed ? 0.8 : 1.0))
            .foregroundColor(.white)
            .cornerRadius(10)
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
    }
}

// MARK: - AnimatedSampleView

struct AnimatedSampleView: View {
    var progress: Double? = nil
    @State private var animate = false

    var body: some View {
        VStack(spacing: 15) {
            Text("Animated SwiftUI!")
                .font(.largeTitle)
                .fontWeight(.bold)
                .minimumScaleFactor(0.5)
                .foregroundColor(.white)
                .scaleEffect(progress != nil ? (1.0 + 0.2 * sin(progress! * 2 * .pi)) : (animate ? 1.2 : 1.0))
                .animation(progress == nil ? Animation.easeInOut(duration: 1).repeatForever(autoreverses: true) : .none, value: animate)

            Image(systemName: "star.fill")
                .resizable()
                .frame(width: 50, height: 50)
                .foregroundColor(.yellow)
                .rotationEffect(.degrees(progress != nil ? progress! * 360 : (animate ? 360 : 0)))
                .animation(progress == nil ? Animation.linear(duration: 2).repeatForever(autoreverses: false) : .none, value: animate)
        }
        .padding()
        .background(
            LinearGradient(gradient: Gradient(colors: [.purple, .blue]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
        )
        .cornerRadius(20)
        .shadow(radius: 10)
        .onAppear {
            if progress == nil {
                self.animate = true
            }
        }
    }
}

// MARK: - View Extension to Convert SwiftUI View to UIImage

extension View {
    /// Converts any SwiftUI view to UIImage
    func asUIImage() -> UIImage? {
        // Create a hosting controller with the SwiftUI view
        let controller = UIHostingController(rootView: self)
        
        // Define the target size
        let targetSize = controller.view.intrinsicContentSize
        
        // Set the view's bounds
        controller.view.bounds = CGRect(origin: .zero, size: targetSize)
        controller.view.backgroundColor = .clear
        
        // Ensure the view has laid out its subviews
        controller.view.layoutIfNeeded()
        
        // Function to perform drawing
        func performDrawing() -> UIImage {
            let renderer = UIGraphicsImageRenderer(size: targetSize)
            return renderer.image { _ in
                controller.view.drawHierarchy(in: controller.view.bounds, afterScreenUpdates: true)
            }
        }
        
        // Check if the current thread is the main thread
        if Thread.isMainThread {
            // Perform drawing directly
            return performDrawing()
        } else {
            // Perform drawing on the main thread synchronously
            return DispatchQueue.main.sync {
                performDrawing()
            }
        }
    }
}
