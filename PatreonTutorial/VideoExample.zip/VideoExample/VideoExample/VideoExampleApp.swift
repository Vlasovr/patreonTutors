//
//  VideoExampleApp.swift
//  VideoExample
//
//  Created by Damra on 2.11.2024.
//

import SwiftUI

@main
struct VideoExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
