//
//  ContentView.swift
//  coloredsnow
//
//  Created by Selçuk Aslantas on 23.07.2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            
            SnowfallView()
                .edgesIgnoringSafeArea(.top)
                .shadow(color: .yellow, radius: 3.5, x: 0.0, y: 0.0)
            
            VStack {
                Text("Colored Snow".uppercased())
                    .foregroundColor(.white)
                    .font(.system(size: 20))
                Text("By SwiftUI Codes")
                    .font(.system(size: 15))
                    .foregroundStyle(.orange.gradient)
                
                Spacer()
                
                Image("csnow")
                    .aspectRatio(contentMode: .fill)
                    .shadow(color: .yellow, radius: 5, x: 0.0, y: 0.0)
                
            }
            .edgesIgnoringSafeArea(.bottom)
        }
    }
}

#Preview {
    ContentView()
}
