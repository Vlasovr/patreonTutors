//
//  coloredsnowApp.swift
//  coloredsnow
//
//  Created by Selçuk Aslantas on 23.07.2024.
//

import SwiftUI

@main
struct coloredsnowApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
