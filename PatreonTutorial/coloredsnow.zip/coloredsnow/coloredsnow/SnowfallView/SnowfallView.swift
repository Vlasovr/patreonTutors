//
//  SnowfallView.swift
//  coloredsnow
//
//  Created by Selçuk Aslantas on 23.07.2024.
//

import SwiftUI

struct SnowfallView: View {
    @State private var snowflakes: [SnowflakeModel] = []
    let snowflakeCount = 30
    let screenBounds = UIScreen.main.bounds
    var body: some View {
        Canvas { context, size in
            for snowflake in snowflakes {
                let snowflakeSize: CGFloat = 10
                let snowflakeRect = CGRect(x: snowflake.postion.x - snowflakeSize / 2, y: snowflake.postion.y - snowflakeSize / 2, width: snowflakeSize, height: snowflakeSize)
                let path = SnowFlake().path(in: snowflakeRect)
                context.fill(path, with: .color(snowflake.color))
            }
        }
        .onAppear(perform: {
            startSnowfall()
        })
    }
    func startSnowfall() {
        snowflakes = (0..<snowflakeCount).map {_ in
            SnowflakeModel(postion: CGPoint(x: CGFloat.random(in: 0...screenBounds.width),y: CGFloat.random(in: 0...screenBounds.height)), speed: CGFloat.random(in: 1...5), color: Color(red: Double.random(in: 0.5...1),green: Double.random(in: 0.5...1),blue: Double.random(in: 0.5...1)))
            
        }
        
        Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { _ in
            withAnimation(.linear(duration: 0.05)) {
                updateSnowflakes()
            }
        }
    }
    
    func updateSnowflakes() {
        snowflakes = snowflakes.map({ snowflake in
            var newY = snowflake.postion.y + snowflake.speed
            if newY > screenBounds.height {
                newY = 0
            }
            return SnowflakeModel(postion: CGPoint(x: snowflake.postion.x, y: newY), speed: snowflake.speed, color: snowflake.color)
        })
    }
    
}

#Preview {
    SnowfallView()
}

struct SnowFlake: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let radius: CGFloat = min(rect.width, rect.height) / 2

        path.addEllipse(in: CGRect(x: center.x - radius / 2, y: center.y - radius / 2, width: radius, height: radius))

        return path
    }
}

struct SnowflakeModel {
    var postion: CGPoint
    var speed: CGFloat
    var color: Color
}
