//
//  CarouselComponentApp.swift
//  CarouselComponent
//
//  Created by Damra on 1.10.2024.
//

import SwiftUI

@main
struct CarouselComponentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
