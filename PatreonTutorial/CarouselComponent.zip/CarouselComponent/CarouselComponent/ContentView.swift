//
//  ContentView.swift
//  CarouselComponent
//
//  Created by Damra on 1.10.2024.
//

import SwiftUI

struct ContentView: View {
    let sampleItems = [
        CarouselItem(imageName: "image1", title: "Image 1"),
        CarouselItem(imageName: "image2", title: "Image 2"),
        CarouselItem(imageName: "image3", title: "Image 3"),
        // Daha fazla öğe ekleyebilirsiniz
    ]
    
    var body: some View {
        NavigationView {
            VStack {
                CarouselView(items: sampleItems)
                    .padding()
                
                Spacer()
            }
            .navigationTitle("SwiftUI Carousel")
        }
    }
}

#Preview {
    ContentView()
}

import SwiftUI

struct CarouselItem: Identifiable {
    let id = UUID()
    let imageName: String
    let title: String
}

struct CarouselView: View {
    let items: [CarouselItem]
    @State private var currentIndex: Int = 0
    let timer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()
    
    var body: some View {
        VStack {
            TabView(selection: $currentIndex) {
                ForEach(Array(items.enumerated()), id: \.element.id) { index, item in
                    CarouselItemView(item: item)
                        .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
            .frame(height: 300)
            .onReceive(timer) { _ in
                withAnimation {
                    currentIndex = (currentIndex + 1) % items.count
                }
            }
            
            // Nokta göstergeleri
            HStack(spacing: 8) {
                ForEach(0..<items.count, id: \.self) { index in
                    Circle()
                        .fill(index == currentIndex ? Color.blue : Color.gray.opacity(0.5))
                        .frame(width: 8, height: 8)
                }
            }
            .padding(.top, 10)
        }
    }
}


struct CarouselItemView: View {
    let item: CarouselItem
    
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Image(item.imageName)
                .resizable()
                .scaledToFill()
                .frame(height: 300)
                .clipped()
                .cornerRadius(15)
                .shadow(radius: 5)
            
            Text(item.title)
                .font(.headline)
                .foregroundColor(.white)
                .padding()
                .background(Color.black.opacity(0.6))
                .cornerRadius(10)
                .padding([.leading, .bottom], 10)
        }
    }
}
