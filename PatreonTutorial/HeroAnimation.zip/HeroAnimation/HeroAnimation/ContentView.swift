
import SwiftUI

// Main view that initializes the Home view and injects the CarouselViewModel
struct ContentView: View {
    @StateObject var homeModel = CarouselViewModel()
    
    var body: some View {
        Home()
            .environmentObject(homeModel)
    }
}


// Home view which displays the carousel and navigation UI
struct Home: View {
    @EnvironmentObject var model: CarouselViewModel // Shared data model
    @Namespace var animation // Namespace for matched geometry effect animations
    
    var body: some View {
        ZStack {
            // Background color covering the entire screen
            Color(.systemBackground).edgesIgnoringSafeArea(.all)
            
            VStack {
                // Header with close button and title
                HStack {
                    Button(action: {}) {
                        Image(systemName: "xmark")
                            .font(.title2)
                            .foregroundColor(.primary)
                    }
                    
                    Text("Health Tips")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.primary)
                        .padding(.leading)
                    
                    Spacer()
                }
                .padding()
                
                // Carousel of cards stacked with ZStack
                ZStack {
                    // Looping through each card in reverse order for stacked effect
                    ForEach(model.cards.indices.reversed(), id: \.self) { index in
                        HStack {
                            CardView(card: model.cards[index], animation: animation)
                                .scaleEffect(getScale(index: index)) // Scale effect based on index
                                .offset(x: getCardOffset(index: index)) // Offset effect for layering
                                .rotationEffect(Angle(degrees: getCardRotation(index: index))) // Rotation effect based on swipe
                                .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 5) // Shadow for depth
                            
                            Spacer(minLength: 0) // Spacer to align cards properly
                        }
                        .frame(height: 450) // Setting card height
                        .contentShape(Rectangle()) // Setting shape for tap detection
                        .offset(x: model.cards[index].offset) // Offset based on card's current position
                        .gesture(DragGesture(minimumDistance: 0)
                            .onChanged({ (value) in
                                onChanged(value: value, index: index) // Handling swipe changes
                            }).onEnded({ (value) in
                                onEnd(value: value, index: index) // Handling swipe end
                            }))
                    }
                }
                .padding(.top, 25)
                .padding(.horizontal, 30)
                
                // Reset button to reset card positions
                Button(action: ResetViews) {
                    Image(systemName: "arrow.counterclockwise")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .clipShape(Circle())
                        .shadow(color: Color.blue.opacity(0.5), radius: 5, x: 0, y: 5) // Shadow for button
                }
                .padding(.top, 35)
                
                Spacer() // Spacer to push content to the top
            }
            
            // Display DetailView if a card is selected
            if model.showCard {
                DetailView(animation: animation)
                    .transition(.move(edge: .bottom)) // Slide-up transition for detail view
            }
        }
    }
    
    // Function to reset all card positions
    func ResetViews() {
        for index in model.cards.indices {
            withAnimation(.spring()) {
                model.cards[index].offset = 0 // Reset offset to initial position
                model.swipedCard = 0 // Reset swiped card index
            }
        }
    }
    
    // Function to update card position while swiping
    func onChanged(value: DragGesture.Value, index: Int) {
        if value.translation.width < 0 {
            model.cards[index].offset = value.translation.width // Update offset for left swipe
        }
    }
    
    // Function to handle swipe end and determine if card should move off screen
    func onEnd(value: DragGesture.Value, index: Int) {
        withAnimation {
            if -value.translation.width > UIScreen.main.bounds.width / 3 {
                // If swiped far enough, move card off screen and update swipedCard count
                model.cards[index].offset = -UIScreen.main.bounds.width
                model.swipedCard += 1
            } else {
                model.cards[index].offset = 0 // Reset position if swipe wasn't far enough
            }
        }
    }
    
    // Function to calculate rotation based on swipe offset
    func getCardRotation(index: Int) -> Double {
        let boxWidth = Double(UIScreen.main.bounds.width / 3)
        let offset = Double(model.cards[index].offset)
        let angle: Double = 5 // Maximum rotation angle
        return (offset / boxWidth) * angle
    }
    
    // Function to scale cards based on their index
    func getScale(index: Int) -> CGFloat {
        let scale = 1 - CGFloat(index - model.swipedCard) * 0.05
        return max(scale, 0.8) // Minimum scale is 0.8
    }
    
    // Function to set horizontal offset for card stacking effect
    func getCardOffset(index: Int) -> CGFloat {
        return CGFloat(index - model.swipedCard) * 20
    }
}

// View representing an individual card in the carousel
struct CardView: View {
    @EnvironmentObject var model: CarouselViewModel
    var card: Card // Current card data
    var animation: Namespace.ID // Namespace for matched geometry effect
    
    var body: some View {
        VStack {
            Text("Monday, December 28") // Static date text
                .font(.caption)
                .foregroundColor(.white.opacity(0.85))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 20)
                .padding(.horizontal)
                .matchedGeometryEffect(id: "Date-\(card.id)", in: animation)
            
            HStack {
                Text(card.title)
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.horizontal)
                    .matchedGeometryEffect(id: "Title-\(card.id)", in: animation)
                
                Spacer()
            }
            
            Spacer()
            
            if !model.showContent {
                HStack {
                    Spacer()
                    
                    Text("Read More")
                        .font(.headline)
                        .foregroundColor(.white)
                    Image(systemName: "arrow.right")
                        .foregroundColor(.white)
                }
                .padding()
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            ZStack {
                LinearGradient(gradient: Gradient(colors: [card.cardColor.opacity(0.8), card.cardColor]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .cornerRadius(25) // Rounded corners for card
                    .matchedGeometryEffect(id: "bgColor-\(card.id)", in: animation)
            }
        )
        .onTapGesture {
            withAnimation(.spring()) {
                model.selectedCard = card // Set selected card
                model.showCard.toggle() // Toggle detail view visibility
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    withAnimation(.easeIn) {
                        model.showContent = true // Show content with delay for animation
                    }
                }
            }
        }
    }
}

// Detail view for selected card
struct DetailView: View {
    @EnvironmentObject var model: CarouselViewModel
    var animation: Namespace.ID
    
    var body: some View {
        ZStack(alignment: .topTrailing) {
            VStack {
                Text("Monday, December 28")
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.85))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 50)
                    .padding(.horizontal)
                    .matchedGeometryEffect(id: "Date-\(model.selectedCard.id)", in: animation)
                
                HStack {
                    Text(model.selectedCard.title)
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.horizontal)
                        .matchedGeometryEffect(id: "Title-\(model.selectedCard.id)", in: animation)
                    
                    Spacer()
                }
                
                if model.showContent {
                    // Scrollable text content for detailed description
                    ScrollView {
                        Text(model.content)
                            .font(.body)
                            .foregroundColor(.white)
                            .padding()
                    }
                    .transition(.opacity) // Fade-in transition for content
                }
                
                Spacer()
            }
            .background(
                LinearGradient(gradient: Gradient(colors: [model.selectedCard.cardColor.opacity(0.8), model.selectedCard.cardColor]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .edgesIgnoringSafeArea(.all)
                    .matchedGeometryEffect(id: "bgColor-\(model.selectedCard.id)", in: animation)
            )
            
            // Close button to exit detail view
            if model.showContent {
                Button(action: CloseView) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 30))
                        .foregroundColor(.white)
                        .padding()
                }
                .padding(.top, 50)
                .padding(.trailing)
            }
        }
    }
    
    // Function to close detail view with animation
    func CloseView() {
        withAnimation(.spring()) {
            model.showContent = false
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                withAnimation(.easeIn) {
                    model.showCard = false
                }
            }
        }
    }
}

// Data model and logic for the carousel
class CarouselViewModel: ObservableObject {
    
    // Array of cards to display in the carousel
    @Published var cards = [
        Card(cardColor: Color.blue, title: "Neurobics for Your Mind"),
        Card(cardColor: Color.purple, title: "Review Your Hygiene"),
        Card(cardColor: Color.green, title: "Don't Skip Breakfast"),
        Card(cardColor: Color.yellow, title: "Exercise Regularly"),
        Card(cardColor: Color.orange, title: "Get Enough Sleep"),
    ]
    
    @Published var swipedCard = 0 // Index of the last swiped card
    
    // Detail view properties
    @Published var showCard = false // To show/hide detail view
    @Published var selectedCard = Card(cardColor: .clear, title: "") // Selected card for detail view
    @Published var showContent = false // To control content visibility in detail view
    
    // Placeholder detailed content text
    var content = """
Neurobic exercises are activities that encourage using your brain in new and unexpected ways. These exercises help increase mental flexibility by changing your daily routines and experiencing new things. For example, taking a different route to work, learning a new language, or brushing your teeth with your non-dominant hand are simple neurobic exercises.
"""
}

// Model representing individual card data
struct Card: Identifiable {
    var id = UUID().uuidString // Unique ID for each card
    var cardColor: Color // Background color for the card
    var offset: CGFloat = 0 // Current offset of the card (for swipe tracking)
    var title: String // Title text displayed on the card
}

#Preview {
    ContentView()
}

