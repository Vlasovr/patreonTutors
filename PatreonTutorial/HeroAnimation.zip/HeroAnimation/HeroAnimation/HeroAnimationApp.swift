

import SwiftUI

@main
struct HeroAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
