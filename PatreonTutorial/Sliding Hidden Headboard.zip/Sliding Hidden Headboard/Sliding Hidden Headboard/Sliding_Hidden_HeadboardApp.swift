//
//  Sliding_Hidden_HeadboardApp.swift
//  Sliding Hidden Headboard
//
//  Created by Damra on 2.11.2023.
//

import SwiftUI

@main
struct Sliding_Hidden_HeadboardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
