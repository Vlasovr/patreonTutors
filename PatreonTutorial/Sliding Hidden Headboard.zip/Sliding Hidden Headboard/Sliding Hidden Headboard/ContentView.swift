//
//  ContentView.swift
//  Sliding Hidden Headboard
//
//  Created by Damra on 2.11.2023.
//

import SwiftUI

//MARK: View Properties

struct ContentView: View {
    var body: some View {
        Home()
    }
}

#Preview {
    ContentView()
}
