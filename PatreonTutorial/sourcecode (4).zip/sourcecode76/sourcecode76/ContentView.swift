//
//  ContentView.swift
//  sourcecode76
//
//  Created by M.Damra on 21.02.2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        DraggableCard()
    }
}

#Preview {
    ContentView()
}

struct DraggableCard: View {
    @State private var offset = CGSize.zero
    @State private var rotation: Double = 0
    var body: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(
                LinearGradient(
                    colors: [.teal, .mint],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .frame(width: 250, height: 350)
            .offset(offset)
            .rotationEffect(.degrees(rotation))
            .gesture(
                DragGesture()
                    .onChanged { gesture in
                        offset = gesture.translation
                        rotation = Double(gesture.translation.width / 10)
                    }
                    .onEnded { _ in
                        withAnimation(.spring()) {
                            offset = .zero
                            rotation = 0
                        }
                    }
            )
    }
}
