//
//  sourcecode76App.swift
//  sourcecode76
//
//  Created by M.Damra on 21.02.2025.
//

import SwiftUI

@main
struct sourcecode76App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
