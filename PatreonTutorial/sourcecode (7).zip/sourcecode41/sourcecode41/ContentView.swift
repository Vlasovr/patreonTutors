//
//  ContentView.swift
//  sourcecode41
//
//  Created by M.Damra on 1.02.2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        StackedCardsView()
    }
}

#Preview {
    ContentView()
}

struct Card: Identifiable {
    let id = UUID()
    let title: String
    let imageName: String
}

struct CardView: View {
    let card: Card
    var body: some View {
        ZStack {
            Image(card.imageName)
                .resizable()
                .scaledToFit()
                .cornerRadius(25)
            
            Text(card.title)
                .font(.title)
                .foregroundColor(.black)
        }
        .frame(width: 400, height: 500)
    }
}

struct StackedCardsView: View {
    @State private var cards: [Card] = [
        Card(title: "", imageName: "photo1"),
        Card(title: "", imageName: "photo2"),
        Card(title: "", imageName: "photo3"),
        Card(title: "", imageName: "photo4")
    ]
    
    @State private var topCardOffset: CGSize = .zero
    
    var body: some View {
        ZStack {
            ForEach(Array(cards.enumerated()), id: \.element.id) { index, card in
                CardView(card: card)
                    .offset(y: CGFloat(index) * 10)
                    .scaleEffect(index == cards.count - 1 ? 1.0 : 0.95)
                    .offset(x: index == cards.count - 1 ? topCardOffset.width : 0)
                    .animation(.spring(), value: topCardOffset)
                    .gesture(
                        index == cards.count - 1 ?
                        DragGesture()
                            .onChanged { value in
                                topCardOffset = value.translation
                            }
                            .onEnded { value in
                                if abs(value.translation.width) > 100 {
                                    withAnimation {
                                        let removedCard = cards.removeLast()
                                        cards.insert(removedCard, at: 0)
                                        topCardOffset = .zero
                                    }
                                } else {
                                    withAnimation {
                                        topCardOffset = .zero
                                    }
                                }
                            }
                        : nil
                    )
            }
        }
    }
}
