//
//  sourcecode41App.swift
//  sourcecode41
//
//  Created by M.Damra on 1.02.2025.
//

import SwiftUI

@main
struct sourcecode41App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
