//
//  ToastView.swift
//  ToastNotification
//
//  Created by Damra on 25.10.2024.
//

import SwiftUI

// Custom component to display a toast message
struct ToastView: View {
    let message: String // Message to display
    var icon: Image? = nil // Optional icon
    var position: ToastPosition = .bottom // Toast position (top or bottom)
    var backgroundColor: Color = Color.black.opacity(0.8) // Background color
    var textColor: Color = .white // Text color
    var duration: Double = 2.0 // Toast display duration
    var actionTitle: String? = nil // Optional action title
    var action: (() -> Void)? = nil // Action function
    
    @Binding var isShowing: Bool // State to manage visibility
    @State private var offset: CGFloat = 0 // Offset for positioning
    
    // Toast positions
    enum ToastPosition {
        case top, bottom
    }
    
    var body: some View {
        VStack {
            if isShowing {
                VStack {
                    if position == .top {
                        toastContent
                            .transition(.move(edge: .top).combined(with: .opacity)) // Slide-in from top
                    }
                    Spacer()
                    if position == .bottom {
                        toastContent
                            .transition(.move(edge: .bottom).combined(with: .opacity)) // Slide-in from bottom
                    }
                }
                .edgesIgnoringSafeArea(.all)
                .onAppear {
                    withAnimation {
                        DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
                            withAnimation {
                                self.isShowing = false
                            }
                        }
                    }
                }
            }
        }
    }
    // Layout of the toast content
    private var toastContent: some View {
        HStack(spacing: 10) {
            if let icon = icon {
                icon
                    .foregroundColor(textColor)
            }
            Text(message)
                .foregroundColor(textColor)
                .multilineTextAlignment(.leading)
            if let actionTitle = actionTitle, let action = action {
                Button(action: {
                    action()
                    withAnimation {
                        isShowing = false
                    }
                }) {
                    Text(actionTitle)
                        .foregroundColor(.blue)
                        .underline()
                }
            }
        }
        .padding()
        .background(backgroundColor)
        .cornerRadius(10)
        .padding(.horizontal, 20)
        .shadow(radius: 5)
    }
}
