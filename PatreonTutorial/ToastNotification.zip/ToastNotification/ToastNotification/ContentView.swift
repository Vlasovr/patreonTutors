//
//  ContentView.swift
//  ToastNotification
//
//  Created by Damra on 25.10.2024.
//

import SwiftUI

struct ContentView: View {
    @State private var showToast: Bool = false // State to show the simple toast message
    @State private var showActionToast: Bool = false // State to show the actionable toast message
    var body: some View {
        ZStack {
            Color.mint.opacity(0.2).ignoresSafeArea()
            VStack {
                Spacer()
                
                // Button to Show Simple Toast
                Button(action: {
                    withAnimation(.bouncy) {
                        showToast = true
                    }
                }) {
                    Text("Show Simple Toast")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .padding(.bottom, 20)
                
                // Button to Show Actionable Toast
                Button(action: {
                    withAnimation(.bouncy) {
                        showActionToast = true
                    }
                }) {
                    Text("Show Action Toast")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.orange)
                        .cornerRadius(10)
                }
                
                Spacer()
                
            }
            
            // Simple ToastView, appears at the top
            ToastView(
                message: "This is a Toast message!",
                position: .top,
                backgroundColor: Color.black.opacity(0.8),
                textColor: .white,
                duration: 3.0,
                isShowing: $showToast
                )
            .padding([.top, .bottom])
            
            // Actionable ToastView, appears at the bottom with an action button
            ToastView(
                message: "Would you like to do something?",
                icon: Image(systemName: "questionmark.circle"),
                position: .bottom,
                backgroundColor: Color.orange.opacity(0.8),
                textColor: .white,
                duration: 3.0,
                actionTitle: "Do it Now",
                action: {
                    print("Action button tapped!")
                },
                isShowing: $showActionToast
                )
            .padding([.top, .bottom])
            
        }
    }
}

#Preview {
    ContentView()
}
