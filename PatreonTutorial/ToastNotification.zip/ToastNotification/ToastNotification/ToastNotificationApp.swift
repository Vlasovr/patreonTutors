//
//  ToastNotificationApp.swift
//  ToastNotification
//
//  Created by Damra on 25.10.2024.
//

import SwiftUI

@main
struct ToastNotificationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
