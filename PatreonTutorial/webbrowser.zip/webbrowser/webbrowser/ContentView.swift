import SwiftUI
import WebKit

// MARK: - ContentView
struct ContentView: View {
    @StateObject private var viewModel = WebViewModel()
    @State private var showingBookmarks = false
    @State private var showingShareSheet = false
    @State private var shareURL: URL?
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // URL Input Bar with Page Title
                HStack {
                    VStack(alignment: .leading) {
                        Text(viewModel.pageTitle)
                            .font(.headline)
                            .lineLimit(1)
                            .truncationMode(.tail)
                        HStack {
                            TextField("Enter URL", text: $viewModel.urlString, onCommit: {
                                viewModel.loadURL()
                            })
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.URL)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                            
                            Button(action: {
                                viewModel.loadURL()
                            }) {
                                Image(systemName: "arrow.right.circle")
                                    .font(.title2)
                            }
                        }
                    }
                }
                .padding([.horizontal, .top], 10)
                
                // Loading Progress Bar and Activity Indicator
                if viewModel.isLoading {
                    VStack {
                        ProgressView(value: viewModel.progress)
                            .progressViewStyle(LinearProgressViewStyle())
                            .padding([.horizontal], 10)
                        ActivityIndicator(isAnimating: .constant(true), style: .medium)
                            .padding(.bottom, 5)
                    }
                }
                
                // WebView
                WebView(viewModel: viewModel)
                    .edgesIgnoringSafeArea(.all)
                    .gesture(
                        DragGesture()
                            .onEnded { value in
                                if value.translation.width > 100 {
                                    viewModel.goBack()
                                } else if value.translation.width < -100 {
                                    viewModel.goForward()
                                }
                            }
                    )
                
                // Navigation and Action Buttons
                HStack {
                    Button(action: {
                        viewModel.goBack()
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.title2)
                    }
                    .disabled(!viewModel.webView.canGoBack)
                    .padding()
                    
                    Button(action: {
                        viewModel.goForward()
                    }) {
                        Image(systemName: "chevron.right")
                            .font(.title2)
                    }
                    .disabled(!viewModel.webView.canGoForward)
                    .padding()
                    
                    Spacer()
                    
                    Button(action: {
                        viewModel.reload()
                    }) {
                        Image(systemName: "arrow.clockwise")
                            .font(.title2)
                    }
                    .padding()
                    
                    Button(action: {
                        addBookmark()
                    }) {
                        Image(systemName: "bookmark")
                            .font(.title2)
                    }
                    .padding()
                    
                    Button(action: {
                        shareCurrentURL()
                    }) {
                        Image(systemName: "square.and.arrow.up")
                            .font(.title2)
                    }
                    .padding()
                }
                .background(Color(UIColor.systemGray6))
            }
            .navigationBarTitle("SwiftUI Browser", displayMode: .inline)
            .navigationBarItems(trailing:
                Button(action: {
                    showingBookmarks.toggle()
                }) {
                    Image(systemName: "book")
                        .font(.title2)
                }
            )
            .sheet(isPresented: $showingBookmarks) {
                BookmarksView(viewModel: viewModel, showingBookmarks: $showingBookmarks)
            }
            .sheet(isPresented: $showingShareSheet, content: {
                if let url = shareURL {
                    ShareSheet(activityItems: [url])
                }
            })
            .alert(item: $viewModel.errorAlert) { error in
                Alert(title: Text("Error"), message: Text(error.message), dismissButton: .default(Text("OK")))
            }
        }
    }
    
    // MARK: - Helper Functions
    private func addBookmark() {
        viewModel.addBookmark()
    }
    
    private func shareCurrentURL() {
        if let url = viewModel.webView.url {
            shareURL = url
            showingShareSheet = true
        }
    }
}

// MARK: - WebView
struct WebView: UIViewRepresentable {
    @ObservedObject var viewModel: WebViewModel
    
    func makeUIView(context: Context) -> WKWebView {
        viewModel.webView.navigationDelegate = context.coordinator
        viewModel.webView.addObserver(context.coordinator, forKeyPath: "estimatedProgress", options: .new, context: nil)
        viewModel.webView.addObserver(context.coordinator, forKeyPath: "title", options: .new, context: nil)
        return viewModel.webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        // No updates needed
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(viewModel: viewModel)
    }
    
    class Coordinator: NSObject, WKNavigationDelegate {
        var viewModel: WebViewModel
        
        init(viewModel: WebViewModel) {
            self.viewModel = viewModel
        }
        
        // Observe estimatedProgress and title changes
        override func observeValue(forKeyPath keyPath: String?, of object: Any?,
                                   change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
            if keyPath == "estimatedProgress" {
                DispatchQueue.main.async {
                    self.viewModel.progress = self.viewModel.webView.estimatedProgress
                    if self.viewModel.progress >= 1.0 {
                        self.viewModel.isLoading = false
                    }
                }
            } else if keyPath == "title" {
                DispatchQueue.main.async {
                    self.viewModel.pageTitle = self.viewModel.webView.title ?? ""
                }
            }
        }
        
        // Navigation Delegate Methods
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            DispatchQueue.main.async {
                self.viewModel.isLoading = true
                self.viewModel.errorAlert = nil
            }
        }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            DispatchQueue.main.async {
                self.viewModel.isLoading = false
                self.viewModel.urlString = webView.url?.absoluteString ?? ""
                self.viewModel.pageTitle = webView.title ?? ""
            }
        }
        
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            DispatchQueue.main.async {
                self.viewModel.isLoading = false
                self.viewModel.errorAlert = WebError(message: error.localizedDescription)
            }
        }
        
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!,
                     withError error: Error) {
            DispatchQueue.main.async {
                self.viewModel.isLoading = false
                self.viewModel.errorAlert = WebError(message: error.localizedDescription)
            }
        }
    }
}

// MARK: - WebViewModel
class WebViewModel: ObservableObject {
    @Published var urlString: String = "https://www.apple.com"
    @Published var isLoading: Bool = false
    @Published var progress: Double = 0.0
    @Published var pageTitle: String = "SwiftUI Browser"
    @Published var errorAlert: WebError?
    @Published var bookmarks: [Bookmark] = []
    
    let webView: WKWebView = WKWebView()
    
    init() {
        loadURL()
        loadBookmarks()
    }
    
    // Load URL in WebView
    func loadURL() {
        var formattedURL = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if !formattedURL.hasPrefix("http://") && !formattedURL.hasPrefix("https://") {
            formattedURL = "https://" + formattedURL
        }
        
        if let url = URL(string: formattedURL) {
            let request = URLRequest(url: url)
            webView.load(request)
        } else {
            errorAlert = WebError(message: "Invalid URL")
        }
    }
    
    // Navigation Controls
    func goBack() {
        if webView.canGoBack {
            webView.goBack()
        }
    }
    
    func goForward() {
        if webView.canGoForward {
            webView.goForward()
        }
    }
    
    func reload() {
        webView.reload()
    }
    
    // Bookmark Management
    func addBookmark() {
        guard let url = webView.url else { return }
        let newBookmark = Bookmark(title: pageTitle, url: url.absoluteString)
        if !bookmarks.contains(newBookmark) {
            bookmarks.append(newBookmark)
            saveBookmarks()
        }
    }
    
    func removeBookmark(at offsets: IndexSet) {
        bookmarks.remove(atOffsets: offsets)
        saveBookmarks()
    }
    
    func loadBookmark(_ bookmark: Bookmark) {
        urlString = bookmark.url
        loadURL()
    }
    
    // Persistence with UserDefaults
    private func loadBookmarks() {
        if let data = UserDefaults.standard.data(forKey: "Bookmarks"),
           let savedBookmarks = try? JSONDecoder().decode([Bookmark].self, from: data) {
            bookmarks = savedBookmarks
        }
    }
    
    private func saveBookmarks() {
        if let data = try? JSONEncoder().encode(bookmarks) {
            UserDefaults.standard.set(data, forKey: "Bookmarks")
        }
    }
}

// MARK: - Bookmark Model
struct Bookmark: Identifiable, Codable, Equatable {
    let id = UUID()
    let title: String
    let url: String
}

// MARK: - WebError Model
struct WebError: Identifiable {
    var id: String { message }
    let message: String
}

// MARK: - BookmarksView
struct BookmarksView: View {
    @ObservedObject var viewModel: WebViewModel
    @Binding var showingBookmarks: Bool
    
    var body: some View {
        NavigationView {
            List {
                ForEach(viewModel.bookmarks) { bookmark in
                    Button(action: {
                        viewModel.loadBookmark(bookmark)
                        showingBookmarks = false
                    }) {
                        VStack(alignment: .leading) {
                            Text(bookmark.title)
                                .font(.headline)
                            Text(bookmark.url)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                                .lineLimit(1)
                                .truncationMode(.middle)
                        }
                    }
                }
                .onDelete(perform: viewModel.removeBookmark)
            }
            .navigationBarTitle("Bookmarks", displayMode: .inline)
            .navigationBarItems(leading: Button("Close") {
                showingBookmarks = false
            }, trailing: EditButton())
        }
    }
}

// MARK: - ShareSheet
struct ShareSheet: UIViewControllerRepresentable {
    var activityItems: [Any]
    var applicationActivities: [UIActivity]? = nil
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: activityItems,
                                                  applicationActivities: applicationActivities)
        return controller
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

// MARK: - ActivityIndicator
struct ActivityIndicator: UIViewRepresentable {
    @Binding var isAnimating: Bool
    let style: UIActivityIndicatorView.Style
    
    func makeUIView(context: Context) -> UIActivityIndicatorView {
        let indicator = UIActivityIndicatorView(style: style)
        indicator.hidesWhenStopped = true
        return indicator
    }
    
    func updateUIView(_ uiView: UIActivityIndicatorView, context: Context) {
        isAnimating ? uiView.startAnimating() : uiView.stopAnimating()
    }
}

// MARK: - App Entry Point
@main
struct WebBrowserApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}


#Preview {
    ContentView()
}
