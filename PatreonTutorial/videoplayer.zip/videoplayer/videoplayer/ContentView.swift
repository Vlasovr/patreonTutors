import SwiftUI
import AVKit
import AVFoundation

// MARK: - Subtitle Model
struct Subtitle: Identifiable {
    let id = UUID()
    let startTime: TimeInterval
    let endTime: TimeInterval
    let text: String
}

// MARK: - Subtitle Parser
class SubtitleParser {
    static func parseSRT(url: URL) -> [Subtitle] {
        do {
            let content = try String(contentsOf: url, encoding: .utf8)
            let regex = try NSRegularExpression(pattern: "(\\d+)\\s+([\\d:,]+)\\s+-->\\s+([\\d:,]+)\\s+(.+?)(?=\\n\\n|$)", options: .dotMatchesLineSeparators)
            let matches = regex.matches(in: content, options: [], range: NSRange(location: 0, length: content.utf16.count))
            
            var subtitles: [Subtitle] = []
            
            for match in matches {
                if match.numberOfRanges == 5,
                   let startRange = Range(match.range(at: 2), in: content),
                   let endRange = Range(match.range(at: 3), in: content),
                   let textRange = Range(match.range(at: 4), in: content) {
                    
                    let startString = String(content[startRange])
                    let endString = String(content[endRange])
                    let text = String(content[textRange]).trimmingCharacters(in: .whitespacesAndNewlines)
                    
                    let startTime = SubtitleParser.timeInterval(from: startString)
                    let endTime = SubtitleParser.timeInterval(from: endString)
                    
                    let subtitle = Subtitle(startTime: startTime, endTime: endTime, text: text)
                    subtitles.append(subtitle)
                }
            }
            
            return subtitles
        } catch {
            print("Failed to parse SRT file: \(error)")
            return []
        }
    }
    
    private static func timeInterval(from string: String) -> TimeInterval {
        let components = string.components(separatedBy: ":")
        guard components.count == 3 else { return 0 }
        
        let hours = Double(components[0]) ?? 0
        let minutes = Double(components[1]) ?? 0
        let secondsAndMilliseconds = components[2].components(separatedBy: ",")
        let seconds = Double(secondsAndMilliseconds.first ?? "0") ?? 0
        let milliseconds = Double(secondsAndMilliseconds.last ?? "0") ?? 0
        
        return hours * 3600 + minutes * 60 + seconds + milliseconds / 1000
    }
}

// MARK: - Enhanced Full-Screen Video Player
struct EnhancedFullScreenVideoPlayerView: View {
    @State private var player: AVPlayer = AVPlayer()
    @State private var isPlaying: Bool = false
    @State private var currentTime: Double = 0
    @State private var totalTime: Double = 0
    @State private var isMuted: Bool = false
    @State private var showControls: Bool = true
    @State private var isFullScreen: Bool = true
    @State private var volume: Double = 0.5
    @State private var playbackSpeed: Double = 1.0
    @State private var showPlaybackSpeedOptions: Bool = false
    @State private var isFavorite: Bool = false
    @State private var showShareSheet: Bool = false
    @State private var showDownloadAlert: Bool = false
    @State private var subtitlesEnabled: Bool = false
    @State private var subtitles: [Subtitle] = []
    @State private var currentSubtitle: String = ""
    
    @Namespace private var animation
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Video Player
                VideoPlayer(player: player)
                    .onAppear(perform: setupPlayer)
                    .edgesIgnoringSafeArea(.all)
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .onTapGesture {
                        toggleControls()
                    }
                    .transition(.opacity)
                
                // Gradient Overlay
                LinearGradient(
                    gradient: Gradient(colors: [Color.black.opacity(0.0), Color.black.opacity(0.7)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .edgesIgnoringSafeArea(.all)
                .opacity(showControls ? 1 : 0)
                .animation(.easeInOut, value: showControls)
                
                // Subtitles Overlay
                if subtitlesEnabled && !currentSubtitle.isEmpty {
                    VStack {
                        Spacer()
                        Text(currentSubtitle)
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.black.opacity(0.6))
                            .cornerRadius(10)
                            .padding(.bottom, 50)
                    }
                    .transition(.opacity)
                }
                
                // Controls Overlay
                if showControls {
                    VStack {
                        // Top Controls
                        HStack {
                            Button(action: toggleFavorite) {
                                Image(systemName: isFavorite ? "heart.fill" : "heart")
                                    .font(.title2)
                                    .foregroundColor(isFavorite ? .red : .white)
                            }
                            Spacer()
                            Button(action: {
                                showShareSheet.toggle()
                            }) {
                                Image(systemName: "square.and.arrow.up")
                                    .font(.title2)
                                    .foregroundColor(.white)
                            }
                            .sheet(isPresented: $showShareSheet) {
                                ShareSheet(activityItems: [player.currentItem?.asset as Any].compactMap { $0 })
                            }
                        }
                        .padding([.leading, .trailing, .top], 20)
                        
                        Spacer()
                        
                        // Playback Controls
                        VStack(spacing: 20) {
                            // Playback Controls
                            playbackControls()
                            
                            // Progress Slider
                            progressSlider()
                            
                            // Bottom Controls
                            HStack {
                                // Sound Controls
                                soundControls()
                                
                                Spacer()
                                
                                // Playback Speed
                                playbackSpeedControls()
                                
                                Spacer()
                                
                                // Full-Screen Toggle
                                Button(action: toggleFullScreen) {
                                    Image(systemName: isFullScreen ? "arrow.down.right.and.arrow.up.left" : "arrow.up.left.and.arrow.down.right")
                                        .resizable()
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(.white)
                                }
                            }
                            .padding([.leading, .trailing], 20)
                            
                            // Additional Controls
                            HStack {
                                // Subtitles Toggle
                                Button(action: toggleSubtitles) {
                                    Image(systemName: subtitlesEnabled ? "captions.bubble.fill" : "captions.bubble")
                                        .font(.title2)
                                        .foregroundColor(subtitlesEnabled ? .yellow : .white)
                                }
                                
                                Spacer()
                                
                                // Download Button
                                Button(action: downloadVideo) {
                                    Image(systemName: "arrow.down.circle")
                                        .font(.title2)
                                        .foregroundColor(.white)
                                }
                                .alert(isPresented: $showDownloadAlert) {
                                    Alert(title: Text("Download"), message: Text("Video downloaded successfully."), dismissButton: .default(Text("OK")))
                                }
                            }
                            .padding([.leading, .trailing], 20)
                        }
                        .padding(.bottom, 30)
                        .background(BlurView(style: .systemUltraThinMaterialDark).opacity(0.5))
                        .cornerRadius(15)
                        .padding(.bottom, 20)
                        .transition(.move(edge: .bottom))
                    }
                }
            }
            .background(Color.black)
            .onAppear {
                player.volume = Float(volume)
                enterFullScreen()
            }
            .onDisappear {
                player.pause()
            }
        }
        .statusBar(hidden: isFullScreen)
        .edgesIgnoringSafeArea(isFullScreen ? .all : .init())
        // Update current subtitle as the video plays
        .onReceive(Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()) { _ in
            updateCurrentSubtitle()
        }
    }
    
    // MARK: - Player Setup
    private func setupPlayer() {
        guard let url = Bundle.main.url(forResource: "sample", withExtension: "mp4") else {
            print("Video file not found.")
            return
        }
        let asset = AVAsset(url: url)
        let item = AVPlayerItem(asset: asset)
        
        player = AVPlayer(playerItem: item)
        player.isMuted = isMuted
        player.volume = Float(volume)
        player.rate = Float(playbackSpeed)
        
        // Observe player time
        player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 1, preferredTimescale: 1),
                                       queue: .main) { _ in
            updateTime()
        }
        
        // Get total duration
        if let duration = player.currentItem?.asset.duration {
            totalTime = CMTimeGetSeconds(duration)
        }
        
        // Load Subtitles
        loadSubtitles()
        
        // Start Playing
        player.play()
        isPlaying = true
    }
    
    // MARK: - Load Subtitles
    private func loadSubtitles() {
        guard let subtitleURL = Bundle.main.url(forResource: "sample", withExtension: "srt") else {
            print("Subtitle file not found.")
            return
        }
        subtitles = SubtitleParser.parseSRT(url: subtitleURL)
    }
    
    // MARK: - Enter Full Screen
    private func enterFullScreen() {
        // Ensure the app launches in full-screen mode
        // Note: Full-screen behavior might vary based on device and context
    }
    
    // MARK: - Play and Pause
    private func togglePlayPause() {
        if isPlaying {
            player.pause()
        } else {
            player.play()
        }
        isPlaying.toggle()
    }
    
    // MARK: - Update Time
    private func updateTime() {
        currentTime = player.currentTime().seconds
        if let duration = player.currentItem?.duration {
            totalTime = CMTimeGetSeconds(duration)
        }
    }
    
    // MARK: - Mute/Unmute
    private func toggleMute() {
        isMuted.toggle()
        player.isMuted = isMuted
    }
    
    // MARK: - Rewind
    private func rewind() {
        let newTime = max(currentTime - 10, 0)
        player.seek(to: CMTime(seconds: newTime, preferredTimescale: 1))
    }
    
    // MARK: - Forward
    private func forward() {
        let newTime = min(currentTime + 10, totalTime)
        player.seek(to: CMTime(seconds: newTime, preferredTimescale: 1))
    }
    
    // MARK: - Toggle Controls
    private func toggleControls() {
        withAnimation {
            showControls.toggle()
        }
    }
    
    // MARK: - Toggle Full Screen
    private func toggleFullScreen() {
        withAnimation(.easeInOut) {
            isFullScreen.toggle()
        }
    }
    
    // MARK: - Update Progress
    private func updateProgress(to value: Double) {
        player.seek(to: CMTime(seconds: value, preferredTimescale: 1))
        currentTime = value
    }
    
    // MARK: - Playback Controls View
    private func playbackControls() -> some View {
        HStack(spacing: 40) {
            Button(action: rewind) {
                Image(systemName: "gobackward.10")
                    .font(.title)
                    .foregroundColor(.white)
            }
            
            Button(action: togglePlayPause) {
                Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                    .font(.system(size: 50))
                    .foregroundColor(.white)
            }
            
            Button(action: forward) {
                Image(systemName: "goforward.10")
                    .font(.title)
                    .foregroundColor(.white)
            }
        }
        .padding(.top, 20)
        .animation(.easeInOut, value: isPlaying)
    }
    
    // MARK: - Progress Slider View
    private func progressSlider() -> some View {
        VStack {
            Slider(value: Binding(get: {
                currentTime
            }, set: { newValue in
                updateProgress(to: newValue)
            }), in: 0...totalTime, minimumValueLabel: Text(formatTime(currentTime)),
               maximumValueLabel: Text(formatTime(totalTime))) {
                Text("Progress")
            }
            .accentColor(.red)
            .padding([.leading, .trailing], 20)
        }
    }
    
    // MARK: - Sound Controls View
    private func soundControls() -> some View {
        HStack {
            Button(action: toggleMute) {
                Image(systemName: isMuted ? "speaker.slash.fill" : "speaker.2.fill")
                    .foregroundColor(.white)
            }
            
            Slider(value: Binding(get: {
                volume
            }, set: { newValue in
                volume = newValue
                player.volume = Float(newValue)
                if newValue > 0 {
                    isMuted = false
                } else {
                    isMuted = true
                }
            }), in: 0...1)
            .accentColor(.white)
        }
    }
    
    // MARK: - Playback Speed Controls
    private func playbackSpeedControls() -> some View {
        VStack {
            Button(action: {
                withAnimation {
                    showPlaybackSpeedOptions.toggle()
                }
            }) {
                Text("\(String(format: "%.1fx", playbackSpeed))")
                    .foregroundColor(.white)
                    .padding(5)
                    .background(Color.black.opacity(0.5))
                    .cornerRadius(5)
            }
            
            if showPlaybackSpeedOptions {
                HStack {
                    Button(action: { setPlaybackSpeed(0.5) }) {
                        Text("0.5x")
                            .foregroundColor(playbackSpeed == 0.5 ? .yellow : .white)
                            .padding(5)
                    }
                    Button(action: { setPlaybackSpeed(1.0) }) {
                        Text("1.0x")
                            .foregroundColor(playbackSpeed == 1.0 ? .yellow : .white)
                            .padding(5)
                    }
                    Button(action: { setPlaybackSpeed(1.5) }) {
                        Text("1.5x")
                            .foregroundColor(playbackSpeed == 1.5 ? .yellow : .white)
                            .padding(5)
                    }
                    Button(action: { setPlaybackSpeed(2.0) }) {
                        Text("2.0x")
                            .foregroundColor(playbackSpeed == 2.0 ? .yellow : .white)
                            .padding(5)
                    }
                }
                .background(Color.black.opacity(0.7))
                .cornerRadius(10)
                .padding(.top, 5)
                .transition(.opacity)
            }
        }
    }
    
    private func setPlaybackSpeed(_ speed: Double) {
        playbackSpeed = speed
        player.rate = Float(speed)
        showPlaybackSpeedOptions = false
    }
    
    // MARK: - Toggle Favorite
    private func toggleFavorite() {
        isFavorite.toggle()
        // Implement favorite logic here (e.g., save to UserDefaults or a database)
    }
    
    // MARK: - Toggle Subtitles
    private func toggleSubtitles() {
        subtitlesEnabled.toggle()
    }
    
    // MARK: - Download Video
    private func downloadVideo() {
        // Implement download logic here
        // For demonstration, we'll show an alert
        showDownloadAlert = true
    }
    
    // MARK: - Update Current Subtitle
    private func updateCurrentSubtitle() {
        guard subtitlesEnabled else {
            currentSubtitle = ""
            return
        }
        
        if let subtitle = subtitles.first(where: { currentTime >= $0.startTime && currentTime <= $0.endTime }) {
            currentSubtitle = subtitle.text
        } else {
            currentSubtitle = ""
        }
    }
    
    // MARK: - Time Formatting
    private func formatTime(_ time: Double) -> String {
        guard !time.isNaN else { return "00:00" }
        let minutes = Int(time) / 60
        let seconds = Int(time) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

// MARK: - Blur View for Background
struct BlurView: UIViewRepresentable {
    var style: UIBlurEffect.Style = .systemUltraThinMaterialDark
    
    func makeUIView(context: Context) -> UIVisualEffectView {
        return UIVisualEffectView(effect: UIBlurEffect(style: style))
    }
    
    func updateUIView(_ uiView: UIVisualEffectView, context: Context) {}
}

// MARK: - Share Sheet
struct ShareSheet: UIViewControllerRepresentable {
    var activityItems: [Any]
    var applicationActivities: [UIActivity]? = nil
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: activityItems, applicationActivities: applicationActivities)
        return controller
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

// MARK: - Preview
struct EnhancedFullScreenVideoPlayerView_Previews: PreviewProvider {
    static var previews: some View {
        EnhancedFullScreenVideoPlayerView()
    }
}
