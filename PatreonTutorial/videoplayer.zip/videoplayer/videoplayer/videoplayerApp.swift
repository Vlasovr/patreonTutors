//
//  videoplayerApp.swift
//  videoplayer
//
//  Created by Altuğ Nuri ASLANTAŞ on 2.12.2024.
//

import SwiftUI

@main
struct videoplayerApp: App {
    var body: some Scene {
        WindowGroup {
            EnhancedFullScreenVideoPlayerView()
        }
    }
}
