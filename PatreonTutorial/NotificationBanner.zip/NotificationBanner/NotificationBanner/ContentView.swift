//
//  ContentView.swift
//  NotificationBanner
//
//  Created by Damra on 24.10.2024.
//

import SwiftUI

struct ContentView: View {
    // Using @State variables to manage the state of the banner, such as its visibility and type
    @State private var showBanner: Bool = false
    @State private var bannerType: NotificationBannerType = .success
    @State private var bannerTitle: String = ""
    @State private var bannerMessage: String? = nil
    @State private var bannerPosition: NotificationBannerPosition = .top

    var body: some View {
        ZStack {
            VStack(spacing: 20) {
                Spacer()

                // Picker component allows the user to select the position of the banner
                Picker("Position", selection: $bannerPosition) {
                    Text("Top").tag(NotificationBannerPosition.top)
                    Text("Center").tag(NotificationBannerPosition.center)
                    Text("Bottom").tag(NotificationBannerPosition.bottom)
                }
                .pickerStyle(SegmentedPickerStyle()) // Segmented style design
                .padding()

                // Button to show the success banner
                Button(action: {
                    showSuccessBanner()
                }) {
                    Text("Success Action")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(10)
                }
                
                // Button to show the error banner
                Button(action: {
                    showErrorBanner()
                }) {
                    Text("Error Action")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.red)
                        .cornerRadius(10)
                }
                
                // Button to show the warning banner
                Button(action: {
                    showWarningBanner()
                }) {
                    Text("Warning Action")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.orange)
                        .cornerRadius(10)
                }
                
                // Button to show the info banner
                Button(action: {
                    showInfoBanner()
                }) {
                    Text("Info Action")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }

                Spacer()
            }

            // If the banner is visible, show the NotificationBanner component
            if showBanner {
                NotificationBanner(
                    type: bannerType,   // The type of banner (success, error, warning, info)
                    title: bannerTitle, // The title of the banner
                    message: bannerMessage, // The message of the banner (optional)
                    duration: 3.0, // The duration the banner will stay on the screen
                    onDismiss: {
                        showBanner = false // Hide the banner when dismiss is triggered
                    },
                    position: bannerPosition, // The position of the banner on the screen
                    animation: .spring(response: 0.5, dampingFraction: 0.7, blendDuration: 0.5), // Animation for the banner
                    additionalContent: {
                        // Additional content: provides extra information for the user
                        Text("Additional info can be placed here.")
                            .font(.subheadline)
                            .foregroundColor(.white)
                    }
                )
                .zIndex(1) // Ensures the banner appears above other elements
            }
        }
    }
    
    // Function to show the success banner
    func showSuccessBanner() {
        bannerType = .success
        bannerTitle = "Success!"
        bannerMessage = "The operation was completed successfully."
        showBanner = true
    }

    // Function to show the error banner
    func showErrorBanner() {
        bannerType = .error
        bannerTitle = "Error!"
        bannerMessage = "An error occurred during the operation."
        showBanner = true
    }

    // Function to show the warning banner
    func showWarningBanner() {
        bannerType = .warning
        bannerTitle = "Warning!"
        bannerMessage = "There is something you need to be cautious about."
        showBanner = true
    }

    // Function to show the info banner
    func showInfoBanner() {
        bannerType = .info
        bannerTitle = "Info"
        bannerMessage = "This is an informational message."
        showBanner = true
    }
}

#Preview {
    ContentView()
}
