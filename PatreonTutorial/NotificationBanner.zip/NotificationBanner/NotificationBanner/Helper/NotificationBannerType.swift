//
//  NotificationBannerType.swift
//  NotificationBanner
//
//  Created by Damra on 24.10.2024.
//

import SwiftUI

enum NotificationBannerType {
    case success
    case error
    case warning
    case info

    // Computed property to set the background color based on the banner type
    var backgroundColor: Color {
        switch self {
        case .success:
            return Color.green.opacity(0.9)
        case .error:
            return Color.red.opacity(0.9)
        case .warning:
            return Color.orange.opacity(0.9)
        case .info:
            return Color.blue.opacity(0.9)
        }
    }

    // Computed property to determine the icon used in the banner based on the type
    var iconName: String {
        switch self {
        case .success:
            return "checkmark.circle"
        case .error:
            return "xmark.octagon"
        case .warning:
            return "exclamationmark.triangle"
        case .info:
            return "info.circle"
        }
    }
}
