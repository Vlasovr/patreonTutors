//
//  NotificationBannerPosition.swift
//  NotificationBanner
//
//  Created by Damra on 24.10.2024.
//

import SwiftUI

enum NotificationBannerPosition {
    case top
    case center
    case bottom
}
