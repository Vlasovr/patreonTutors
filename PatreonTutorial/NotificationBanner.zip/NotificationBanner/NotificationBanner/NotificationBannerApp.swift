//
//  NotificationBannerApp.swift
//  NotificationBanner
//
//  Created by Damra on 24.10.2024.
//

import SwiftUI

@main
struct NotificationBannerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
