//
//  NotificationBanner.swift
//  NotificationBanner
//
//  Created by Damra on 24.10.2024.
//

import SwiftUI

struct NotificationBanner<Content: View>: View {
    let type: NotificationBannerType
    let title: String
    let message: String?
    let duration: Double
    let onDismiss: () -> Void
    let position: NotificationBannerPosition
    let animation: Animation
    let additionalContent: () -> Content

    @State private var isVisible: Bool = false

    var body: some View {
        VStack {
            // If the position is top and the banner is visible, show the banner with a top-to-bottom animation
            if position == .top {
                if isVisible {
                    bannerContent
                        .transition(.move(edge: .top).combined(with: .opacity))
                }
            }

            Spacer()

            // If the position is center and the banner is visible, show the banner with a scale and opacity animation
            if position == .center {
                if isVisible {
                    bannerContent
                        .transition(.scale.combined(with: .opacity))
                }
            }

            // If the position is bottom and the banner is visible, show the banner with a bottom-to-top animation
            if position == .bottom {
                if isVisible {
                    bannerContent
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }
            }
        }
        .animation(animation, value: isVisible) // Animation for the banner
        .onAppear {
            showBanner() // Show the banner when it appears
        }
    }

    // The content of the banner (icon, title, message, and additional content)
    var bannerContent: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: type.iconName) // Icon based on banner type
                    .resizable()
                    .frame(width: 24, height: 24)
                    .foregroundColor(.white)

                VStack(alignment: .leading, spacing: 2) {
                    Text(title) // Banner title
                        .font(.headline)
                        .foregroundColor(.white)
                    if let message = message {
                        Text(message) // Banner message (optional)
                            .font(.subheadline)
                            .foregroundColor(.white)
                    }
                }

                Spacer()

                // Button to close the banner
                Button(action: {
                    dismissBanner()
                }) {
                    Image(systemName: "xmark")
                        .foregroundColor(.white)
                        .padding(8)
                }
            }

            additionalContent() // Additional content
        }
        .padding()
        .background(type.backgroundColor) // Background color based on banner type
        .cornerRadius(10)
        .shadow(radius: 5)
        .padding([.horizontal, position == .top ? .top : .bottom], 16)
    }

    // Function to show the banner
    func showBanner() {
        withAnimation {
            isVisible = true
        }

        // After the specified duration, hide the banner
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
            dismissBanner()
        }
    }

    // Function to dismiss the banner
    func dismissBanner() {
        withAnimation {
            isVisible = false
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            onDismiss()
        }
    }
}
